# 'coding: utf-8'
# Davi Rich     aka: Stalkerstein
# 2025-04-18
# Version 1.0
# Final release!
#
# PySide6 is LGPL licensed.
#   This means you don’t need a commercial license (from Qt) to
#   distribute your application without distributing the source.
#   https://www.gnu.org/licenses/lgpl-3.0.html
#
# Most commands were tested on these distros at certain points of development.
# CachyOS, Debian, Endeavour, Feren, Garuda, KDE Neon, Kubuntu, Lite, LMDE,
# Manjaro, Mint, MX, Neptune, Nobara, Parrot, Q4OS, Solus, Sparky, Ubuntu
#
# CachyOS 24.12 Plasma                                  # finished
# Debian GNU/Linux 12.9.0 Bookworm Plasma               # finished
# EndeavourOS_Endeavour_neo-2024.09.22 01-06-2025       # finished
# Feren 2023.04 Plasma                                  # finished
# Garuda-cinnamon-linux-zen-240428 Bird of Prey         # finished
# Garuda-xfce-linux-lts-240428 Bird of Prey             # finished
# Kubuntu-24.04.1 KDE Noble                             # finished
# Linuxmint-21.3-cinnamon                               # finished
# LinuxMint-22.1-cinnamon                               # finished
# Lite-Xfce-7.4 Nobile                                  # finished
# LMDE-6-cinnamon                                       # finished
# Manjaro-kde-24.2.1-241216 Zetar                       # finished
# Manjaro-xfce-24.2.1-241216 Zetar                      # finished
# MX-23.5_KDE Plasma                                    # finished
# MX-23.5_xfce_ahs                                      # finished
# Neon-kde-user-20250202-0745 Plasma                    # finished
# Neptune8-KDE-20240328 Bookworm                        # finished
# Nobara-41-KDE-2025-01-05                              # finished
# Parrot-home-6.2                                       # finished
# Parrot-home-6.3.2                                     # finished
# Parrot-security-6.2                                   # finished
# Q4os-5.7 Debian 12 Bookworm                           # finished
# Solus-Plasma-Release-2024-10-14                       # finished
# Sparkylinux-7.6-x86_64-kde                            # finished
# Sparkylinux-7.6-x86_64-mate                           # finished
# Sparkylinux-7.6-x86_64-xfce                           # finished
# Ubuntu 24.04.2 LTS Cinnamon & Mate                    # finished
#
# Python as of late 3.12.3, Qt Designer 6.4.2, Pycharm 2025.1 (Community)
#   PyCharm requires PySide6, PySide6-Addons, PySide6-Essentials
#   reboot after install PySide6 for it to show in PyCharm.

# Installing 'ttf-mscorefonts-installer' is optional when using LibreOffice
# LMDE & Mint: cinnamon-settings (actions, general, info, power, settings, themes, etc.)
# dpkg-query -Wf '${Installed-size}\t${Package}\n' | column -t      List programs & sizes
#

import os
import sys
import platform
import subprocess
import threading
import webbrowser
import shutil
import getpass
import time
from os.path import exists
from shutil import which
from subprocess import PIPE
from PySide6 import QtCore
from PySide6 import QtGui
from PySide6 import QtWidgets
from PySide6.QtCore import QProcess
from PySide6.QtWidgets import QMessageBox, QInputDialog, QLineEdit, QLabel


class Ui_MainWindow(object):
    def setupUi(ui, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setStyleSheet("")
        MainWindow.setAnimated(False)
        ui.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        ui.centralwidget.setObjectName("centralwidget")
        ui.lbnotices = QtWidgets.QLabel(parent=ui.centralwidget)
        ui.lbnotices.setGeometry(QtCore.QRect(60, 522, 711, 18))
        font = QtGui.QFont()
        font.setItalic(True)
        ui.lbnotices.setFont(font)
        ui.lbnotices.setObjectName("lbnotices")
        ui.tabWidget = QtWidgets.QTabWidget(parent=ui.centralwidget)
        ui.tabWidget.setGeometry(QtCore.QRect(10, 12, 800, 500))
        ui.tabWidget.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus)
        ui.tabWidget.setStyleSheet("")
        ui.tabWidget.setTabShape(QtWidgets.QTabWidget.TabShape.Rounded)
        ui.tabWidget.setObjectName("tabWidget")
        ui.tab_1 = QtWidgets.QWidget()
        ui.tab_1.setObjectName("tab_1")
        ui.pb5 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb5.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb5.setObjectName("pb5")
        ui.lb5 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb5.setGeometry(QtCore.QRect(140, 106, 71, 30))
        ui.lb5.setObjectName("lb5")
        ui.lb5_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb5_2.setGeometry(QtCore.QRect(490, 106, 261, 30))
        ui.lb5_2.setObjectName("lb5_2")
        ui.lb6_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb6_2.setGeometry(QtCore.QRect(490, 10, 261, 30))
        ui.lb6_2.setObjectName("lb6_2")
        ui.lb6 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb6.setGeometry(QtCore.QRect(140, 10, 61, 30))
        ui.lb6.setObjectName("lb6")
        ui.pb6 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb6.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb6.setMouseTracking(False)
        ui.pb6.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)
        ui.pb6.setObjectName("pb6")
        ui.pb2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb2.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb2.setToolTipDuration(3)
        ui.pb2.setObjectName("pb2")
        ui.lb2_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb2_2.setGeometry(QtCore.QRect(490, 74, 281, 30))
        ui.lb2_2.setObjectName("lb2_2")
        ui.lb2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb2.setGeometry(QtCore.QRect(140, 74, 71, 30))
        ui.lb2.setObjectName("lb2")
        ui.pb9 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb9.setGeometry(QtCore.QRect(10, 170, 41, 34))
        ui.pb9.setObjectName("pb9")
        ui.lb9_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb9_2.setGeometry(QtCore.QRect(490, 170, 271, 30))
        ui.lb9_2.setObjectName("lb9_2")
        ui.lb9 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb9.setGeometry(QtCore.QRect(140, 170, 61, 30))
        ui.lb9.setObjectName("lb9")
        ui.pb10 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb10.setGeometry(QtCore.QRect(10, 202, 41, 34))
        ui.pb10.setObjectName("pb10")
        ui.lb10 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb10.setGeometry(QtCore.QRect(140, 202, 71, 30))
        ui.lb10.setObjectName("lb10")
        ui.lb10_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb10_2.setGeometry(QtCore.QRect(490, 202, 261, 30))
        ui.lb10_2.setObjectName("lb10_2")
        ui.pb11 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb11.setGeometry(QtCore.QRect(10, 266, 41, 34))
        ui.pb11.setObjectName("pb11")
        ui.lb11 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb11.setGeometry(QtCore.QRect(140, 266, 111, 30))
        ui.lb11.setObjectName("lb11")
        ui.lb11_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb11_2.setGeometry(QtCore.QRect(490, 266, 362, 30))
        ui.lb11_2.setObjectName("lb11_2")
        ui.pb12 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb12.setGeometry(QtCore.QRect(10, 298, 41, 34))
        ui.pb12.setObjectName("pb12")
        ui.lb12 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb12.setGeometry(QtCore.QRect(140, 298, 61, 30))
        ui.lb12.setObjectName("lb12")
        ui.lb12_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb12_2.setGeometry(QtCore.QRect(490, 298, 261, 30))
        ui.lb12_2.setObjectName("lb12_2")
        ui.pb86 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb86.setGeometry(QtCore.QRect(10, 234, 41, 34))
        ui.pb86.setObjectName("pb86")
        ui.lb86_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb86_2.setGeometry(QtCore.QRect(490, 234, 281, 30))
        ui.lb86_2.setObjectName("lb86_2")
        ui.lb86 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb86.setGeometry(QtCore.QRect(140, 234, 81, 30))
        ui.lb86.setObjectName("lb86")
        ui.cb86 = QtWidgets.QComboBox(parent=ui.tab_1)
        ui.cb86.setGeometry(QtCore.QRect(230, 234, 241, 32))
        ui.cb86.setStyleSheet("")
        ui.cb86.setEditable(False)
        ui.cb86.setObjectName("cb86")
        ui.cb5 = QtWidgets.QComboBox(parent=ui.tab_1)
        ui.cb5.setGeometry(QtCore.QRect(230, 106, 241, 32))
        ui.cb5.setStyleSheet("")
        ui.cb5.setEditable(False)
        ui.cb5.setObjectName("cb5")
        ui.pb2_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb2_2.setGeometry(QtCore.QRect(60, 74, 41, 34))
        ui.pb2_2.setToolTipDuration(3)
        ui.pb2_2.setObjectName("pb2_2")
        ui.pb5_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb5_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb5_2.setObjectName("pb5_2")
        ui.pb86_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb86_2.setGeometry(QtCore.QRect(60, 234, 41, 34))
        ui.pb86_2.setObjectName("pb86_2")
        ui.pb12_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb12_2.setGeometry(QtCore.QRect(60, 298, 41, 34))
        ui.pb12_2.setObjectName("pb12_2")
        ui.pb6_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb6_2.setGeometry(QtCore.QRect(60, 10, 41, 34))
        ui.pb6_2.setMouseTracking(False)
        ui.pb6_2.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)
        ui.pb6_2.setObjectName("pb6_2")
        ui.pb10_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb10_2.setGeometry(QtCore.QRect(60, 202, 41, 34))
        ui.pb10_2.setObjectName("pb10_2")
        ui.pb9_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb9_2.setGeometry(QtCore.QRect(60, 170, 41, 34))
        ui.pb9_2.setObjectName("pb9_2")
        ui.pb11_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb11_2.setGeometry(QtCore.QRect(60, 266, 41, 34))
        ui.pb11_2.setObjectName("pb11_2")
        ui.cb6 = QtWidgets.QComboBox(parent=ui.tab_1)
        ui.cb6.setGeometry(QtCore.QRect(230, 10, 241, 32))
        ui.cb6.setEditable(False)
        ui.cb6.setObjectName("cb6")
        ui.lb101_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb101_2.setGeometry(QtCore.QRect(490, 42, 261, 30))
        ui.lb101_2.setObjectName("lb101_2")
        ui.pb101 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb101.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb101.setMouseTracking(False)
        ui.pb101.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)
        ui.pb101.setObjectName("pb101")
        ui.pb101_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb101_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb101_2.setMouseTracking(False)
        ui.pb101_2.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.NoContextMenu)
        ui.pb101_2.setObjectName("pb101_2")
        ui.lb101 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb101.setGeometry(QtCore.QRect(140, 42, 81, 30))
        ui.lb101.setObjectName("lb101")
        ui.cb101 = QtWidgets.QComboBox(parent=ui.tab_1)
        ui.cb101.setGeometry(QtCore.QRect(230, 42, 241, 32))
        ui.cb101.setStyleSheet("")
        ui.cb101.setEditable(False)
        ui.cb101.setObjectName("cb101")
        ui.pb9_4 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb9_4.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb9_4.setObjectName("pb9_4")
        ui.lb9_3 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb9_3.setGeometry(QtCore.QRect(140, 138, 71, 30))
        ui.lb9_3.setObjectName("lb9_3")
        ui.lb9_4 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb9_4.setGeometry(QtCore.QRect(490, 138, 261, 30))
        ui.lb9_4.setObjectName("lb9_4")
        ui.lb13 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb13.setGeometry(QtCore.QRect(140, 330, 61, 30))
        ui.lb13.setObjectName("lb13")
        ui.pb13_2 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb13_2.setGeometry(QtCore.QRect(60, 330, 41, 34))
        ui.pb13_2.setObjectName("pb13_2")
        ui.lb13_2 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb13_2.setGeometry(QtCore.QRect(490, 330, 261, 30))
        ui.lb13_2.setObjectName("lb13_2")
        ui.cb13 = QtWidgets.QComboBox(parent=ui.tab_1)
        ui.cb13.setGeometry(QtCore.QRect(230, 330, 241, 32))
        ui.cb13.setStyleSheet("")
        ui.cb13.setEditable(False)
        ui.cb13.setObjectName("cb13")
        ui.pb13 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb13.setGeometry(QtCore.QRect(10, 330, 41, 34))
        ui.pb13.setObjectName("pb13")
        ui.lb13_3 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb13_3.setGeometry(QtCore.QRect(490, 362, 261, 30))
        ui.lb13_3.setObjectName("lb13_3")
        ui.pb13_3 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb13_3.setGeometry(QtCore.QRect(60, 362, 41, 34))
        ui.pb13_3.setObjectName("pb13_3")
        ui.lb13_4 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb13_4.setGeometry(QtCore.QRect(140, 362, 61, 30))
        ui.lb13_4.setObjectName("lb13_4")
        ui.pb13_4 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb13_4.setGeometry(QtCore.QRect(10, 362, 41, 34))
        ui.pb13_4.setObjectName("pb13_4")
        ui.cb13_2 = QtWidgets.QComboBox(parent=ui.tab_1)
        ui.cb13_2.setGeometry(QtCore.QRect(230, 362, 241, 32))
        ui.cb13_2.setStyleSheet("")
        ui.cb13_2.setEditable(False)
        ui.cb13_2.setObjectName("cb13_2")
        ui.pb14_3 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb14_3.setGeometry(QtCore.QRect(60, 394, 41, 34))
        ui.pb14_3.setObjectName("pb14_3")
        ui.lb14_3 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb14_3.setGeometry(QtCore.QRect(490, 394, 261, 30))
        ui.lb14_3.setObjectName("lb14_3")
        ui.lb14_4 = QtWidgets.QLabel(parent=ui.tab_1)
        ui.lb14_4.setGeometry(QtCore.QRect(140, 394, 61, 30))
        ui.lb14_4.setObjectName("lb14_4")
        ui.pb14_4 = QtWidgets.QPushButton(parent=ui.tab_1)
        ui.pb14_4.setGeometry(QtCore.QRect(10, 394, 41, 34))
        ui.pb14_4.setObjectName("pb14_4")
        ui.tabWidget.addTab(ui.tab_1, "")
        ui.tab_2 = QtWidgets.QWidget()
        ui.tab_2.setObjectName("tab_2")
        ui.pb15 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb15.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb15.setObjectName("pb15")
        ui.lb15 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb15.setGeometry(QtCore.QRect(140, 10, 84, 30))
        ui.lb15.setObjectName("lb15")
        ui.lb15_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb15_2.setGeometry(QtCore.QRect(490, 10, 261, 30))
        ui.lb15_2.setObjectName("lb15_2")
        ui.cb15 = QtWidgets.QComboBox(parent=ui.tab_2)
        ui.cb15.setGeometry(QtCore.QRect(230, 10, 241, 32))
        ui.cb15.setStyleSheet("")
        ui.cb15.setObjectName("cb15")
        ui.lb16_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb16_2.setGeometry(QtCore.QRect(490, 42, 261, 30))
        ui.lb16_2.setObjectName("lb16_2")
        ui.lb16 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb16.setGeometry(QtCore.QRect(140, 42, 61, 30))
        ui.lb16.setObjectName("lb16")
        ui.pb16 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb16.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb16.setObjectName("pb16")
        ui.lb17_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb17_2.setGeometry(QtCore.QRect(490, 74, 261, 30))
        ui.lb17_2.setObjectName("lb17_2")
        ui.lb17 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb17.setGeometry(QtCore.QRect(140, 74, 121, 30))
        ui.lb17.setObjectName("lb17")
        ui.pb17 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb17.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb17.setObjectName("pb17")
        ui.pb18 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb18.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb18.setObjectName("pb18")
        ui.lb18 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb18.setGeometry(QtCore.QRect(140, 138, 61, 30))
        ui.lb18.setObjectName("lb18")
        ui.lb18_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb18_2.setGeometry(QtCore.QRect(490, 138, 261, 30))
        ui.lb18_2.setObjectName("lb18_2")
        ui.pb19 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb19.setGeometry(QtCore.QRect(10, 170, 41, 34))
        ui.pb19.setObjectName("pb19")
        ui.lb19 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb19.setGeometry(QtCore.QRect(140, 170, 91, 30))
        ui.lb19.setObjectName("lb19")
        ui.lb19_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb19_2.setGeometry(QtCore.QRect(490, 170, 261, 30))
        ui.lb19_2.setObjectName("lb19_2")
        ui.lb20_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb20_2.setGeometry(QtCore.QRect(490, 202, 261, 30))
        ui.lb20_2.setObjectName("lb20_2")
        ui.lb20 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb20.setGeometry(QtCore.QRect(140, 202, 51, 30))
        ui.lb20.setObjectName("lb20")
        ui.pb20 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb20.setGeometry(QtCore.QRect(10, 202, 41, 34))
        ui.pb20.setObjectName("pb20")
        ui.lb21 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb21.setGeometry(QtCore.QRect(140, 234, 71, 30))
        ui.lb21.setObjectName("lb21")
        ui.lb21_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb21_2.setGeometry(QtCore.QRect(490, 234, 271, 30))
        ui.lb21_2.setObjectName("lb21_2")
        ui.pb21 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb21.setGeometry(QtCore.QRect(10, 234, 41, 34))
        ui.pb21.setObjectName("pb21")
        ui.pb22 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb22.setGeometry(QtCore.QRect(10, 266, 41, 34))
        ui.pb22.setObjectName("pb22")
        ui.lb22 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb22.setGeometry(QtCore.QRect(140, 266, 81, 30))
        ui.lb22.setObjectName("lb22")
        ui.lb22_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb22_2.setGeometry(QtCore.QRect(490, 266, 281, 30))
        ui.lb22_2.setObjectName("lb22_2")
        ui.lb23_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb23_2.setGeometry(QtCore.QRect(490, 298, 261, 30))
        ui.lb23_2.setObjectName("lb23_2")
        ui.lb23 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb23.setGeometry(QtCore.QRect(140, 298, 91, 30))
        ui.lb23.setObjectName("lb23")
        ui.pb23 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb23.setGeometry(QtCore.QRect(10, 298, 41, 34))
        ui.pb23.setObjectName("pb23")
        ui.cb22 = QtWidgets.QComboBox(parent=ui.tab_2)
        ui.cb22.setGeometry(QtCore.QRect(230, 266, 241, 32))
        ui.cb22.setStyleSheet("")
        ui.cb22.setObjectName("cb22")
        ui.cb23 = QtWidgets.QComboBox(parent=ui.tab_2)
        ui.cb23.setGeometry(QtCore.QRect(230, 298, 241, 32))
        ui.cb23.setStyleSheet("")
        ui.cb23.setObjectName("cb23")
        ui.pb24 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb24.setGeometry(QtCore.QRect(10, 330, 41, 34))
        ui.pb24.setObjectName("pb24")
        ui.lb24 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb24.setGeometry(QtCore.QRect(140, 330, 71, 30))
        ui.lb24.setObjectName("lb24")
        ui.lb24_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb24_2.setGeometry(QtCore.QRect(490, 330, 261, 30))
        ui.lb24_2.setObjectName("lb24_2")
        ui.lb93_3 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb93_3.setGeometry(QtCore.QRect(140, 362, 81, 30))
        ui.lb93_3.setObjectName("lb93_3")
        ui.lb93_4 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb93_4.setGeometry(QtCore.QRect(490, 362, 281, 30))
        ui.lb93_4.setObjectName("lb93_4")
        ui.pb93 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb93.setGeometry(QtCore.QRect(10, 362, 41, 34))
        ui.pb93.setObjectName("pb93")
        ui.pb93_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb93_2.setGeometry(QtCore.QRect(60, 362, 41, 34))
        ui.pb93_2.setObjectName("pb93_2")
        ui.pb24_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb24_2.setGeometry(QtCore.QRect(60, 330, 41, 34))
        ui.pb24_2.setObjectName("pb24_2")
        ui.pb16_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb16_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb16_2.setObjectName("pb16_2")
        ui.pb15_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb15_2.setGeometry(QtCore.QRect(60, 10, 41, 34))
        ui.pb15_2.setObjectName("pb15_2")
        ui.pb20_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb20_2.setGeometry(QtCore.QRect(60, 202, 41, 34))
        ui.pb20_2.setObjectName("pb20_2")
        ui.pb21_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb21_2.setGeometry(QtCore.QRect(60, 234, 41, 34))
        ui.pb21_2.setObjectName("pb21_2")
        ui.pb23_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb23_2.setGeometry(QtCore.QRect(60, 298, 41, 34))
        ui.pb23_2.setObjectName("pb23_2")
        ui.pb18_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb18_2.setGeometry(QtCore.QRect(60, 138, 41, 34))
        ui.pb18_2.setObjectName("pb18_2")
        ui.pb19_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb19_2.setGeometry(QtCore.QRect(60, 170, 41, 34))
        ui.pb19_2.setObjectName("pb19_2")
        ui.pb22_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb22_2.setGeometry(QtCore.QRect(60, 266, 41, 34))
        ui.pb22_2.setObjectName("pb22_2")
        ui.pb102_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb102_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb102_2.setObjectName("pb102_2")
        ui.lb102 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb102.setGeometry(QtCore.QRect(140, 106, 51, 30))
        ui.lb102.setObjectName("lb102")
        ui.cb102 = QtWidgets.QComboBox(parent=ui.tab_2)
        ui.cb102.setGeometry(QtCore.QRect(230, 106, 241, 32))
        ui.cb102.setStyleSheet("")
        ui.cb102.setObjectName("cb102")
        ui.pb102 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb102.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb102.setObjectName("pb102")
        ui.lb102_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb102_2.setGeometry(QtCore.QRect(490, 106, 261, 30))
        ui.lb102_2.setObjectName("lb102_2")
        ui.pb25 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb25.setGeometry(QtCore.QRect(10, 394, 41, 34))
        ui.pb25.setObjectName("pb25")
        ui.pb25_2 = QtWidgets.QPushButton(parent=ui.tab_2)
        ui.pb25_2.setGeometry(QtCore.QRect(60, 394, 41, 34))
        ui.pb25_2.setObjectName("pb25_2")
        ui.lb25_2 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb25_2.setGeometry(QtCore.QRect(490, 394, 261, 30))
        ui.lb25_2.setObjectName("lb25_2")
        ui.lb25 = QtWidgets.QLabel(parent=ui.tab_2)
        ui.lb25.setGeometry(QtCore.QRect(140, 394, 111, 30))
        ui.lb25.setObjectName("lb25")
        ui.tabWidget.addTab(ui.tab_2, "")
        ui.tab_3 = QtWidgets.QWidget()
        ui.tab_3.setObjectName("tab_3")
        ui.lb26 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb26.setGeometry(QtCore.QRect(140, 10, 61, 30))
        ui.lb26.setObjectName("lb26")
        ui.pb26 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb26.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb26.setObjectName("pb26")
        ui.lb26_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb26_2.setGeometry(QtCore.QRect(490, 10, 261, 30))
        ui.lb26_2.setObjectName("lb26_2")
        ui.lb27_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb27_2.setGeometry(QtCore.QRect(490, 42, 261, 30))
        ui.lb27_2.setObjectName("lb27_2")
        ui.lb27 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb27.setGeometry(QtCore.QRect(140, 42, 51, 30))
        ui.lb27.setObjectName("lb27")
        ui.pb27 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb27.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb27.setObjectName("pb27")
        ui.lb28_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb28_2.setGeometry(QtCore.QRect(490, 138, 261, 30))
        ui.lb28_2.setObjectName("lb28_2")
        ui.lb28 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb28.setGeometry(QtCore.QRect(140, 138, 71, 30))
        ui.lb28.setObjectName("lb28")
        ui.pb28 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb28.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb28.setObjectName("pb28")
        ui.pb29 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb29.setGeometry(QtCore.QRect(10, 170, 41, 34))
        ui.pb29.setObjectName("pb29")
        ui.lb29_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb29_2.setGeometry(QtCore.QRect(490, 170, 261, 30))
        ui.lb29_2.setObjectName("lb29_2")
        ui.lb29 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb29.setGeometry(QtCore.QRect(140, 170, 131, 30))
        ui.lb29.setObjectName("lb29")
        ui.lb30 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb30.setGeometry(QtCore.QRect(140, 202, 51, 30))
        ui.lb30.setObjectName("lb30")
        ui.pb30 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb30.setGeometry(QtCore.QRect(10, 202, 41, 34))
        ui.pb30.setObjectName("pb30")
        ui.lb30_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb30_2.setGeometry(QtCore.QRect(490, 202, 261, 30))
        ui.lb30_2.setObjectName("lb30_2")
        ui.lb31 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb31.setGeometry(QtCore.QRect(140, 234, 61, 30))
        ui.lb31.setObjectName("lb31")
        ui.pb31 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb31.setGeometry(QtCore.QRect(10, 234, 41, 34))
        ui.pb31.setObjectName("pb31")
        ui.lb31_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb31_2.setGeometry(QtCore.QRect(490, 234, 261, 30))
        ui.lb31_2.setObjectName("lb31_2")
        ui.lb32_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb32_2.setGeometry(QtCore.QRect(490, 266, 261, 30))
        ui.lb32_2.setObjectName("lb32_2")
        ui.lb32 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb32.setGeometry(QtCore.QRect(140, 266, 91, 30))
        ui.lb32.setObjectName("lb32")
        ui.pb32 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb32.setGeometry(QtCore.QRect(10, 266, 41, 34))
        ui.pb32.setObjectName("pb32")
        ui.lb33_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb33_2.setGeometry(QtCore.QRect(490, 362, 261, 30))
        ui.lb33_2.setObjectName("lb33_2")
        ui.pb33 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb33.setGeometry(QtCore.QRect(10, 362, 41, 34))
        ui.pb33.setObjectName("pb33")
        ui.lb33 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb33.setGeometry(QtCore.QRect(140, 362, 81, 30))
        ui.lb33.setObjectName("lb33")
        ui.cb33 = QtWidgets.QComboBox(parent=ui.tab_3)
        ui.cb33.setGeometry(QtCore.QRect(230, 362, 241, 32))
        ui.cb33.setStyleSheet("")
        ui.cb33.setObjectName("cb33")
        ui.lb27_3 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb27_3.setGeometry(QtCore.QRect(140, 74, 81, 30))
        ui.lb27_3.setObjectName("lb27_3")
        ui.pb89 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb89.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb89.setObjectName("pb89")
        ui.lb27_4 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb27_4.setGeometry(QtCore.QRect(490, 74, 281, 30))
        ui.lb27_4.setObjectName("lb27_4")
        ui.pb91 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb91.setGeometry(QtCore.QRect(10, 394, 41, 34))
        ui.pb91.setObjectName("pb91")
        ui.lb91_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb91_2.setGeometry(QtCore.QRect(490, 394, 261, 30))
        ui.lb91_2.setObjectName("lb91_2")
        ui.lb91 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb91.setGeometry(QtCore.QRect(140, 394, 101, 30))
        ui.lb91.setObjectName("lb91")
        ui.pb89_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb89_2.setGeometry(QtCore.QRect(60, 74, 41, 34))
        ui.pb89_2.setObjectName("pb89_2")
        ui.pb28_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb28_2.setGeometry(QtCore.QRect(60, 138, 41, 34))
        ui.pb28_2.setObjectName("pb28_2")
        ui.pb30_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb30_2.setGeometry(QtCore.QRect(60, 202, 41, 34))
        ui.pb30_2.setObjectName("pb30_2")
        ui.pb91_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb91_2.setGeometry(QtCore.QRect(60, 394, 41, 34))
        ui.pb91_2.setObjectName("pb91_2")
        ui.pb31_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb31_2.setGeometry(QtCore.QRect(60, 234, 41, 34))
        ui.pb31_2.setObjectName("pb31_2")
        ui.pb29_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb29_2.setGeometry(QtCore.QRect(60, 170, 41, 34))
        ui.pb29_2.setObjectName("pb29_2")
        ui.pb32_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb32_2.setGeometry(QtCore.QRect(60, 266, 41, 34))
        ui.pb32_2.setObjectName("pb32_2")
        ui.pb26_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb26_2.setGeometry(QtCore.QRect(60, 10, 41, 34))
        ui.pb26_2.setObjectName("pb26_2")
        ui.pb33_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb33_2.setGeometry(QtCore.QRect(60, 362, 41, 34))
        ui.pb33_2.setObjectName("pb33_2")
        ui.pb27_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb27_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb27_2.setObjectName("pb27_2")
        ui.lb103_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb103_2.setGeometry(QtCore.QRect(490, 298, 281, 30))
        ui.lb103_2.setObjectName("lb103_2")
        ui.pb103 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb103.setGeometry(QtCore.QRect(10, 298, 41, 34))
        ui.pb103.setObjectName("pb103")
        ui.pb103_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb103_2.setGeometry(QtCore.QRect(60, 298, 41, 34))
        ui.pb103_2.setObjectName("pb103_2")
        ui.lb103 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb103.setGeometry(QtCore.QRect(140, 298, 71, 30))
        ui.lb103.setObjectName("lb103")
        ui.lb106_2 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb106_2.setGeometry(QtCore.QRect(490, 106, 261, 30))
        ui.lb106_2.setObjectName("lb106_2")
        ui.pb106 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb106.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb106.setObjectName("pb106")
        ui.pb106_2 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb106_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb106_2.setObjectName("pb106_2")
        ui.lb106 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb106.setGeometry(QtCore.QRect(140, 106, 101, 30))
        ui.lb106.setObjectName("lb106")
        ui.lb91_3 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb91_3.setGeometry(QtCore.QRect(490, 330, 261, 30))
        ui.lb91_3.setObjectName("lb91_3")
        ui.pb91_3 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb91_3.setGeometry(QtCore.QRect(10, 330, 41, 34))
        ui.pb91_3.setObjectName("pb91_3")
        ui.pb91_4 = QtWidgets.QPushButton(parent=ui.tab_3)
        ui.pb91_4.setGeometry(QtCore.QRect(60, 330, 41, 34))
        ui.pb91_4.setObjectName("pb91_4")
        ui.lb91_4 = QtWidgets.QLabel(parent=ui.tab_3)
        ui.lb91_4.setGeometry(QtCore.QRect(140, 330, 101, 30))
        ui.lb91_4.setObjectName("lb91_4")
        ui.tabWidget.addTab(ui.tab_3, "")
        ui.tab_4 = QtWidgets.QWidget()
        ui.tab_4.setObjectName("tab_4")
        ui.cb37 = QtWidgets.QComboBox(parent=ui.tab_4)
        ui.cb37.setGeometry(QtCore.QRect(230, 106, 241, 32))
        ui.cb37.setStyleSheet("")
        ui.cb37.setObjectName("cb37")
        ui.lb37_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb37_2.setGeometry(QtCore.QRect(490, 106, 281, 30))
        ui.lb37_2.setObjectName("lb37_2")
        ui.pb37 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb37.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb37.setObjectName("pb37")
        ui.lb37 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb37.setGeometry(QtCore.QRect(140, 106, 71, 30))
        ui.lb37.setObjectName("lb37")
        ui.pb38 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb38.setGeometry(QtCore.QRect(10, 170, 41, 34))
        ui.pb38.setObjectName("pb38")
        ui.lb38_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb38_2.setGeometry(QtCore.QRect(490, 170, 261, 30))
        ui.lb38_2.setObjectName("lb38_2")
        ui.cb38 = QtWidgets.QComboBox(parent=ui.tab_4)
        ui.cb38.setGeometry(QtCore.QRect(230, 170, 241, 32))
        ui.cb38.setStyleSheet("")
        ui.cb38.setObjectName("cb38")
        ui.lb38 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb38.setGeometry(QtCore.QRect(140, 170, 71, 30))
        ui.lb38.setObjectName("lb38")
        ui.lb42_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb42_2.setGeometry(QtCore.QRect(490, 234, 261, 30))
        ui.lb42_2.setObjectName("lb42_2")
        ui.lb42 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb42.setGeometry(QtCore.QRect(140, 234, 71, 30))
        ui.lb42.setObjectName("lb42")
        ui.pb42 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb42.setGeometry(QtCore.QRect(10, 234, 41, 34))
        ui.pb42.setObjectName("pb42")
        ui.pb40 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb40.setGeometry(QtCore.QRect(10, 266, 41, 34))
        ui.pb40.setObjectName("pb40")
        ui.lb40 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb40.setGeometry(QtCore.QRect(140, 266, 61, 30))
        ui.lb40.setObjectName("lb40")
        ui.lb40_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb40_2.setGeometry(QtCore.QRect(490, 266, 261, 30))
        ui.lb40_2.setObjectName("lb40_2")
        ui.cb40 = QtWidgets.QComboBox(parent=ui.tab_4)
        ui.cb40.setGeometry(QtCore.QRect(230, 266, 241, 32))
        ui.cb40.setStyleSheet("")
        ui.cb40.setObjectName("cb40")
        ui.pb44 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb44.setGeometry(QtCore.QRect(10, 298, 41, 34))
        ui.pb44.setObjectName("pb44")
        ui.lb44 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb44.setGeometry(QtCore.QRect(140, 298, 71, 30))
        ui.lb44.setObjectName("lb44")
        ui.lb44_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb44_2.setGeometry(QtCore.QRect(490, 298, 261, 30))
        ui.lb44_2.setObjectName("lb44_2")
        ui.cb44 = QtWidgets.QComboBox(parent=ui.tab_4)
        ui.cb44.setGeometry(QtCore.QRect(230, 298, 241, 32))
        ui.cb44.setStyleSheet("")
        ui.cb44.setObjectName("cb44")
        ui.lb45_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb45_2.setGeometry(QtCore.QRect(490, 330, 261, 30))
        ui.lb45_2.setObjectName("lb45_2")
        ui.lb45 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb45.setGeometry(QtCore.QRect(140, 330, 71, 30))
        ui.lb45.setObjectName("lb45")
        ui.pb45 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb45.setGeometry(QtCore.QRect(10, 330, 41, 34))
        ui.pb45.setObjectName("pb45")
        ui.lb46_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb46_2.setGeometry(QtCore.QRect(490, 362, 261, 30))
        ui.lb46_2.setObjectName("lb46_2")
        ui.lb46 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb46.setGeometry(QtCore.QRect(140, 362, 61, 30))
        ui.lb46.setObjectName("lb46")
        ui.pb46 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb46.setGeometry(QtCore.QRect(10, 362, 41, 34))
        ui.pb46.setObjectName("pb46")
        ui.lb47_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb47_2.setGeometry(QtCore.QRect(490, 394, 261, 30))
        ui.lb47_2.setObjectName("lb47_2")
        ui.pb47 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb47.setGeometry(QtCore.QRect(10, 394, 41, 34))
        ui.pb47.setObjectName("pb47")
        ui.lb47 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb47.setGeometry(QtCore.QRect(140, 394, 51, 30))
        ui.lb47.setObjectName("lb47")
        ui.cb36 = QtWidgets.QComboBox(parent=ui.tab_4)
        ui.cb36.setGeometry(QtCore.QRect(230, 74, 241, 32))
        ui.cb36.setStyleSheet("")
        ui.cb36.setObjectName("cb36")
        ui.lb36_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb36_2.setGeometry(QtCore.QRect(490, 74, 261, 30))
        ui.lb36_2.setObjectName("lb36_2")
        ui.lb36 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb36.setGeometry(QtCore.QRect(140, 74, 71, 30))
        ui.lb36.setObjectName("lb36")
        ui.pb36 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb36.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb36.setObjectName("pb36")
        ui.lb35 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb35.setGeometry(QtCore.QRect(140, 42, 101, 30))
        ui.lb35.setObjectName("lb35")
        ui.lb35_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb35_2.setGeometry(QtCore.QRect(490, 42, 271, 30))
        ui.lb35_2.setObjectName("lb35_2")
        ui.pb35 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb35.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb35.setObjectName("pb35")
        ui.lb48_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb48_2.setGeometry(QtCore.QRect(490, 426, 261, 30))
        ui.lb48_2.setObjectName("lb48_2")
        ui.pb48 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb48.setGeometry(QtCore.QRect(10, 426, 41, 34))
        ui.pb48.setStyleSheet("")
        ui.pb48.setObjectName("pb48")
        ui.lb48 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb48.setGeometry(QtCore.QRect(140, 426, 61, 30))
        ui.lb48.setObjectName("lb48")
        ui.pb42_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb42_2.setGeometry(QtCore.QRect(60, 234, 41, 34))
        ui.pb42_2.setObjectName("pb42_2")
        ui.pb35_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb35_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb35_2.setObjectName("pb35_2")
        ui.pb47_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb47_2.setGeometry(QtCore.QRect(60, 394, 41, 34))
        ui.pb47_2.setObjectName("pb47_2")
        ui.pb37_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb37_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb37_2.setObjectName("pb37_2")
        ui.pb44_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb44_2.setGeometry(QtCore.QRect(60, 298, 41, 34))
        ui.pb44_2.setObjectName("pb44_2")
        ui.pb40_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb40_2.setGeometry(QtCore.QRect(60, 266, 41, 34))
        ui.pb40_2.setObjectName("pb40_2")
        ui.pb46_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb46_2.setGeometry(QtCore.QRect(60, 362, 41, 34))
        ui.pb46_2.setObjectName("pb46_2")
        ui.pb48_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb48_2.setGeometry(QtCore.QRect(60, 426, 41, 34))
        ui.pb48_2.setStyleSheet("")
        ui.pb48_2.setObjectName("pb48_2")
        ui.pb38_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb38_2.setGeometry(QtCore.QRect(60, 170, 41, 34))
        ui.pb38_2.setObjectName("pb38_2")
        ui.pb36_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb36_2.setGeometry(QtCore.QRect(60, 74, 41, 34))
        ui.pb36_2.setObjectName("pb36_2")
        ui.pb45_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb45_2.setGeometry(QtCore.QRect(60, 330, 41, 34))
        ui.pb45_2.setObjectName("pb45_2")
        ui.pb34_2 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb34_2.setGeometry(QtCore.QRect(60, 10, 41, 34))
        ui.pb34_2.setObjectName("pb34_2")
        ui.lb34_2 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb34_2.setGeometry(QtCore.QRect(490, 10, 261, 30))
        ui.lb34_2.setObjectName("lb34_2")
        ui.lb34 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb34.setGeometry(QtCore.QRect(140, 10, 101, 30))
        ui.lb34.setObjectName("lb34")
        ui.pb34 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb34.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb34.setObjectName("pb34")
        ui.lb47_3 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb47_3.setGeometry(QtCore.QRect(140, 202, 101, 30))
        ui.lb47_3.setObjectName("lb47_3")
        ui.pb47_3 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb47_3.setGeometry(QtCore.QRect(60, 202, 41, 34))
        ui.pb47_3.setObjectName("pb47_3")
        ui.pb47_4 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb47_4.setGeometry(QtCore.QRect(10, 202, 41, 34))
        ui.pb47_4.setObjectName("pb47_4")
        ui.lb47_4 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb47_4.setGeometry(QtCore.QRect(490, 202, 261, 30))
        ui.lb47_4.setObjectName("lb47_4")
        ui.lb35_3 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb35_3.setGeometry(QtCore.QRect(490, 138, 271, 30))
        ui.lb35_3.setObjectName("lb35_3")
        ui.lb35_4 = QtWidgets.QLabel(parent=ui.tab_4)
        ui.lb35_4.setGeometry(QtCore.QRect(140, 138, 101, 30))
        ui.lb35_4.setObjectName("lb35_4")
        ui.pb35_3 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb35_3.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb35_3.setObjectName("pb35_3")
        ui.pb35_4 = QtWidgets.QPushButton(parent=ui.tab_4)
        ui.pb35_4.setGeometry(QtCore.QRect(60, 138, 41, 34))
        ui.pb35_4.setObjectName("pb35_4")
        ui.tabWidget.addTab(ui.tab_4, "")
        ui.tab_5 = QtWidgets.QWidget()
        ui.tab_5.setObjectName("tab_5")
        ui.lb49 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb49.setGeometry(QtCore.QRect(140, 74, 71, 30))
        ui.lb49.setObjectName("lb49")
        ui.lb49_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb49_2.setGeometry(QtCore.QRect(490, 74, 261, 30))
        ui.lb49_2.setObjectName("lb49_2")
        ui.pb49 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb49.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb49.setObjectName("pb49")
        ui.lb50 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb50.setGeometry(QtCore.QRect(140, 106, 61, 30))
        ui.lb50.setObjectName("lb50")
        ui.lb50_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb50_2.setGeometry(QtCore.QRect(490, 106, 261, 30))
        ui.lb50_2.setObjectName("lb50_2")
        ui.pb50 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb50.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb50.setObjectName("pb50")
        ui.lb51_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb51_2.setGeometry(QtCore.QRect(490, 138, 261, 30))
        ui.lb51_2.setObjectName("lb51_2")
        ui.lb51 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb51.setGeometry(QtCore.QRect(140, 138, 51, 30))
        ui.lb51.setObjectName("lb51")
        ui.pb51 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb51.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb51.setObjectName("pb51")
        ui.lb52_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb52_2.setGeometry(QtCore.QRect(490, 170, 261, 30))
        ui.lb52_2.setObjectName("lb52_2")
        ui.lb52 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb52.setGeometry(QtCore.QRect(140, 170, 81, 30))
        ui.lb52.setObjectName("lb52")
        ui.pb52 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb52.setGeometry(QtCore.QRect(10, 170, 41, 34))
        ui.pb52.setObjectName("pb52")
        ui.pb55 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb55.setGeometry(QtCore.QRect(10, 266, 41, 34))
        ui.pb55.setObjectName("pb55")
        ui.lb55 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb55.setGeometry(QtCore.QRect(140, 266, 71, 30))
        ui.lb55.setObjectName("lb55")
        ui.lb55_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb55_2.setGeometry(QtCore.QRect(490, 266, 261, 30))
        ui.lb55_2.setObjectName("lb55_2")
        ui.pb57 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb57.setGeometry(QtCore.QRect(10, 298, 41, 34))
        ui.pb57.setObjectName("pb57")
        ui.lb57_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb57_2.setGeometry(QtCore.QRect(490, 298, 261, 30))
        ui.lb57_2.setObjectName("lb57_2")
        ui.lb57 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb57.setGeometry(QtCore.QRect(140, 298, 71, 30))
        ui.lb57.setObjectName("lb57")
        ui.cb57 = QtWidgets.QComboBox(parent=ui.tab_5)
        ui.cb57.setGeometry(QtCore.QRect(230, 298, 241, 32))
        ui.cb57.setStyleSheet("")
        ui.cb57.setObjectName("cb57")
        ui.lb58_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb58_2.setGeometry(QtCore.QRect(490, 330, 281, 30))
        ui.lb58_2.setObjectName("lb58_2")
        ui.pb58 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb58.setGeometry(QtCore.QRect(10, 330, 41, 34))
        ui.pb58.setObjectName("pb58")
        ui.lb58 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb58.setGeometry(QtCore.QRect(140, 330, 201, 30))
        ui.lb58.setObjectName("lb58")
        ui.lb84 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb84.setGeometry(QtCore.QRect(140, 234, 151, 30))
        ui.lb84.setObjectName("lb84")
        ui.pb84 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb84.setGeometry(QtCore.QRect(10, 234, 41, 34))
        ui.pb84.setObjectName("pb84")
        ui.lb84_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb84_2.setGeometry(QtCore.QRect(490, 234, 271, 30))
        ui.lb84_2.setObjectName("lb84_2")
        ui.lb87 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb87.setGeometry(QtCore.QRect(140, 362, 61, 30))
        ui.lb87.setObjectName("lb87")
        ui.lb87_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb87_2.setGeometry(QtCore.QRect(490, 362, 261, 30))
        ui.lb87_2.setObjectName("lb87_2")
        ui.pb87 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb87.setGeometry(QtCore.QRect(10, 362, 41, 34))
        ui.pb87.setObjectName("pb87")
        ui.lb90 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb90.setGeometry(QtCore.QRect(140, 42, 51, 30))
        ui.lb90.setObjectName("lb90")
        ui.pb90 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb90.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb90.setObjectName("pb90")
        ui.lb90_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb90_2.setGeometry(QtCore.QRect(490, 42, 261, 30))
        ui.lb90_2.setObjectName("lb90_2")
        ui.cb52 = QtWidgets.QComboBox(parent=ui.tab_5)
        ui.cb52.setGeometry(QtCore.QRect(230, 170, 241, 32))
        ui.cb52.setStyleSheet("")
        ui.cb52.setObjectName("cb52")
        ui.pb94 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb94.setGeometry(QtCore.QRect(10, 202, 41, 34))
        ui.pb94.setObjectName("pb94")
        ui.lb94 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb94.setGeometry(QtCore.QRect(140, 202, 81, 30))
        ui.lb94.setObjectName("lb94")
        ui.cb94 = QtWidgets.QComboBox(parent=ui.tab_5)
        ui.cb94.setGeometry(QtCore.QRect(230, 202, 241, 32))
        ui.cb94.setStyleSheet("")
        ui.cb94.setObjectName("cb94")
        ui.lb94_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb94_2.setGeometry(QtCore.QRect(490, 202, 261, 30))
        ui.lb94_2.setObjectName("lb94_2")
        ui.pb90_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb90_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb90_2.setObjectName("pb90_2")
        ui.pb52_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb52_2.setGeometry(QtCore.QRect(60, 170, 41, 34))
        ui.pb52_2.setObjectName("pb52_2")
        ui.pb87_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb87_2.setGeometry(QtCore.QRect(60, 362, 41, 34))
        ui.pb87_2.setObjectName("pb87_2")
        ui.pb94_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb94_2.setGeometry(QtCore.QRect(60, 202, 41, 34))
        ui.pb94_2.setObjectName("pb94_2")
        ui.pb58_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb58_2.setGeometry(QtCore.QRect(60, 330, 41, 34))
        ui.pb58_2.setObjectName("pb58_2")
        ui.pb57_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb57_2.setGeometry(QtCore.QRect(60, 298, 41, 34))
        ui.pb57_2.setObjectName("pb57_2")
        ui.pb84_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb84_2.setGeometry(QtCore.QRect(60, 234, 41, 34))
        ui.pb84_2.setObjectName("pb84_2")
        ui.pb49_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb49_2.setGeometry(QtCore.QRect(60, 74, 41, 34))
        ui.pb49_2.setObjectName("pb49_2")
        ui.pb51_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb51_2.setGeometry(QtCore.QRect(60, 138, 41, 34))
        ui.pb51_2.setObjectName("pb51_2")
        ui.pb50_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb50_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb50_2.setObjectName("pb50_2")
        ui.pb55_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb55_2.setGeometry(QtCore.QRect(60, 266, 41, 34))
        ui.pb55_2.setObjectName("pb55_2")
        ui.pb90_3 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb90_3.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb90_3.setObjectName("pb90_3")
        ui.lb90_3 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb90_3.setGeometry(QtCore.QRect(490, 10, 261, 30))
        ui.lb90_3.setObjectName("lb90_3")
        ui.lb90_4 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb90_4.setGeometry(QtCore.QRect(140, 10, 51, 30))
        ui.lb90_4.setObjectName("lb90_4")
        ui.pb90_4 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb90_4.setGeometry(QtCore.QRect(60, 10, 41, 34))
        ui.pb90_4.setObjectName("pb90_4")
        ui.lb108_2 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb108_2.setGeometry(QtCore.QRect(490, 394, 261, 30))
        ui.lb108_2.setObjectName("lb108_2")
        ui.cb108 = QtWidgets.QComboBox(parent=ui.tab_5)
        ui.cb108.setGeometry(QtCore.QRect(230, 394, 241, 32))
        ui.cb108.setStyleSheet("")
        ui.cb108.setEditable(False)
        ui.cb108.setObjectName("cb108")
        ui.pb108 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb108.setGeometry(QtCore.QRect(10, 394, 41, 34))
        ui.pb108.setObjectName("pb108")
        ui.lb108 = QtWidgets.QLabel(parent=ui.tab_5)
        ui.lb108.setGeometry(QtCore.QRect(140, 394, 71, 30))
        ui.lb108.setObjectName("lb108")
        ui.pb108_2 = QtWidgets.QPushButton(parent=ui.tab_5)
        ui.pb108_2.setGeometry(QtCore.QRect(60, 394, 41, 34))
        ui.pb108_2.setObjectName("pb108_2")
        ui.tabWidget.addTab(ui.tab_5, "")
        ui.tab_6 = QtWidgets.QWidget()
        ui.tab_6.setObjectName("tab_6")
        ui.pb64 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb64.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb64.setObjectName("pb64")
        ui.lb64_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb64_2.setGeometry(QtCore.QRect(490, 74, 281, 30))
        ui.lb64_2.setObjectName("lb64_2")
        ui.lb64 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb64.setGeometry(QtCore.QRect(140, 74, 131, 30))
        ui.lb64.setObjectName("lb64")
        ui.pb65 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb65.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb65.setObjectName("pb65")
        ui.lb65_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb65_2.setGeometry(QtCore.QRect(490, 106, 271, 30))
        ui.lb65_2.setObjectName("lb65_2")
        ui.lb65 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb65.setGeometry(QtCore.QRect(140, 106, 111, 30))
        ui.lb65.setObjectName("lb65")
        ui.pb66 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb66.setGeometry(QtCore.QRect(10, 170, 41, 34))
        ui.pb66.setObjectName("pb66")
        ui.lb66 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb66.setGeometry(QtCore.QRect(140, 170, 51, 30))
        ui.lb66.setObjectName("lb66")
        ui.lb66_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb66_2.setGeometry(QtCore.QRect(490, 170, 271, 30))
        ui.lb66_2.setObjectName("lb66_2")
        ui.pb68 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb68.setGeometry(QtCore.QRect(10, 202, 41, 34))
        ui.pb68.setObjectName("pb68")
        ui.lb68 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb68.setGeometry(QtCore.QRect(140, 202, 81, 30))
        ui.lb68.setObjectName("lb68")
        ui.lb68_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb68_2.setGeometry(QtCore.QRect(490, 202, 271, 30))
        ui.lb68_2.setObjectName("lb68_2")
        ui.lb69 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb69.setGeometry(QtCore.QRect(140, 234, 71, 30))
        ui.lb69.setObjectName("lb69")
        ui.pb69 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb69.setGeometry(QtCore.QRect(10, 234, 41, 34))
        ui.pb69.setObjectName("pb69")
        ui.lb69_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb69_2.setGeometry(QtCore.QRect(490, 234, 271, 30))
        ui.lb69_2.setObjectName("lb69_2")
        ui.cb66 = QtWidgets.QComboBox(parent=ui.tab_6)
        ui.cb66.setGeometry(QtCore.QRect(230, 170, 241, 32))
        ui.cb66.setStyleSheet("")
        ui.cb66.setObjectName("cb66")
        ui.lb70 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb70.setGeometry(QtCore.QRect(140, 266, 71, 30))
        ui.lb70.setObjectName("lb70")
        ui.pb70 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb70.setGeometry(QtCore.QRect(10, 266, 41, 34))
        ui.pb70.setObjectName("pb70")
        ui.lb70_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb70_2.setGeometry(QtCore.QRect(490, 266, 281, 30))
        ui.lb70_2.setObjectName("lb70_2")
        ui.lb71_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb71_2.setGeometry(QtCore.QRect(490, 298, 271, 30))
        ui.lb71_2.setObjectName("lb71_2")
        ui.lb71 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb71.setGeometry(QtCore.QRect(140, 298, 81, 30))
        ui.lb71.setObjectName("lb71")
        ui.pb71 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb71.setGeometry(QtCore.QRect(10, 298, 41, 34))
        ui.pb71.setObjectName("pb71")
        ui.pb74 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb74.setGeometry(QtCore.QRect(10, 362, 41, 34))
        ui.pb74.setObjectName("pb74")
        ui.lb73 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb73.setGeometry(QtCore.QRect(140, 330, 61, 30))
        ui.lb73.setObjectName("lb73")
        ui.lb74 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb74.setGeometry(QtCore.QRect(140, 362, 71, 30))
        ui.lb74.setObjectName("lb74")
        ui.pb73 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb73.setGeometry(QtCore.QRect(10, 330, 41, 34))
        ui.pb73.setObjectName("pb73")
        ui.cb73 = QtWidgets.QComboBox(parent=ui.tab_6)
        ui.cb73.setGeometry(QtCore.QRect(230, 330, 241, 32))
        ui.cb73.setStyleSheet("")
        ui.cb73.setObjectName("cb73")
        ui.lb73_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb73_2.setGeometry(QtCore.QRect(490, 330, 271, 30))
        ui.lb73_2.setObjectName("lb73_2")
        ui.lb74_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb74_2.setGeometry(QtCore.QRect(490, 362, 281, 30))
        ui.lb74_2.setObjectName("lb74_2")
        ui.pb64_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb64_2.setGeometry(QtCore.QRect(60, 74, 41, 34))
        ui.pb64_2.setObjectName("pb64_2")
        ui.pb65_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb65_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb65_2.setObjectName("pb65_2")
        ui.pb66_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb66_2.setGeometry(QtCore.QRect(60, 170, 41, 34))
        ui.pb66_2.setObjectName("pb66_2")
        ui.pb69_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb69_2.setGeometry(QtCore.QRect(60, 234, 41, 34))
        ui.pb69_2.setObjectName("pb69_2")
        ui.pb74_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb74_2.setGeometry(QtCore.QRect(60, 362, 41, 34))
        ui.pb74_2.setObjectName("pb74_2")
        ui.pb71_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb71_2.setGeometry(QtCore.QRect(60, 298, 41, 34))
        ui.pb71_2.setObjectName("pb71_2")
        ui.pb68_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb68_2.setGeometry(QtCore.QRect(60, 202, 41, 34))
        ui.pb68_2.setObjectName("pb68_2")
        ui.pb73_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb73_2.setGeometry(QtCore.QRect(60, 330, 41, 34))
        ui.pb73_2.setObjectName("pb73_2")
        ui.pb105 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb105.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb105.setObjectName("pb105")
        ui.lb105_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb105_2.setGeometry(QtCore.QRect(490, 42, 281, 30))
        ui.lb105_2.setObjectName("lb105_2")
        ui.lb105 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb105.setGeometry(QtCore.QRect(140, 42, 81, 30))
        ui.lb105.setObjectName("lb105")
        ui.pb105_2 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb105_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb105_2.setObjectName("pb105_2")
        ui.lb69_3 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb69_3.setGeometry(QtCore.QRect(490, 138, 271, 30))
        ui.lb69_3.setObjectName("lb69_3")
        ui.pb69_3 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb69_3.setGeometry(QtCore.QRect(60, 138, 41, 34))
        ui.pb69_3.setObjectName("pb69_3")
        ui.pb69_4 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb69_4.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb69_4.setObjectName("pb69_4")
        ui.lb69_4 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb69_4.setGeometry(QtCore.QRect(140, 138, 81, 30))
        ui.lb69_4.setObjectName("lb69_4")
        ui.lb110_2 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb110_2.setGeometry(QtCore.QRect(490, 10, 271, 30))
        ui.lb110_2.setObjectName("lb110_2")
        ui.pb110 = QtWidgets.QPushButton(parent=ui.tab_6)
        ui.pb110.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb110.setObjectName("pb110")
        ui.lb110 = QtWidgets.QLabel(parent=ui.tab_6)
        ui.lb110.setGeometry(QtCore.QRect(140, 10, 81, 30))
        ui.lb110.setObjectName("lb110")
        ui.tabWidget.addTab(ui.tab_6, "")
        ui.tab_7 = QtWidgets.QWidget()
        ui.tab_7.setObjectName("tab_7")
        ui.pb77 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb77.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb77.setObjectName("pb77")
        ui.lb77 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb77.setGeometry(QtCore.QRect(140, 42, 61, 30))
        ui.lb77.setObjectName("lb77")
        ui.lb77_2 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb77_2.setGeometry(QtCore.QRect(490, 42, 271, 30))
        ui.lb77_2.setObjectName("lb77_2")
        ui.cb77 = QtWidgets.QComboBox(parent=ui.tab_7)
        ui.cb77.setGeometry(QtCore.QRect(230, 42, 241, 32))
        ui.cb77.setStyleSheet("")
        ui.cb77.setObjectName("cb77")
        ui.lb80 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb80.setGeometry(QtCore.QRect(140, 106, 61, 30))
        ui.lb80.setObjectName("lb80")
        ui.pb80 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb80.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb80.setObjectName("pb80")
        ui.lb80_2 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb80_2.setGeometry(QtCore.QRect(490, 106, 271, 30))
        ui.lb80_2.setObjectName("lb80_2")
        ui.lb81_2 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb81_2.setGeometry(QtCore.QRect(490, 138, 271, 30))
        ui.lb81_2.setObjectName("lb81_2")
        ui.lb81 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb81.setGeometry(QtCore.QRect(140, 138, 61, 30))
        ui.lb81.setObjectName("lb81")
        ui.pb81 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb81.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb81.setObjectName("pb81")
        ui.lb82 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb82.setGeometry(QtCore.QRect(140, 170, 61, 30))
        ui.lb82.setObjectName("lb82")
        ui.lb82_2 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb82_2.setGeometry(QtCore.QRect(490, 170, 271, 30))
        ui.lb82_2.setObjectName("lb82_2")
        ui.pb82 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb82.setGeometry(QtCore.QRect(10, 170, 41, 34))
        ui.pb82.setObjectName("pb82")
        ui.pb79 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb79.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb79.setObjectName("pb79")
        ui.lb79 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb79.setGeometry(QtCore.QRect(140, 74, 61, 30))
        ui.lb79.setObjectName("lb79")
        ui.lb79_2 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb79_2.setGeometry(QtCore.QRect(490, 74, 271, 30))
        ui.lb79_2.setObjectName("lb79_2")
        ui.cb79 = QtWidgets.QComboBox(parent=ui.tab_7)
        ui.cb79.setGeometry(QtCore.QRect(230, 74, 241, 32))
        ui.cb79.setStyleSheet("")
        ui.cb79.setObjectName("cb79")
        ui.pb83 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb83.setGeometry(QtCore.QRect(10, 202, 41, 34))
        ui.pb83.setObjectName("pb83")
        ui.lb83 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb83.setGeometry(QtCore.QRect(140, 202, 61, 30))
        ui.lb83.setObjectName("lb83")
        ui.lb83_2 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb83_2.setGeometry(QtCore.QRect(490, 202, 271, 30))
        ui.lb83_2.setObjectName("lb83_2")
        ui.cb83 = QtWidgets.QComboBox(parent=ui.tab_7)
        ui.cb83.setGeometry(QtCore.QRect(230, 202, 241, 32))
        ui.cb83.setStyleSheet("")
        ui.cb83.setObjectName("cb83")
        ui.lb99 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb99.setGeometry(QtCore.QRect(140, 234, 71, 30))
        ui.lb99.setObjectName("lb99")
        ui.lb99_2 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb99_2.setGeometry(QtCore.QRect(490, 234, 261, 30))
        ui.lb99_2.setObjectName("lb99_2")
        ui.pb99 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb99.setGeometry(QtCore.QRect(10, 234, 41, 34))
        ui.pb99.setObjectName("pb99")
        ui.cb99 = QtWidgets.QComboBox(parent=ui.tab_7)
        ui.cb99.setGeometry(QtCore.QRect(230, 234, 241, 32))
        ui.cb99.setStyleSheet("")
        ui.cb99.setObjectName("cb99")
        ui.pb79_2 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb79_2.setGeometry(QtCore.QRect(60, 74, 41, 34))
        ui.pb79_2.setObjectName("pb79_2")
        ui.pb83_2 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb83_2.setGeometry(QtCore.QRect(60, 202, 41, 34))
        ui.pb83_2.setObjectName("pb83_2")
        ui.pb99_2 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb99_2.setGeometry(QtCore.QRect(60, 234, 41, 34))
        ui.pb99_2.setObjectName("pb99_2")
        ui.pb82_2 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb82_2.setGeometry(QtCore.QRect(60, 170, 41, 34))
        ui.pb82_2.setObjectName("pb82_2")
        ui.pb81_2 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb81_2.setGeometry(QtCore.QRect(60, 138, 41, 34))
        ui.pb81_2.setObjectName("pb81_2")
        ui.pb80_2 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb80_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb80_2.setObjectName("pb80_2")
        ui.pb77_2 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb77_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb77_2.setObjectName("pb77_2")
        ui.pb77_3 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb77_3.setGeometry(QtCore.QRect(60, 10, 41, 34))
        ui.pb77_3.setObjectName("pb77_3")
        ui.lb77_3 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb77_3.setGeometry(QtCore.QRect(490, 10, 271, 30))
        ui.lb77_3.setObjectName("lb77_3")
        ui.pb77_4 = QtWidgets.QPushButton(parent=ui.tab_7)
        ui.pb77_4.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb77_4.setObjectName("pb77_4")
        ui.lb77_4 = QtWidgets.QLabel(parent=ui.tab_7)
        ui.lb77_4.setGeometry(QtCore.QRect(140, 10, 61, 30))
        ui.lb77_4.setObjectName("lb77_4")
        ui.cb77_2 = QtWidgets.QComboBox(parent=ui.tab_7)
        ui.cb77_2.setGeometry(QtCore.QRect(230, 10, 241, 32))
        ui.cb77_2.setStyleSheet("")
        ui.cb77_2.setObjectName("cb77_2")
        ui.tabWidget.addTab(ui.tab_7, "")
        ui.tab_8 = QtWidgets.QWidget()
        ui.tab_8.setObjectName("tab_8")
        ui.cbList = QtWidgets.QComboBox(parent=ui.tab_8)
        ui.cbList.setGeometry(QtCore.QRect(60, 22, 441, 32))
        ui.cbList.setStyleSheet("")
        ui.cbList.setMaxVisibleItems(20)
        ui.cbList.setObjectName("cbList")
        ui.cbList.addItem("")
        ui.pbRefreshList = QtWidgets.QPushButton(parent=ui.tab_8)
        ui.pbRefreshList.setGeometry(QtCore.QRect(530, 22, 88, 34))
        ui.pbRefreshList.setStyleSheet("")
        ui.pbRefreshList.setObjectName("pbRefreshList")
        ui.pbEditFile = QtWidgets.QPushButton(parent=ui.tab_8)
        ui.pbEditFile.setGeometry(QtCore.QRect(630, 22, 88, 34))
        ui.pbEditFile.setStyleSheet("")
        ui.pbEditFile.setFlat(False)
        ui.pbEditFile.setObjectName("pbEditFile")
        ui.tabWidget.addTab(ui.tab_8, "")
        ui.tab_9 = QtWidgets.QWidget()
        ui.tab_9.setObjectName("tab_9")
        ui.pb8_2 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb8_2.setGeometry(QtCore.QRect(60, 74, 41, 34))
        ui.pb8_2.setObjectName("pb8_2")
        ui.pb4_2 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb4_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb4_2.setObjectName("pb4_2")
        ui.lb8 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb8.setGeometry(QtCore.QRect(140, 74, 71, 30))
        ui.lb8.setObjectName("lb8")
        ui.cb7 = QtWidgets.QComboBox(parent=ui.tab_9)
        ui.cb7.setGeometry(QtCore.QRect(230, 10, 241, 32))
        ui.cb7.setStyleSheet("")
        ui.cb7.setEditable(False)
        ui.cb7.setObjectName("cb7")
        ui.lb7 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb7.setGeometry(QtCore.QRect(140, 10, 71, 30))
        ui.lb7.setObjectName("lb7")
        ui.pb4 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb4.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb4.setObjectName("pb4")
        ui.pb8 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb8.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb8.setObjectName("pb8")
        ui.pb7_2 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb7_2.setGeometry(QtCore.QRect(60, 10, 41, 34))
        ui.pb7_2.setObjectName("pb7_2")
        ui.pb7 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb7.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb7.setObjectName("pb7")
        ui.lb4 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb4.setGeometry(QtCore.QRect(140, 42, 71, 30))
        ui.lb4.setObjectName("lb4")
        ui.lb8_2 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb8_2.setGeometry(QtCore.QRect(490, 74, 261, 30))
        ui.lb8_2.setObjectName("lb8_2")
        ui.lb7_2 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb7_2.setGeometry(QtCore.QRect(490, 10, 261, 30))
        ui.lb7_2.setObjectName("lb7_2")
        ui.lb4_2 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb4_2.setGeometry(QtCore.QRect(490, 42, 261, 30))
        ui.lb4_2.setObjectName("lb4_2")
        ui.lb88_2 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb88_2.setGeometry(QtCore.QRect(490, 106, 261, 30))
        ui.lb88_2.setObjectName("lb88_2")
        ui.pb88 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb88.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb88.setObjectName("pb88")
        ui.lb88 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb88.setGeometry(QtCore.QRect(140, 106, 51, 30))
        ui.lb88.setObjectName("lb88")
        ui.pb88_2 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb88_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb88_2.setObjectName("pb88_2")
        ui.lb61_2 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb61_2.setGeometry(QtCore.QRect(490, 138, 261, 30))
        ui.lb61_2.setObjectName("lb61_2")
        ui.pb61 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb61.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb61.setObjectName("pb61")
        ui.lb61 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb61.setGeometry(QtCore.QRect(140, 138, 51, 30))
        ui.lb61.setObjectName("lb61")
        ui.pb61_2 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb61_2.setGeometry(QtCore.QRect(60, 138, 41, 34))
        ui.pb61_2.setObjectName("pb61_2")
        ui.cb76 = QtWidgets.QComboBox(parent=ui.tab_9)
        ui.cb76.setGeometry(QtCore.QRect(230, 234, 241, 32))
        ui.cb76.setStyleSheet("")
        ui.cb76.setObjectName("cb76")
        ui.pb95_2 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb95_2.setGeometry(QtCore.QRect(60, 170, 42, 34))
        ui.pb95_2.setObjectName("pb95_2")
        ui.lb95_2 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb95_2.setGeometry(QtCore.QRect(490, 170, 261, 30))
        ui.lb95_2.setObjectName("lb95_2")
        ui.lb95 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb95.setGeometry(QtCore.QRect(140, 170, 51, 30))
        ui.lb95.setObjectName("lb95")
        ui.pb95 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb95.setGeometry(QtCore.QRect(10, 170, 42, 34))
        ui.pb95.setObjectName("pb95")
        ui.lb76_2 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb76_2.setGeometry(QtCore.QRect(490, 234, 271, 30))
        ui.lb76_2.setObjectName("lb76_2")
        ui.lb76 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb76.setGeometry(QtCore.QRect(140, 234, 71, 30))
        ui.lb76.setObjectName("lb76")
        ui.pb76 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb76.setGeometry(QtCore.QRect(10, 234, 41, 34))
        ui.pb76.setObjectName("pb76")
        ui.pb76_2 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb76_2.setGeometry(QtCore.QRect(60, 234, 41, 34))
        ui.pb76_2.setObjectName("pb76_2")
        ui.pb75 = QtWidgets.QPushButton(parent=ui.tab_9)
        ui.pb75.setGeometry(QtCore.QRect(10, 202, 41, 34))
        ui.pb75.setObjectName("pb75")
        ui.lb75 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb75.setGeometry(QtCore.QRect(140, 202, 131, 30))
        ui.lb75.setObjectName("lb75")
        ui.lb75_2 = QtWidgets.QLabel(parent=ui.tab_9)
        ui.lb75_2.setGeometry(QtCore.QRect(490, 202, 271, 30))
        ui.lb75_2.setObjectName("lb75_2")
        ui.tabWidget.addTab(ui.tab_9, "")
        ui.tab_10 = QtWidgets.QWidget()
        ui.tab_10.setObjectName("tab_10")
        ui.lb39_2 = QtWidgets.QLabel(parent=ui.tab_10)
        ui.lb39_2.setGeometry(QtCore.QRect(490, 42, 261, 30))
        ui.lb39_2.setObjectName("lb39_2")
        ui.lb39_3 = QtWidgets.QLabel(parent=ui.tab_10)
        ui.lb39_3.setGeometry(QtCore.QRect(140, 74, 91, 30))
        ui.lb39_3.setObjectName("lb39_3")
        ui.pb39_2 = QtWidgets.QPushButton(parent=ui.tab_10)
        ui.pb39_2.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb39_2.setObjectName("pb39_2")
        ui.lb39_4 = QtWidgets.QLabel(parent=ui.tab_10)
        ui.lb39_4.setGeometry(QtCore.QRect(490, 74, 261, 30))
        ui.lb39_4.setObjectName("lb39_4")
        ui.cb39 = QtWidgets.QComboBox(parent=ui.tab_10)
        ui.cb39.setGeometry(QtCore.QRect(230, 74, 241, 32))
        ui.cb39.setStyleSheet("")
        ui.cb39.setObjectName("cb39")
        ui.pb39 = QtWidgets.QPushButton(parent=ui.tab_10)
        ui.pb39.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb39.setObjectName("pb39")
        ui.lb39 = QtWidgets.QLabel(parent=ui.tab_10)
        ui.lb39.setGeometry(QtCore.QRect(140, 42, 141, 30))
        ui.lb39.setObjectName("lb39")
        ui.lb1 = QtWidgets.QLabel(parent=ui.tab_10)
        ui.lb1.setGeometry(QtCore.QRect(140, 10, 201, 30))
        ui.lb1.setObjectName("lb1")
        ui.lb1_2 = QtWidgets.QLabel(parent=ui.tab_10)
        ui.lb1_2.setGeometry(QtCore.QRect(490, 10, 261, 30))
        ui.lb1_2.setObjectName("lb1_2")
        ui.pb1 = QtWidgets.QPushButton(parent=ui.tab_10)
        ui.pb1.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb1.setObjectName("pb1")
        ui.lb39_5 = QtWidgets.QLabel(parent=ui.tab_10)
        ui.lb39_5.setGeometry(QtCore.QRect(490, 106, 261, 30))
        ui.lb39_5.setObjectName("lb39_5")
        ui.lb39_6 = QtWidgets.QLabel(parent=ui.tab_10)
        ui.lb39_6.setGeometry(QtCore.QRect(140, 106, 191, 30))
        ui.lb39_6.setObjectName("lb39_6")
        ui.pb39_3 = QtWidgets.QPushButton(parent=ui.tab_10)
        ui.pb39_3.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb39_3.setObjectName("pb39_3")
        ui.tabWidget.addTab(ui.tab_10, "")
        ui.tab_11 = QtWidgets.QWidget()
        ui.tab_11.setObjectName("tab_11")
        ui.lb59 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb59.setGeometry(QtCore.QRect(140, 10, 81, 30))
        ui.lb59.setObjectName("lb59")
        ui.cb59 = QtWidgets.QComboBox(parent=ui.tab_11)
        ui.cb59.setGeometry(QtCore.QRect(230, 10, 241, 32))
        ui.cb59.setStyleSheet("")
        ui.cb59.setObjectName("cb59")
        ui.pb60_2 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb60_2.setGeometry(QtCore.QRect(60, 42, 41, 34))
        ui.pb60_2.setObjectName("pb60_2")
        ui.lb59_2 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb59_2.setGeometry(QtCore.QRect(490, 10, 261, 30))
        ui.lb59_2.setObjectName("lb59_2")
        ui.pb60 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb60.setGeometry(QtCore.QRect(10, 42, 41, 34))
        ui.pb60.setObjectName("pb60")
        ui.lb60_2 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb60_2.setGeometry(QtCore.QRect(490, 42, 261, 30))
        ui.lb60_2.setObjectName("lb60_2")
        ui.pb59_2 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb59_2.setGeometry(QtCore.QRect(60, 10, 41, 34))
        ui.pb59_2.setObjectName("pb59_2")
        ui.pb59 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb59.setGeometry(QtCore.QRect(10, 10, 41, 34))
        ui.pb59.setObjectName("pb59")
        ui.lb60 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb60.setGeometry(QtCore.QRect(140, 42, 121, 30))
        ui.lb60.setObjectName("lb60")
        ui.lb72 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb72.setGeometry(QtCore.QRect(140, 106, 101, 30))
        ui.lb72.setObjectName("lb72")
        ui.pb72 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb72.setGeometry(QtCore.QRect(10, 106, 41, 34))
        ui.pb72.setObjectName("pb72")
        ui.pb72_2 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb72_2.setGeometry(QtCore.QRect(60, 106, 41, 34))
        ui.pb72_2.setObjectName("pb72_2")
        ui.lb72_2 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb72_2.setGeometry(QtCore.QRect(490, 106, 271, 30))
        ui.lb72_2.setObjectName("lb72_2")
        ui.lb78 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb78.setGeometry(QtCore.QRect(140, 138, 61, 30))
        ui.lb78.setObjectName("lb78")
        ui.lb78_2 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb78_2.setGeometry(QtCore.QRect(490, 138, 271, 30))
        ui.lb78_2.setObjectName("lb78_2")
        ui.pb78 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb78.setGeometry(QtCore.QRect(10, 138, 41, 34))
        ui.pb78.setObjectName("pb78")
        ui.pb78_2 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb78_2.setGeometry(QtCore.QRect(60, 138, 41, 34))
        ui.pb78_2.setObjectName("pb78_2")
        ui.lb78_3 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb78_3.setGeometry(QtCore.QRect(490, 74, 271, 30))
        ui.lb78_3.setObjectName("lb78_3")
        ui.pb78_3 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb78_3.setGeometry(QtCore.QRect(60, 74, 41, 34))
        ui.pb78_3.setObjectName("pb78_3")
        ui.pb78_4 = QtWidgets.QPushButton(parent=ui.tab_11)
        ui.pb78_4.setGeometry(QtCore.QRect(10, 74, 41, 34))
        ui.pb78_4.setObjectName("pb78_4")
        ui.lb78_4 = QtWidgets.QLabel(parent=ui.tab_11)
        ui.lb78_4.setGeometry(QtCore.QRect(140, 74, 61, 30))
        ui.lb78_4.setObjectName("lb78_4")
        ui.tabWidget.addTab(ui.tab_11, "")
        MainWindow.setCentralWidget(ui.centralwidget)
        ui.menubar = QtWidgets.QMenuBar(parent=MainWindow)
        ui.menubar.setGeometry(QtCore.QRect(0, 0, 800, 20))
        ui.menubar.setObjectName("menubar")
        ui.menuFile = QtWidgets.QMenu(parent=ui.menubar)
        ui.menuFile.setObjectName("menuFile")
        ui.menuHelp = QtWidgets.QMenu(parent=ui.menubar)
        ui.menuHelp.setObjectName("menuHelp")
        ui.menu_Forum = QtWidgets.QMenu(parent=ui.menubar)
        ui.menu_Forum.setTearOffEnabled(True)
        ui.menu_Forum.setObjectName("menu_Forum")
        ui.menuStyle = QtWidgets.QMenu(parent=ui.menubar)
        ui.menuStyle.setObjectName("menuStyle")
        ui.menu_Outputs = QtWidgets.QMenu(parent=ui.menubar)
        ui.menu_Outputs.setObjectName("menu_Outputs")
        ui.menu_License = QtWidgets.QMenu(parent=ui.menubar)
        ui.menu_License.setObjectName("menu_License")
        MainWindow.setMenuBar(ui.menubar)
        ui.statusbar = QtWidgets.QStatusBar(parent=MainWindow)
        ui.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(ui.statusbar)
        ui.actionExit = QtGui.QAction(parent=MainWindow)
        ui.actionExit.setObjectName("actionExit")
        ui.actionAbout = QtGui.QAction(parent=MainWindow)
        ui.actionAbout.setObjectName("actionAbout")
        ui.actionNotes = QtGui.QAction(parent=MainWindow)
        ui.actionNotes.setObjectName("actionNotes")
        ui.actionCommands = QtGui.QAction(parent=MainWindow)
        ui.actionCommands.setObjectName("actionCommands")
        ui.action_urls = QtGui.QAction(parent=MainWindow)
        ui.action_urls.setObjectName("action_urls")
        ui.action_distrowatch = QtGui.QAction(parent=MainWindow)
        ui.action_distrowatch.setObjectName("action_distrowatch")
        ui.actionUpdate_List = QtGui.QAction(parent=MainWindow)
        ui.actionUpdate_List.setObjectName("actionUpdate_List")
        ui.actiontestlabel = QtGui.QAction(parent=MainWindow)
        ui.actiontestlabel.setObjectName("actiontestlabel")
        ui.action_forum = QtGui.QAction(parent=MainWindow)
        ui.action_forum.setObjectName("action_forum")
        ui.actionAbout_3 = QtGui.QAction(parent=MainWindow)
        ui.actionAbout_3.setObjectName("actionAbout_3")
        ui.actionNotes_2 = QtGui.QAction(parent=MainWindow)
        ui.actionNotes_2.setObjectName("actionNotes_2")
        ui.actionCommands_2 = QtGui.QAction(parent=MainWindow)
        ui.actionCommands_2.setObjectName("actionCommands_2")
        ui.actionTesting = QtGui.QAction(parent=MainWindow)
        ui.actionTesting.setObjectName("actionTesting")
        ui.actionLicense_Copyright = QtGui.QAction(parent=MainWindow)
        ui.actionLicense_Copyright.setObjectName("actionLicense_Copyright")
        ui.actionGray = QtGui.QAction(parent=MainWindow)
        ui.actionGray.setCheckable(False)
        ui.actionGray.setObjectName("actionGray")
        ui.actionLight = QtGui.QAction(parent=MainWindow)
        ui.actionLight.setCheckable(False)
        ui.actionLight.setChecked(False)
        ui.actionLight.setObjectName("actionLight")
        ui.actionDark_Gray = QtGui.QAction(parent=MainWindow)
        ui.actionDark_Gray.setObjectName("actionDark_Gray")
        ui.actionDark_Dark = QtGui.QAction(parent=MainWindow)
        ui.actionDark_Dark.setObjectName("actionDark_Dark")
        ui.actionBlue = QtGui.QAction(parent=MainWindow)
        ui.actionBlue.setObjectName("actionBlue")
        ui.actionGreen = QtGui.QAction(parent=MainWindow)
        ui.actionGreen.setObjectName("actionGreen")
        ui.actionTeal = QtGui.QAction(parent=MainWindow)
        ui.actionTeal.setObjectName("actionTeal")
        ui.actionDark = QtGui.QAction(parent=MainWindow)
        ui.actionDark.setObjectName("actionDark")
        ui.actionLight_2 = QtGui.QAction(parent=MainWindow)
        ui.actionLight_2.setObjectName("actionLight_2")
        ui.actionDark_Dark_2 = QtGui.QAction(parent=MainWindow)
        ui.actionDark_Dark_2.setObjectName("actionDark_Dark_2")
        ui.actionSend_to_text_file = QtGui.QAction(parent=MainWindow)
        ui.actionSend_to_text_file.setObjectName("actionSend_to_text_file")
        ui.actionSend_to_terminal = QtGui.QAction(parent=MainWindow)
        ui.actionSend_to_terminal.setObjectName("actionSend_to_terminal")
        ui.actionSend_to_text_file_2 = QtGui.QAction(parent=MainWindow)
        ui.actionSend_to_text_file_2.setCheckable(True)
        ui.actionSend_to_text_file_2.setChecked(True)
        ui.actionSend_to_text_file_2.setObjectName("actionSend_to_text_file_2")
        ui.actionSend_to_terminal_2 = QtGui.QAction(parent=MainWindow)
        ui.actionSend_to_terminal_2.setCheckable(True)
        ui.actionSend_to_terminal_2.setObjectName("actionSend_to_terminal_2")
        ui.actionLGPL_3_0 = QtGui.QAction(parent=MainWindow)
        ui.actionLGPL_3_0.setObjectName("actionLGPL_3_0")
        ui.action_Cocoa = QtGui.QAction(parent=MainWindow)
        ui.action_Cocoa.setObjectName("action_Cocoa")
        ui.actionCyan = QtGui.QAction(parent=MainWindow)
        ui.actionCyan.setObjectName("actionCyan")
        ui.actionTan = QtGui.QAction(parent=MainWindow)
        ui.actionTan.setObjectName("actionTan")
        ui.menuFile.addAction(ui.actionExit)
        ui.menuHelp.addAction(ui.actionAbout_3)
        ui.menuHelp.addAction(ui.actionNotes_2)
        ui.menuHelp.addAction(ui.actionCommands_2)
        ui.menuHelp.addAction(ui.actionTesting)
        ui.menu_Forum.addAction(ui.action_distrowatch)
        ui.menu_Forum.addAction(ui.action_forum)
        ui.menuStyle.addAction(ui.actionBlue)
        ui.menuStyle.addAction(ui.action_Cocoa)
        ui.menuStyle.addAction(ui.actionCyan)
        ui.menuStyle.addAction(ui.actionDark)
        ui.menuStyle.addAction(ui.actionDark_Dark_2)
        ui.menuStyle.addAction(ui.actionGray)
        ui.menuStyle.addAction(ui.actionGreen)
        ui.menuStyle.addAction(ui.actionLight_2)
        ui.menuStyle.addAction(ui.actionTan)
        ui.menuStyle.addAction(ui.actionTeal)
        ui.menu_Outputs.addAction(ui.actionSend_to_text_file_2)
        ui.menu_Outputs.addAction(ui.actionSend_to_terminal_2)
        ui.menu_License.addAction(ui.actionLGPL_3_0)
        ui.menubar.addAction(ui.menuFile.menuAction())
        ui.menubar.addAction(ui.menuHelp.menuAction())
        ui.menubar.addAction(ui.menu_Outputs.menuAction())
        ui.menubar.addAction(ui.menuStyle.menuAction())
        ui.menubar.addAction(ui.menu_Forum.menuAction())
        ui.menubar.addAction(ui.menu_License.menuAction())

        ui.retranslateUi(MainWindow)
        ui.tabWidget.setCurrentIndex(0)
        ui.actionExit.triggered.connect(MainWindow.close)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(ui, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Linux Easy Command Center"))
        ui.lbnotices.setText(_translate("MainWindow", "Notices:"))
        ui.pb5.setText(_translate("MainWindow", "Run"))
        ui.lb5.setText(_translate("MainWindow", "cat"))
        ui.lb5_2.setText(_translate("MainWindow", "Shows system file\'s information (assorted)"))
        ui.lb6_2.setText(_translate("MainWindow", "Package management lists"))
        ui.lb6.setText(_translate("MainWindow", "apt list"))
        ui.pb6.setText(_translate("MainWindow", "Run"))
        ui.pb2.setText(_translate("MainWindow", "Run"))
        ui.lb2_2.setText(_translate("MainWindow", "Locate/print block device attributes"))
        ui.lb2.setText(_translate("MainWindow", "blkid"))
        ui.pb9.setText(_translate("MainWindow", "Run"))
        ui.lb9_2.setText(_translate("MainWindow", "Show CPU/Mobo/Memory/etc  information"))
        ui.lb9.setText(_translate("MainWindow", "cpu-x"))
        ui.pb10.setText(_translate("MainWindow", "Run"))
        ui.lb10.setText(_translate("MainWindow", "cpufetch"))
        ui.lb10_2.setText(_translate("MainWindow", "CPU architecture fetching tool"))
        ui.pb11.setText(_translate("MainWindow", "Run"))
        ui.lb11.setText(_translate("MainWindow", "cpupower-gui"))
        ui.lb11_2.setText(_translate("MainWindow", "Show/Adjust CPU frequencies"))
        ui.pb12.setText(_translate("MainWindow", "Run"))
        ui.lb12.setText(_translate("MainWindow", "clamtk"))
        ui.lb12_2.setText(_translate("MainWindow", "GUI to run Clam AntiVirus"))
        ui.pb86.setText(_translate("MainWindow", "Run"))
        ui.lb86_2.setText(_translate("MainWindow", "Show processor power related values"))
        ui.lb86.setText(_translate("MainWindow", "cpupower"))
        ui.pb2_2.setText(_translate("MainWindow", "Man"))
        ui.pb5_2.setText(_translate("MainWindow", "Man"))
        ui.pb86_2.setText(_translate("MainWindow", "Man"))
        ui.pb12_2.setText(_translate("MainWindow", "Man"))
        ui.pb6_2.setText(_translate("MainWindow", "Man"))
        ui.pb10_2.setText(_translate("MainWindow", "Man"))
        ui.pb9_2.setText(_translate("MainWindow", "Man"))
        ui.pb11_2.setText(_translate("MainWindow", "Man"))
        ui.lb101_2.setText(_translate("MainWindow", "Some application policies"))
        ui.pb101.setText(_translate("MainWindow", "Run"))
        ui.pb101_2.setText(_translate("MainWindow", "Man"))
        ui.lb101.setText(_translate("MainWindow", "apt policy"))
        ui.pb9_4.setText(_translate("MainWindow", "Run"))
        ui.lb9_3.setText(_translate("MainWindow", "cpuinfo"))
        ui.lb9_4.setText(_translate("MainWindow", "Show CPU basic information"))
        ui.lb13.setText(_translate("MainWindow", "df"))
        ui.pb13_2.setText(_translate("MainWindow", "Man"))
        ui.lb13_2.setText(_translate("MainWindow", "List file system disk space usage"))
        ui.pb13.setText(_translate("MainWindow", "Run"))
        ui.lb13_3.setText(_translate("MainWindow", "DNS information groper"))
        ui.pb13_3.setText(_translate("MainWindow", "Man"))
        ui.lb13_4.setText(_translate("MainWindow", "dig"))
        ui.pb13_4.setText(_translate("MainWindow", "Run"))
        ui.pb14_3.setText(_translate("MainWindow", "Man"))
        ui.lb14_3.setText(_translate("MainWindow", "Display Kernal ring buffer messages"))
        ui.lb14_4.setText(_translate("MainWindow", "dmesg"))
        ui.pb14_4.setText(_translate("MainWindow", "Run"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_1), _translate("MainWindow", "List 1"))
        ui.pb15.setText(_translate("MainWindow", "Run"))
        ui.lb15.setText(_translate("MainWindow", "dmidecode -t"))
        ui.lb15_2.setText(_translate("MainWindow", "List DMI table information"))
        ui.lb16_2.setText(_translate("MainWindow", "List all packages"))
        ui.lb16.setText(_translate("MainWindow", "dpkg"))
        ui.pb16.setText(_translate("MainWindow", "Run"))
        ui.lb17_2.setText(_translate("MainWindow", "List video card drivers"))
        ui.lb17.setText(_translate("MainWindow", "driver-manager"))
        ui.pb17.setText(_translate("MainWindow", "Run"))
        ui.pb18.setText(_translate("MainWindow", "Run"))
        ui.lb18.setText(_translate("MainWindow", "editor"))
        ui.lb18_2.setText(_translate("MainWindow", "Text editor"))
        ui.pb19.setText(_translate("MainWindow", "Run"))
        ui.lb19.setText(_translate("MainWindow", "efibootmgr"))
        ui.lb19_2.setText(_translate("MainWindow", "Display EFI boot list"))
        ui.lb20_2.setText(_translate("MainWindow", "Display environmental variables"))
        ui.lb20.setText(_translate("MainWindow", "env"))
        ui.pb20.setText(_translate("MainWindow", "Run"))
        ui.lb21.setText(_translate("MainWindow", "fdisk -x"))
        ui.lb21_2.setText(_translate("MainWindow", "Lists disk(s) partition(s) table(s) info"))
        ui.pb21.setText(_translate("MainWindow", "Run"))
        ui.pb22.setText(_translate("MainWindow", "Run"))
        ui.lb22.setText(_translate("MainWindow", "find (.conf)"))
        ui.lb22_2.setText(_translate("MainWindow", "Find \'.conf\' files under selected directory"))
        ui.lb23_2.setText(_translate("MainWindow", "Find \'images\' files under \'usr\'"))
        ui.lb23.setText(_translate("MainWindow", "find (image)"))
        ui.pb23.setText(_translate("MainWindow", "Run"))
        ui.pb24.setText(_translate("MainWindow", "Run"))
        ui.lb24.setText(_translate("MainWindow", "findmnt"))
        ui.lb24_2.setText(_translate("MainWindow", "List all mounted filesystems"))
        ui.lb93_3.setText(_translate("MainWindow", "flatpak list"))
        ui.lb93_4.setText(_translate("MainWindow", "List installed applications and/or runtimes"))
        ui.pb93.setText(_translate("MainWindow", "Run"))
        ui.pb93_2.setText(_translate("MainWindow", "Man"))
        ui.pb24_2.setText(_translate("MainWindow", "Man"))
        ui.pb16_2.setText(_translate("MainWindow", "Man"))
        ui.pb15_2.setText(_translate("MainWindow", "Man"))
        ui.pb20_2.setText(_translate("MainWindow", "Man"))
        ui.pb21_2.setText(_translate("MainWindow", "Man"))
        ui.pb23_2.setText(_translate("MainWindow", "Man"))
        ui.pb18_2.setText(_translate("MainWindow", "Man"))
        ui.pb19_2.setText(_translate("MainWindow", "Man"))
        ui.pb22_2.setText(_translate("MainWindow", "Man"))
        ui.pb102_2.setText(_translate("MainWindow", "Man"))
        ui.lb102.setText(_translate("MainWindow", "du -h"))
        ui.pb102.setText(_translate("MainWindow", "Run"))
        ui.lb102_2.setText(_translate("MainWindow", "List estimated directory/file sizes"))
        ui.pb25.setText(_translate("MainWindow", "Run"))
        ui.pb25_2.setText(_translate("MainWindow", "Man"))
        ui.lb25_2.setText(_translate("MainWindow", "firewall-config/gufw"))
        ui.lb25.setText(_translate("MainWindow", "firewall-config"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_2), _translate("MainWindow", "List 2"))
        ui.lb26.setText(_translate("MainWindow", "free -h"))
        ui.pb26.setText(_translate("MainWindow", "Run"))
        ui.lb26_2.setText(_translate("MainWindow", "Display free & used memory"))
        ui.lb27_2.setText(_translate("MainWindow", "Disk usage for current directory"))
        ui.lb27.setText(_translate("MainWindow", "gdu"))
        ui.pb27.setText(_translate("MainWindow", "Run"))
        ui.lb28_2.setText(_translate("MainWindow", "Partition editor"))
        ui.lb28.setText(_translate("MainWindow", "gparted"))
        ui.pb28.setText(_translate("MainWindow", "Run"))
        ui.pb29.setText(_translate("MainWindow", "Run"))
        ui.lb29_2.setText(_translate("MainWindow", "Grub editor"))
        ui.lb29.setText(_translate("MainWindow", "grub-customizer"))
        ui.lb30.setText(_translate("MainWindow", "gufw"))
        ui.pb30.setText(_translate("MainWindow", "Run"))
        ui.lb30_2.setText(_translate("MainWindow", "Firewall status verbose"))
        ui.lb31.setText(_translate("MainWindow", "hardinfo"))
        ui.pb31.setText(_translate("MainWindow", "Run"))
        ui.lb31_2.setText(_translate("MainWindow", "System profilier"))
        ui.lb32_2.setText(_translate("MainWindow", "Bluetooth connections"))
        ui.lb32.setText(_translate("MainWindow", "hcitool dev"))
        ui.pb32.setText(_translate("MainWindow", "Run"))
        ui.lb33_2.setText(_translate("MainWindow", "Host name or ip address"))
        ui.pb33.setText(_translate("MainWindow", "Run"))
        ui.lb33.setText(_translate("MainWindow", "hostname"))
        ui.lb27_3.setText(_translate("MainWindow", "getconf -a"))
        ui.pb89.setText(_translate("MainWindow", "Run"))
        ui.lb27_4.setText(_translate("MainWindow", "Show system configuration variables"))
        ui.pb91.setText(_translate("MainWindow", "Run"))
        ui.lb91_2.setText(_translate("MainWindow", "Show computer information"))
        ui.lb91.setText(_translate("MainWindow", "hostnamectl"))
        ui.pb89_2.setText(_translate("MainWindow", "Man"))
        ui.pb28_2.setText(_translate("MainWindow", "Man"))
        ui.pb30_2.setText(_translate("MainWindow", "Man"))
        ui.pb91_2.setText(_translate("MainWindow", "Man"))
        ui.pb31_2.setText(_translate("MainWindow", "Man"))
        ui.pb29_2.setText(_translate("MainWindow", "Man"))
        ui.pb32_2.setText(_translate("MainWindow", "Man"))
        ui.pb26_2.setText(_translate("MainWindow", "Man"))
        ui.pb33_2.setText(_translate("MainWindow", "Man"))
        ui.pb27_2.setText(_translate("MainWindow", "Man"))
        ui.lb103_2.setText(_translate("MainWindow", "Show SATA/IDE device parameters /dev/sda"))
        ui.pb103.setText(_translate("MainWindow", "Run"))
        ui.pb103_2.setText(_translate("MainWindow", "Man"))
        ui.lb103.setText(_translate("MainWindow", "hdparm -I"))
        ui.lb106_2.setText(_translate("MainWindow", "GNOME disks application"))
        ui.pb106.setText(_translate("MainWindow", "Run"))
        ui.pb106_2.setText(_translate("MainWindow", "Man"))
        ui.lb106.setText(_translate("MainWindow", "gnome-disks"))
        ui.lb91_3.setText(_translate("MainWindow", "Terminal history"))
        ui.pb91_3.setText(_translate("MainWindow", "Run"))
        ui.pb91_4.setText(_translate("MainWindow", "Man"))
        ui.lb91_4.setText(_translate("MainWindow", "history"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_3), _translate("MainWindow", "List 3"))
        ui.lb37_2.setText(_translate("MainWindow", "System info script for console & IRC"))
        ui.pb37.setText(_translate("MainWindow", "Run"))
        ui.lb37.setText(_translate("MainWindow", "inxi"))
        ui.pb38.setText(_translate("MainWindow", "Run"))
        ui.lb38_2.setText(_translate("MainWindow", "Show routing network interfaces"))
        ui.lb38.setText(_translate("MainWindow", "ip"))
        ui.lb42_2.setText(_translate("MainWindow", "Linux Information"))
        ui.lb42.setText(_translate("MainWindow", "linuxinfo"))
        ui.pb42.setText(_translate("MainWindow", "Run"))
        ui.pb40.setText(_translate("MainWindow", "Run"))
        ui.lb40.setText(_translate("MainWindow", "locate"))
        ui.lb40_2.setText(_translate("MainWindow", "Locate extensions"))
        ui.pb44.setText(_translate("MainWindow", "Run"))
        ui.lb44.setText(_translate("MainWindow", "lpstat"))
        ui.lb44_2.setText(_translate("MainWindow", "Printer info [turn printer online]"))
        ui.lb45_2.setText(_translate("MainWindow", "List all block devices"))
        ui.lb45.setText(_translate("MainWindow", "lsblk"))
        ui.pb45.setText(_translate("MainWindow", "Run"))
        ui.lb46_2.setText(_translate("MainWindow", "Show CPU architecture"))
        ui.lb46.setText(_translate("MainWindow", "lscpu"))
        ui.pb46.setText(_translate("MainWindow", "Run"))
        ui.lb47_2.setText(_translate("MainWindow", "List all hardware"))
        ui.pb47.setText(_translate("MainWindow", "Run"))
        ui.lb47.setText(_translate("MainWindow", "lshw"))
        ui.lb36_2.setText(_translate("MainWindow", "Show interfaces information"))
        ui.lb36.setText(_translate("MainWindow", "ifconfig"))
        ui.pb36.setText(_translate("MainWindow", "Run"))
        ui.lb35.setText(_translate("MainWindow", "id"))
        ui.lb35_2.setText(_translate("MainWindow", "Show real & effective user & group IDs"))
        ui.pb35.setText(_translate("MainWindow", "Run"))
        ui.lb48_2.setText(_translate("MainWindow", "Information about known users"))
        ui.pb48.setText(_translate("MainWindow", "Run"))
        ui.lb48.setText(_translate("MainWindow", "lslogins"))
        ui.pb42_2.setText(_translate("MainWindow", "Man"))
        ui.pb35_2.setText(_translate("MainWindow", "Man"))
        ui.pb47_2.setText(_translate("MainWindow", "Man"))
        ui.pb37_2.setText(_translate("MainWindow", "Man"))
        ui.pb44_2.setText(_translate("MainWindow", "Man"))
        ui.pb40_2.setText(_translate("MainWindow", "Man"))
        ui.pb46_2.setText(_translate("MainWindow", "Man"))
        ui.pb48_2.setText(_translate("MainWindow", "Man"))
        ui.pb38_2.setText(_translate("MainWindow", "Man"))
        ui.pb36_2.setText(_translate("MainWindow", "Man"))
        ui.pb45_2.setText(_translate("MainWindow", "Man"))
        ui.pb34_2.setText(_translate("MainWindow", "Man"))
        ui.lb34_2.setText(_translate("MainWindow", "Probe for hardware"))
        ui.lb34.setText(_translate("MainWindow", "hwinfo --disk"))
        ui.pb34.setText(_translate("MainWindow", "Run"))
        ui.lb47_3.setText(_translate("MainWindow", "journalctl -xe"))
        ui.pb47_3.setText(_translate("MainWindow", "Man"))
        ui.pb47_4.setText(_translate("MainWindow", "Run"))
        ui.lb47_4.setText(_translate("MainWindow", "Log entries from the systemd journal"))
        ui.lb35_3.setText(_translate("MainWindow", "CPU & I/O stats for devices & partitions"))
        ui.lb35_4.setText(_translate("MainWindow", "iostat"))
        ui.pb35_3.setText(_translate("MainWindow", "Run"))
        ui.pb35_4.setText(_translate("MainWindow", "Man"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_4), _translate("MainWindow", "List 4"))
        ui.lb49.setText(_translate("MainWindow", "lspci -tv"))
        ui.lb49_2.setText(_translate("MainWindow", "List all PCI devices"))
        ui.pb49.setText(_translate("MainWindow", "Run"))
        ui.lb50.setText(_translate("MainWindow", "lsscsi"))
        ui.lb50_2.setText(_translate("MainWindow", "List SCSI disks"))
        ui.pb50.setText(_translate("MainWindow", "Run"))
        ui.lb51_2.setText(_translate("MainWindow", "Show USB devices"))
        ui.lb51.setText(_translate("MainWindow", "lsusb"))
        ui.pb51.setText(_translate("MainWindow", "Run"))
        ui.lb52_2.setText(_translate("MainWindow", "List files in chosen directory"))
        ui.lb52.setText(_translate("MainWindow", "ls  ( a dir)"))
        ui.pb52.setText(_translate("MainWindow", "Run"))
        ui.pb55.setText(_translate("MainWindow", "Run"))
        ui.lb55.setText(_translate("MainWindow", "neofetch"))
        ui.lb55_2.setText(_translate("MainWindow", "System generic information script"))
        ui.pb57.setText(_translate("MainWindow", "Run"))
        ui.lb57_2.setText(_translate("MainWindow", "Kernel interface/routing tables"))
        ui.lb57.setText(_translate("MainWindow", "netstat"))
        ui.lb58_2.setText(_translate("MainWindow", "Network manager status using \'systemctl\'"))
        ui.pb58.setText(_translate("MainWindow", "Run"))
        ui.lb58.setText(_translate("MainWindow", "network manager status"))
        ui.lb84.setText(_translate("MainWindow", "midnight commander"))
        ui.pb84.setText(_translate("MainWindow", "Run"))
        ui.lb84_2.setText(_translate("MainWindow", "Visual shell - Unix-like system"))
        ui.lb87.setText(_translate("MainWindow", "nmcli"))
        ui.lb87_2.setText(_translate("MainWindow", "Network information"))
        ui.pb87.setText(_translate("MainWindow", "Run"))
        ui.lb90.setText(_translate("MainWindow", "lsof"))
        ui.pb90.setText(_translate("MainWindow", "Run"))
        ui.lb90_2.setText(_translate("MainWindow", "List files opened by processes"))
        ui.pb94.setText(_translate("MainWindow", "Run"))
        ui.lb94.setText(_translate("MainWindow", "ls programs"))
        ui.lb94_2.setText(_translate("MainWindow", "List programs by directory"))
        ui.pb90_2.setText(_translate("MainWindow", "Man"))
        ui.pb52_2.setText(_translate("MainWindow", "Man"))
        ui.pb87_2.setText(_translate("MainWindow", "Man"))
        ui.pb94_2.setText(_translate("MainWindow", "Man"))
        ui.pb58_2.setText(_translate("MainWindow", "Man"))
        ui.pb57_2.setText(_translate("MainWindow", "Man"))
        ui.pb84_2.setText(_translate("MainWindow", "Man"))
        ui.pb49_2.setText(_translate("MainWindow", "Man"))
        ui.pb51_2.setText(_translate("MainWindow", "Man"))
        ui.pb50_2.setText(_translate("MainWindow", "Man"))
        ui.pb55_2.setText(_translate("MainWindow", "Man"))
        ui.pb90_3.setText(_translate("MainWindow", "Run"))
        ui.lb90_3.setText(_translate("MainWindow", "Status of loaded kernel modules"))
        ui.lb90_4.setText(_translate("MainWindow", "lsmod"))
        ui.pb90_4.setText(_translate("MainWindow", "Man"))
        ui.lb108_2.setText(_translate("MainWindow", "DNS information groper"))
        ui.pb108.setText(_translate("MainWindow", "Run"))
        ui.lb108.setText(_translate("MainWindow", "nslookup"))
        ui.pb108_2.setText(_translate("MainWindow", "Man"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_5), _translate("MainWindow", "List 5"))
        ui.pb64.setText(_translate("MainWindow", "Run"))
        ui.lb64_2.setText(_translate("MainWindow", "List installed standard app packages"))
        ui.lb64.setText(_translate("MainWindow", "pip list standard"))
        ui.pb65.setText(_translate("MainWindow", "Run"))
        ui.lb65_2.setText(_translate("MainWindow", "List installed user app packages"))
        ui.lb65.setText(_translate("MainWindow", "pip list --user"))
        ui.pb66.setText(_translate("MainWindow", "Run"))
        ui.lb66.setText(_translate("MainWindow", "ps"))
        ui.lb66_2.setText(_translate("MainWindow", "Snapshots of current processes"))
        ui.pb68.setText(_translate("MainWindow", "Run"))
        ui.lb68.setText(_translate("MainWindow", "psensor"))
        ui.lb68_2.setText(_translate("MainWindow", "Temperature monitor"))
        ui.lb69.setText(_translate("MainWindow", "pstree"))
        ui.pb69.setText(_translate("MainWindow", "Run"))
        ui.lb69_2.setText(_translate("MainWindow", "Show process tree"))
        ui.lb70.setText(_translate("MainWindow", "pydf"))
        ui.pb70.setText(_translate("MainWindow", "Run"))
        ui.lb70_2.setText(_translate("MainWindow", "Shows disk usage & space"))
        ui.lb71_2.setText(_translate("MainWindow", "Show Python3\'s version"))
        ui.lb71.setText(_translate("MainWindow", "python3"))
        ui.pb71.setText(_translate("MainWindow", "Run"))
        ui.pb74.setText(_translate("MainWindow", "Run"))
        ui.lb73.setText(_translate("MainWindow", "ss"))
        ui.lb74.setText(_translate("MainWindow", "sysctl -a"))
        ui.pb73.setText(_translate("MainWindow", "Run"))
        ui.lb73_2.setText(_translate("MainWindow", "Investigate sockets"))
        ui.lb74_2.setText(_translate("MainWindow", "Display all kernel values currently available"))
        ui.pb64_2.setText(_translate("MainWindow", "Man"))
        ui.pb65_2.setText(_translate("MainWindow", "Man"))
        ui.pb66_2.setText(_translate("MainWindow", "Man"))
        ui.pb69_2.setText(_translate("MainWindow", "Man"))
        ui.pb74_2.setText(_translate("MainWindow", "Man"))
        ui.pb71_2.setText(_translate("MainWindow", "Man"))
        ui.pb68_2.setText(_translate("MainWindow", "Man"))
        ui.pb73_2.setText(_translate("MainWindow", "Man"))
        ui.pb105.setText(_translate("MainWindow", "Run"))
        ui.lb105_2.setText(_translate("MainWindow", "Lists partition layout on all block devices"))
        ui.lb105.setText(_translate("MainWindow", "parted -l"))
        ui.pb105_2.setText(_translate("MainWindow", "Man"))
        ui.lb69_3.setText(_translate("MainWindow", "Print all environment"))
        ui.pb69_3.setText(_translate("MainWindow", "Man"))
        ui.pb69_4.setText(_translate("MainWindow", "Run"))
        ui.lb69_4.setText(_translate("MainWindow", "printenv"))
        ui.lb110_2.setText(_translate("MainWindow", "Discover bootable partitions"))
        ui.pb110.setText(_translate("MainWindow", "Run"))
        ui.lb110.setText(_translate("MainWindow", "os-prober"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_6), _translate("MainWindow", "List 6"))
        ui.pb77.setText(_translate("MainWindow", "Run"))
        ui.lb77.setText(_translate("MainWindow", "uname"))
        ui.lb77_2.setText(_translate("MainWindow", "List system information"))
        ui.lb80.setText(_translate("MainWindow", "w"))
        ui.pb80.setText(_translate("MainWindow", "Run"))
        ui.lb80_2.setText(_translate("MainWindow", "Who is logged in & doing what"))
        ui.lb81_2.setText(_translate("MainWindow", "List users logged on"))
        ui.lb81.setText(_translate("MainWindow", "who"))
        ui.pb81.setText(_translate("MainWindow", "Run"))
        ui.lb82.setText(_translate("MainWindow", "whoami"))
        ui.lb82_2.setText(_translate("MainWindow", "Show effective user id"))
        ui.pb82.setText(_translate("MainWindow", "Run"))
        ui.pb79.setText(_translate("MainWindow", "Run"))
        ui.lb79.setText(_translate("MainWindow", "vmstat"))
        ui.lb79_2.setText(_translate("MainWindow", "Virtual memory statistics"))
        ui.pb83.setText(_translate("MainWindow", "Run"))
        ui.lb83.setText(_translate("MainWindow", "xinput"))
        ui.lb83_2.setText(_translate("MainWindow", "List of available input devices"))
        ui.lb99.setText(_translate("MainWindow", "versions"))
        ui.lb99_2.setText(_translate("MainWindow", "List version information"))
        ui.pb99.setText(_translate("MainWindow", "Run"))
        ui.pb79_2.setText(_translate("MainWindow", "Man"))
        ui.pb83_2.setText(_translate("MainWindow", "Man"))
        ui.pb99_2.setText(_translate("MainWindow", "Man"))
        ui.pb82_2.setText(_translate("MainWindow", "Man"))
        ui.pb81_2.setText(_translate("MainWindow", "Man"))
        ui.pb80_2.setText(_translate("MainWindow", "Man"))
        ui.pb77_2.setText(_translate("MainWindow", "Man"))
        ui.pb77_3.setText(_translate("MainWindow", "Man"))
        ui.lb77_3.setText(_translate("MainWindow", "list directories in a tree-like format"))
        ui.pb77_4.setText(_translate("MainWindow", "Run"))
        ui.lb77_4.setText(_translate("MainWindow", "tree"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_7), _translate("MainWindow", "List 7"))
        ui.cbList.setCurrentText(_translate("MainWindow", "select"))
        ui.cbList.setItemText(0, _translate("MainWindow", "select"))
        ui.pbRefreshList.setText(_translate("MainWindow", "Refresh List"))
        ui.pbEditFile.setText(_translate("MainWindow", "Edit File"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_8), _translate("MainWindow", "LECC List"))
        ui.pb8_2.setText(_translate("MainWindow", "Man"))
        ui.pb4_2.setText(_translate("MainWindow", "Man"))
        ui.lb8.setText(_translate("MainWindow", "btop"))
        ui.lb7.setText(_translate("MainWindow", "atop"))
        ui.pb4.setText(_translate("MainWindow", "Run"))
        ui.pb8.setText(_translate("MainWindow", "Run"))
        ui.pb7_2.setText(_translate("MainWindow", "Man"))
        ui.pb7.setText(_translate("MainWindow", "Run"))
        ui.lb4.setText(_translate("MainWindow", "bpytop"))
        ui.lb8_2.setText(_translate("MainWindow", "Shows usages: cpu, mem, disks, net, procs"))
        ui.lb7_2.setText(_translate("MainWindow", "Advanced System & Process Monitor"))
        ui.lb4_2.setText(_translate("MainWindow", "Resource monitor"))
        ui.lb88_2.setText(_translate("MainWindow", "Shows real-time processes"))
        ui.pb88.setText(_translate("MainWindow", "Run"))
        ui.lb88.setText(_translate("MainWindow", "htop"))
        ui.pb88_2.setText(_translate("MainWindow", "Man"))
        ui.lb61_2.setText(_translate("MainWindow", "Nvidia processes"))
        ui.pb61.setText(_translate("MainWindow", "Run"))
        ui.lb61.setText(_translate("MainWindow", "nvtop"))
        ui.pb61_2.setText(_translate("MainWindow", "Man"))
        ui.pb95_2.setText(_translate("MainWindow", "Man"))
        ui.lb95_2.setText(_translate("MainWindow", "Qt app to display processes"))
        ui.lb95.setText(_translate("MainWindow", "qps"))
        ui.pb95.setText(_translate("MainWindow", "Run"))
        ui.lb76_2.setText(_translate("MainWindow", "Shows real-time processes"))
        ui.lb76.setText(_translate("MainWindow", "top"))
        ui.pb76.setText(_translate("MainWindow", "Run"))
        ui.pb76_2.setText(_translate("MainWindow", "Man"))
        ui.pb75.setText(_translate("MainWindow", "Run"))
        ui.lb75.setText(_translate("MainWindow", "system monitor"))
        ui.lb75_2.setText(_translate("MainWindow", "Monitors system processes"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_9), _translate("MainWindow", "Process Viewers"))
        ui.lb39_2.setText(_translate("MainWindow", "o/s settings"))
        ui.lb39_3.setText(_translate("MainWindow", "o/s info"))
        ui.pb39_2.setText(_translate("MainWindow", "Run"))
        ui.lb39_4.setText(_translate("MainWindow", "o/s information"))
        ui.pb39.setText(_translate("MainWindow", "Run"))
        ui.lb39.setText(_translate("MainWindow", "o/s settings"))
        ui.lb1.setText(_translate("MainWindow", "About/Center/Hello/Welcome"))
        ui.lb1_2.setText(_translate("MainWindow", "System Information"))
        ui.pb1.setText(_translate("MainWindow", "Run"))
        ui.lb39_5.setText(_translate("MainWindow", "o/s info (if installed & works then choose)"))
        ui.lb39_6.setText(_translate("MainWindow", "kinfocenter kcm_about-distro"))
        ui.pb39_3.setText(_translate("MainWindow", "Run"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_10), _translate("MainWindow", "Settings/Info"))
        ui.lb59.setText(_translate("MainWindow", "nvidia-smi"))
        ui.pb60_2.setText(_translate("MainWindow", "Man"))
        ui.lb59_2.setText(_translate("MainWindow", "Nvidia GPU driver/device(s)"))
        ui.pb60.setText(_translate("MainWindow", "Run"))
        ui.lb60_2.setText(_translate("MainWindow", "Nvidia server settings"))
        ui.pb59_2.setText(_translate("MainWindow", "Man"))
        ui.pb59.setText(_translate("MainWindow", "Run"))
        ui.lb60.setText(_translate("MainWindow", "nvidia-settings"))
        ui.lb72.setText(_translate("MainWindow", "rhythmbox"))
        ui.pb72.setText(_translate("MainWindow", "Run"))
        ui.pb72_2.setText(_translate("MainWindow", "Man"))
        ui.lb72_2.setText(_translate("MainWindow", "Rhythmbox music player"))
        ui.lb78.setText(_translate("MainWindow", "vlc"))
        ui.lb78_2.setText(_translate("MainWindow", "Media player"))
        ui.pb78.setText(_translate("MainWindow", "Run"))
        ui.pb78_2.setText(_translate("MainWindow", "Man"))
        ui.lb78_3.setText(_translate("MainWindow", "Media player"))
        ui.pb78_3.setText(_translate("MainWindow", "Man"))
        ui.pb78_4.setText(_translate("MainWindow", "Run"))
        ui.lb78_4.setText(_translate("MainWindow", "celluloid"))
        ui.tabWidget.setTabText(ui.tabWidget.indexOf(ui.tab_11), _translate("MainWindow", "Video/Music"))
        ui.menuFile.setTitle(_translate("MainWindow", "&File"))
        ui.menuHelp.setTitle(_translate("MainWindow", "&Help"))
        ui.menu_Forum.setTitle(_translate("MainWindow", "UR&Ls"))
        ui.menuStyle.setTitle(_translate("MainWindow", "&Style"))
        ui.menu_Outputs.setTitle(_translate("MainWindow", "&Outputs"))
        ui.menu_License.setTitle(_translate("MainWindow", "Lice&nse"))
        ui.actionExit.setText(_translate("MainWindow", "E&xit"))
        ui.actionAbout.setText(_translate("MainWindow", "About"))
        ui.actionNotes.setText(_translate("MainWindow", "Notes"))
        ui.actionCommands.setText(_translate("MainWindow", "Commands"))
        ui.action_urls.setIconText(_translate("MainWindow", "Forum"))
        ui.action_urls.setToolTip(_translate("MainWindow", "Forum"))
        ui.action_distrowatch.setText(_translate("MainWindow", "&DistroWatch"))
        ui.actionUpdate_List.setText(_translate("MainWindow", "Update List"))
        ui.actiontestlabel.setText(_translate("MainWindow", "testlabel"))
        ui.action_forum.setText(_translate("MainWindow", "&Forum"))
        ui.actionAbout_3.setText(_translate("MainWindow", "&About"))
        ui.actionNotes_2.setText(_translate("MainWindow", "&Notes"))
        ui.actionCommands_2.setText(_translate("MainWindow", "&Commands"))
        ui.actionTesting.setText(_translate("MainWindow", "&Testing"))
        ui.actionLicense_Copyright.setText(_translate("MainWindow", "&License/Copyright"))
        ui.actionGray.setText(_translate("MainWindow", "&Gray"))
        ui.actionLight.setText(_translate("MainWindow", "Light"))
        ui.actionDark_Gray.setText(_translate("MainWindow", "Dark Gray"))
        ui.actionDark_Dark.setText(_translate("MainWindow", "Dark Dark"))
        ui.actionBlue.setText(_translate("MainWindow", "&Blue"))
        ui.actionGreen.setText(_translate("MainWindow", "G&reen"))
        ui.actionTeal.setText(_translate("MainWindow", "&Teal"))
        ui.actionDark.setText(_translate("MainWindow", "&Dark"))
        ui.actionLight_2.setText(_translate("MainWindow", "&Light"))
        ui.actionDark_Dark_2.setText(_translate("MainWindow", "Dar&k Dark"))
        ui.actionSend_to_text_file.setText(_translate("MainWindow", "Send to text &file"))
        ui.actionSend_to_terminal.setText(_translate("MainWindow", "Send to &terminal"))
        ui.actionSend_to_text_file_2.setText(_translate("MainWindow", "Send to text &file"))
        ui.actionSend_to_terminal_2.setText(_translate("MainWindow", "&Send to terminal"))
        ui.actionLGPL_3_0.setText(_translate("MainWindow", "&LGPL 3.0"))
        ui.action_Cocoa.setText(_translate("MainWindow", "&Cocoa"))
        ui.actionCyan.setText(_translate("MainWindow", "C&yan"))
        ui.actionTan.setText(_translate("MainWindow", "Tan"))

    # my functions
    @staticmethod
    def settaborders():
        # tab 1
        MainWindow.setTabOrder(ui.tab_1, ui.pb6)
        MainWindow.setTabOrder(ui.pb6, ui.pb6_2)
        MainWindow.setTabOrder(ui.pb6_2, ui.cb6)
        MainWindow.setTabOrder(ui.cb6, ui.pb101)
        MainWindow.setTabOrder(ui.pb101, ui.pb101_2)
        MainWindow.setTabOrder(ui.pb101_2, ui.cb101)
        MainWindow.setTabOrder(ui.cb101, ui.pb2)
        MainWindow.setTabOrder(ui.pb2, ui.pb2_2)
        MainWindow.setTabOrder(ui.pb2_2, ui.pb5)
        MainWindow.setTabOrder(ui.pb5, ui.pb5_2)
        MainWindow.setTabOrder(ui.pb5_2, ui.cb5)
        MainWindow.setTabOrder(ui.cb5, ui.pb9_4)
        MainWindow.setTabOrder(ui.pb9_4, ui.pb9)
        MainWindow.setTabOrder(ui.pb9, ui.pb9_2)
        MainWindow.setTabOrder(ui.pb9_2, ui.pb10)
        MainWindow.setTabOrder(ui.pb10, ui.pb10_2)
        MainWindow.setTabOrder(ui.pb10_2, ui.pb86)
        MainWindow.setTabOrder(ui.pb86, ui.pb86_2)
        MainWindow.setTabOrder(ui.pb86_2, ui.cb86)
        MainWindow.setTabOrder(ui.cb86, ui.pb11)
        MainWindow.setTabOrder(ui.pb11, ui.pb11_2)
        MainWindow.setTabOrder(ui.pb11_2, ui.pb12)
        MainWindow.setTabOrder(ui.pb12, ui.pb12_2)
        MainWindow.setTabOrder(ui.pb12_2, ui.pb13)
        MainWindow.setTabOrder(ui.pb13, ui.pb13_2)
        MainWindow.setTabOrder(ui.pb13_2, ui.cb13)
        MainWindow.setTabOrder(ui.cb13, ui.pb13_4)
        MainWindow.setTabOrder(ui.pb13_4, ui.pb13_3)
        MainWindow.setTabOrder(ui.pb13_3, ui.cb13_2)
        MainWindow.setTabOrder(ui.cb13_2, ui.pb14_4)
        MainWindow.setTabOrder(ui.pb14_4, ui.pb14_3)
        MainWindow.setTabOrder(ui.pb14_3, ui.tab_1)

        # tab 2
        MainWindow.setTabOrder(ui.tab_2, ui.pb15)
        MainWindow.setTabOrder(ui.pb15, ui.pb15_2)
        MainWindow.setTabOrder(ui.pb15_2, ui.cb15)
        MainWindow.setTabOrder(ui.cb15, ui.pb16)
        MainWindow.setTabOrder(ui.pb16, ui.pb16_2)
        MainWindow.setTabOrder(ui.pb16_2, ui.pb17)
        MainWindow.setTabOrder(ui.pb17, ui.pb102)
        MainWindow.setTabOrder(ui.pb102, ui.pb102_2)
        MainWindow.setTabOrder(ui.pb102_2, ui.cb102)
        MainWindow.setTabOrder(ui.cb102, ui.pb18)
        MainWindow.setTabOrder(ui.pb18, ui.pb18_2)
        MainWindow.setTabOrder(ui.pb18_2, ui.pb19)
        MainWindow.setTabOrder(ui.pb19, ui.pb19_2)
        MainWindow.setTabOrder(ui.pb19_2, ui.pb20)
        MainWindow.setTabOrder(ui.pb20, ui.pb20_2)
        MainWindow.setTabOrder(ui.pb20_2, ui.pb21)
        MainWindow.setTabOrder(ui.pb21, ui.pb21_2)
        MainWindow.setTabOrder(ui.pb22, ui.pb22_2)
        MainWindow.setTabOrder(ui.pb22_2, ui.cb22)
        MainWindow.setTabOrder(ui.cb22, ui.pb23)
        MainWindow.setTabOrder(ui.pb23, ui.pb23_2)
        MainWindow.setTabOrder(ui.pb23_2, ui.cb23)
        MainWindow.setTabOrder(ui.cb23, ui.pb24)
        MainWindow.setTabOrder(ui.pb24, ui.pb24_2)
        MainWindow.setTabOrder(ui.pb24_2, ui.pb93)
        MainWindow.setTabOrder(ui.pb93, ui.pb93_2)
        MainWindow.setTabOrder(ui.pb93_2, ui.pb25)
        MainWindow.setTabOrder(ui.pb25, ui.pb25_2)
        MainWindow.setTabOrder(ui.pb25_2, ui.tab_2)

        # tab 3
        MainWindow.setTabOrder(ui.tab_3, ui.pb26)
        MainWindow.setTabOrder(ui.pb26, ui.pb26_2)
        MainWindow.setTabOrder(ui.pb26_2, ui.pb27)
        MainWindow.setTabOrder(ui.pb27, ui.pb27_2)
        MainWindow.setTabOrder(ui.pb27_2, ui.pb89)
        MainWindow.setTabOrder(ui.pb89, ui.pb89_2)
        MainWindow.setTabOrder(ui.pb89_2, ui.pb89_2)
        MainWindow.setTabOrder(ui.pb89_2, ui.pb106)
        MainWindow.setTabOrder(ui.pb106_2, ui.pb28)
        MainWindow.setTabOrder(ui.pb28, ui.pb28_2)
        MainWindow.setTabOrder(ui.pb28_2, ui.pb29)
        MainWindow.setTabOrder(ui.pb29, ui.pb29_2)
        MainWindow.setTabOrder(ui.pb29_2, ui.pb30)
        MainWindow.setTabOrder(ui.pb30, ui.pb30_2)
        MainWindow.setTabOrder(ui.pb30_2, ui.pb31)
        MainWindow.setTabOrder(ui.pb31, ui.pb31_2)
        MainWindow.setTabOrder(ui.pb31_2, ui.pb32)
        MainWindow.setTabOrder(ui.pb32, ui.pb32_2)
        MainWindow.setTabOrder(ui.pb32_2, ui.pb103)
        MainWindow.setTabOrder(ui.pb103, ui.pb103_2)
        MainWindow.setTabOrder(ui.pb103_2, ui.pb91_3)
        MainWindow.setTabOrder(ui.pb91_3, ui.pb91_4)
        MainWindow.setTabOrder(ui.pb91_4, ui.pb33)
        MainWindow.setTabOrder(ui.pb33, ui.pb33_2)
        MainWindow.setTabOrder(ui.pb33_2, ui.cb33)
        MainWindow.setTabOrder(ui.cb33, ui.pb91)
        MainWindow.setTabOrder(ui.pb91, ui.pb91_2)
        MainWindow.setTabOrder(ui.pb91_2, ui.tab_3)

        # tab 4
        MainWindow.setTabOrder(ui.tab_4, ui.pb34)
        MainWindow.setTabOrder(ui.pb34, ui.pb34_2)
        MainWindow.setTabOrder(ui.pb34_2, ui.pb35)
        MainWindow.setTabOrder(ui.pb35, ui.pb35_2)
        MainWindow.setTabOrder(ui.pb35_2, ui.pb36)
        MainWindow.setTabOrder(ui.pb36, ui.pb36_2)
        MainWindow.setTabOrder(ui.pb36_2, ui.cb36)
        MainWindow.setTabOrder(ui.cb36, ui.pb37)
        MainWindow.setTabOrder(ui.pb37, ui.pb37_2)
        MainWindow.setTabOrder(ui.pb37_2, ui.cb37)
        MainWindow.setTabOrder(ui.cb37, ui.pb35_3)
        MainWindow.setTabOrder(ui.pb35_3, ui.pb35_4)
        MainWindow.setTabOrder(ui.pb35_4, ui.pb38)
        MainWindow.setTabOrder(ui.pb38, ui.pb38_2)
        MainWindow.setTabOrder(ui.pb38_2, ui.cb38)
        MainWindow.setTabOrder(ui.cb38, ui.pb47_4)
        MainWindow.setTabOrder(ui.pb47_4, ui.pb47_3)
        MainWindow.setTabOrder(ui.pb47_3, ui.pb42)
        MainWindow.setTabOrder(ui.pb42, ui.pb42_2)
        MainWindow.setTabOrder(ui.pb42_2, ui.pb40)
        MainWindow.setTabOrder(ui.pb40, ui.pb40_2)
        MainWindow.setTabOrder(ui.pb40_2, ui.cb40)
        MainWindow.setTabOrder(ui.cb40, ui.pb44)
        MainWindow.setTabOrder(ui.pb44, ui.pb44_2)
        MainWindow.setTabOrder(ui.pb44_2, ui.cb44)
        MainWindow.setTabOrder(ui.cb44, ui.pb45)
        MainWindow.setTabOrder(ui.pb45, ui.pb45_2)
        MainWindow.setTabOrder(ui.pb45_2, ui.pb46)
        MainWindow.setTabOrder(ui.pb46, ui.pb46_2)
        MainWindow.setTabOrder(ui.pb46_2, ui.pb47)
        MainWindow.setTabOrder(ui.pb47, ui.pb47_2)
        MainWindow.setTabOrder(ui.pb47_2, ui.pb48)
        MainWindow.setTabOrder(ui.pb48, ui.pb48_2)
        MainWindow.setTabOrder(ui.pb48_2, ui.tab_4)

        # tab 5
        MainWindow.setTabOrder(ui.tab_5, ui.pb90_3)
        MainWindow.setTabOrder(ui.pb90_3, ui.pb90_4)
        MainWindow.setTabOrder(ui.pb90_4, ui.pb90)
        MainWindow.setTabOrder(ui.pb90, ui.pb90_2)
        MainWindow.setTabOrder(ui.pb90_2, ui.pb49)
        MainWindow.setTabOrder(ui.pb49, ui.pb49_2)
        MainWindow.setTabOrder(ui.pb49_2, ui.pb50)
        MainWindow.setTabOrder(ui.pb50, ui.pb50_2)
        MainWindow.setTabOrder(ui.pb50_2, ui.pb51)
        MainWindow.setTabOrder(ui.pb51, ui.pb51_2)
        MainWindow.setTabOrder(ui.pb51_2, ui.pb52)
        MainWindow.setTabOrder(ui.pb52, ui.pb52_2)
        MainWindow.setTabOrder(ui.pb52_2, ui.cb52)
        MainWindow.setTabOrder(ui.cb52, ui.pb94)
        MainWindow.setTabOrder(ui.pb94, ui.pb94_2)
        MainWindow.setTabOrder(ui.pb94_2, ui.cb94)
        MainWindow.setTabOrder(ui.cb94, ui.pb84)
        MainWindow.setTabOrder(ui.pb84, ui.pb84_2)
        MainWindow.setTabOrder(ui.pb84_2, ui.pb55)
        MainWindow.setTabOrder(ui.pb55, ui.pb55_2)
        MainWindow.setTabOrder(ui.pb55_2, ui.pb57)
        MainWindow.setTabOrder(ui.pb57, ui.pb57_2)
        MainWindow.setTabOrder(ui.pb57_2, ui.cb57)
        MainWindow.setTabOrder(ui.cb57, ui.pb58)
        MainWindow.setTabOrder(ui.pb58, ui.pb58_2)
        MainWindow.setTabOrder(ui.pb58_2, ui.pb87)
        MainWindow.setTabOrder(ui.pb87, ui.pb87_2)
        MainWindow.setTabOrder(ui.pb87_2, ui.pb108)
        MainWindow.setTabOrder(ui.pb108, ui.pb108_2)
        MainWindow.setTabOrder(ui.pb108_2, ui.cb108)
        MainWindow.setTabOrder(ui.cb108, ui.tab_5)

        # tab 6
        MainWindow.setTabOrder(ui.tab_6, ui.pb110)
        MainWindow.setTabOrder(ui.pb110, ui.pb105)
        MainWindow.setTabOrder(ui.pb105, ui.pb105_2)
        MainWindow.setTabOrder(ui.pb105_2, ui.pb64)
        MainWindow.setTabOrder(ui.pb64, ui.pb64_2)
        MainWindow.setTabOrder(ui.pb64_2, ui.pb65)
        MainWindow.setTabOrder(ui.pb65, ui.pb65_2)
        MainWindow.setTabOrder(ui.pb65_2, ui.pb69_4)
        MainWindow.setTabOrder(ui.pb69_4, ui.pb69_3)
        MainWindow.setTabOrder(ui.pb69_3, ui.pb66)
        MainWindow.setTabOrder(ui.pb66, ui.pb66_2)
        MainWindow.setTabOrder(ui.pb66_2, ui.cb66)
        MainWindow.setTabOrder(ui.cb66, ui.pb68)
        MainWindow.setTabOrder(ui.pb68, ui.pb68_2)
        MainWindow.setTabOrder(ui.pb68_2, ui.pb69)
        MainWindow.setTabOrder(ui.pb69, ui.pb69_2)
        MainWindow.setTabOrder(ui.pb69_2, ui.pb70)
        MainWindow.setTabOrder(ui.pb70, ui.pb71)
        MainWindow.setTabOrder(ui.pb71, ui.pb71_2)
        MainWindow.setTabOrder(ui.pb71_2, ui.pb73)
        MainWindow.setTabOrder(ui.pb73, ui.pb73_2)
        MainWindow.setTabOrder(ui.pb73_2, ui.cb73)
        MainWindow.setTabOrder(ui.cb73, ui.pb74)
        MainWindow.setTabOrder(ui.pb74, ui.pb74_2)
        MainWindow.setTabOrder(ui.pb74_2, ui.tab_6)

        # tab 7
        MainWindow.setTabOrder(ui.tab_7, ui.pb77_4)
        MainWindow.setTabOrder(ui.pb77_4, ui.pb77_3)
        MainWindow.setTabOrder(ui.pb77_3, ui.cb77_2)
        MainWindow.setTabOrder(ui.cb77_2, ui.pb77)
        MainWindow.setTabOrder(ui.pb77, ui.pb77_2)
        MainWindow.setTabOrder(ui.pb77_2, ui.cb77)
        MainWindow.setTabOrder(ui.cb77, ui.pb79)
        MainWindow.setTabOrder(ui.pb79, ui.pb79_2)
        MainWindow.setTabOrder(ui.pb79_2, ui.cb79)
        MainWindow.setTabOrder(ui.cb79, ui.pb80)
        MainWindow.setTabOrder(ui.pb80, ui.pb80_2)
        MainWindow.setTabOrder(ui.pb80_2, ui.pb81)
        MainWindow.setTabOrder(ui.pb81, ui.pb81_2)
        MainWindow.setTabOrder(ui.pb81_2, ui.pb82)
        MainWindow.setTabOrder(ui.pb82, ui.pb82_2)
        MainWindow.setTabOrder(ui.pb82_2, ui.pb83)
        MainWindow.setTabOrder(ui.pb83, ui.pb83_2)
        MainWindow.setTabOrder(ui.pb83_2, ui.cb83)
        MainWindow.setTabOrder(ui.cb83, ui.pb99)
        MainWindow.setTabOrder(ui.pb99, ui.pb99_2)
        MainWindow.setTabOrder(ui.pb99_2, ui.cb99)
        MainWindow.setTabOrder(ui.cb99, ui.tab_7)

        # tab lecc list
        MainWindow.setTabOrder(ui.tab_8, ui.cbList)
        MainWindow.setTabOrder(ui.cbList, ui.pbRefreshList)
        MainWindow.setTabOrder(ui.pbRefreshList, ui.pbEditFile)
        MainWindow.setTabOrder(ui.pbEditFile, ui.tab_8)

        # process viewers
        MainWindow.setTabOrder(ui.tab_9, ui.pb7)
        MainWindow.setTabOrder(ui.pb7, ui.pb7_2)
        MainWindow.setTabOrder(ui.pb7_2, ui.cb7)
        MainWindow.setTabOrder(ui.cb7, ui.pb4)
        MainWindow.setTabOrder(ui.pb4, ui.pb4_2)
        MainWindow.setTabOrder(ui.pb4_2, ui.pb8)
        MainWindow.setTabOrder(ui.pb8, ui.pb8_2)
        MainWindow.setTabOrder(ui.pb8_2, ui.pb88)
        MainWindow.setTabOrder(ui.pb88, ui.pb88_2)
        MainWindow.setTabOrder(ui.pb88_2, ui.pb61)
        MainWindow.setTabOrder(ui.pb61, ui.pb61_2)
        MainWindow.setTabOrder(ui.pb61_2, ui.pb95)
        MainWindow.setTabOrder(ui.pb95, ui.pb95_2)
        MainWindow.setTabOrder(ui.pb95_2, ui.pb75)
        MainWindow.setTabOrder(ui.pb75, ui.pb76)
        MainWindow.setTabOrder(ui.pb76, ui.pb76_2)
        MainWindow.setTabOrder(ui.pb76_2, ui.cb76)
        MainWindow.setTabOrder(ui.cb76, ui.tab_9)

        # tab setting/info
        MainWindow.setTabOrder(ui.tab_10, ui.pb1)
        MainWindow.setTabOrder(ui.pb1, ui.pb39)
        MainWindow.setTabOrder(ui.pb39, ui.pb39_2)
        MainWindow.setTabOrder(ui.pb39_2, ui.cb39)
        MainWindow.setTabOrder(ui.cb39, ui.pb39_3)
        MainWindow.setTabOrder(ui.pb39_3, ui.tab_10)

        # tab video
        MainWindow.setTabOrder(ui.tab_11, ui.pb59)
        MainWindow.setTabOrder(ui.pb59, ui.pb59_2)
        MainWindow.setTabOrder(ui.pb59_2, ui.cb59)
        MainWindow.setTabOrder(ui.cb59, ui.pb60)
        MainWindow.setTabOrder(ui.pb60, ui.pb60_2)
        MainWindow.setTabOrder(ui.pb60_2, ui.pb78_4)
        MainWindow.setTabOrder(ui.pb78_4, ui.pb78_3)
        MainWindow.setTabOrder(ui.pb78_3, ui.pb72)
        MainWindow.setTabOrder(ui.pb72, ui.pb72_2)
        MainWindow.setTabOrder(ui.pb72_2, ui.pb78)
        MainWindow.setTabOrder(ui.pb78, ui.pb78_2)
        MainWindow.setTabOrder(ui.pb78_2, ui.tab_11)

    @staticmethod
    def startupinfo():
        global sssdesc

        global folder_path
        folder_path = subprocess.check_output(['xdg-user-dir', 'DESKTOP']).decode()
        folder_path = folder_path.strip('\n')
        folder_path = folder_path + "/LECC"
        isexist = os.path.exists(folder_path)
        if isexist is False:
            try:
                os.mkdir(folder_path, 0o0777)
            except OSError:
                # possibly a permissions problem
                ui.displayerror("Critical!", "LECC directory creation failed.",
                                "Maybe a permissions problem.", "(startupinfo)", "0")

        unameis = getpass.getuser()
        ui.lbnotices.setText('Welcome  ' + unameis)

        # get desktop
        # DESKTOP_SESSION, XDG_SESSION_DESKTOP, XDG_CURRENT_DESKTOP (more accurate)
        global pcds
        pcds = str(os.environ.get('XDG_CURRENT_DESKTOP')).title()
        pcds = pcds.replace("plasmawayland", "plasma wayland").title()
        pcds = pcds.replace("Plasmawayland", "plasma wayland").title()
        pcds = pcds.replace('00_', '')
        if pcds == 'Kde' or pcds == 'Plasma':
            pcds = "KDE Plasma"

        pcism = platform.machine()
        # pckernel = platform.release()
        di = pn = vc = ol = bid = ''

        # /etc/lsb-release (small info), /etc/os-release, /usr/lib/os-release, /usr/bin/lsb_release
        # CachyOS, Debian, Endeavour, Feren, Garuda, KDE Neon, Kubuntu, Lite, LMDE,
        # Manjaro, Mint, MX, Neptune, Nobara, Parrot, Q4OS, Solus, Sparky, Ubuntu

        file_exists1 = exists('/etc/lsb-release')
        # file_exists2 = exists('/usr/lib/os-release')
        # file_exists3 = exists('/etc/manjaro-release')
        # there is also /usr/bin/lsb_release to run with -a switch

        # move 'q 4 os' might be able to remove
        q4osexists = 'n'
        if os.path.isdir('/etc/q4os'):
            q4osexists = 'y'
            # get-q4os-version
            proc = subprocess.Popen("get-q4os-version", stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True)
            stdout = proc.communicate()
            if proc.returncode == 0:
                q4osv = stdout[0]
                q4osv = q4osv.replace("\n", "")
            proc.terminate()

        distrogaruda = exists('/etc/garuda')
        if distrogaruda is True:
            if file_exists1:
                cmd = "cat /etc/lsb-release"
                proc0 = subprocess.Popen(cmd.split(), stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True)
                stdout = proc0.communicate()
                if proc0.returncode == 0:
                    fkgname = stdout[0].splitlines()
                    for inf in fkgname:
                        if 'DISTRIB_DESCRIPTION=' in inf:
                            pn = inf.replace('DISTRIB_DESCRIPTION', '')
                            pn = pn.replace('"', '')
                            pn = pn.replace('=', '')
                            pn = pn.replace('Linux', '')
                            pn = pn.replace('  ', ' ')
                            pn = pn.title()
                    # start building distro info
                    ol = pn.strip() + ', ' + pcds + ',  ' + pcism
                    ol = ol.replace(', ,', ',')
                proc0.terminate()
                sssdesc = ol
                return sssdesc

        distromx = exists('/usr/share/mx-welcome')
        if distromx is True:
            di = 'MX'
            if file_exists1:
                cmd = "cat /etc/lsb-release"
                proc0 = subprocess.Popen(cmd.split(), stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True)
                stdout = proc0.communicate()
                if proc0.returncode == 0:
                    fkgname = stdout[0].splitlines()
                    for inf in fkgname:
                        if 'PRETTY_NAME=' in inf:
                            pn = inf.replace('PRETTY_NAME', '')
                            pn = pn.replace('"', '')
                            pn = pn.replace('=', '')
                            pn = pn.title()
                    # start building distro info
                    ol = pn.strip() + ', ' + pcds + ',  ' + pcism
                    ol = ol.replace(', ,', ',')
                proc0.terminate()
                sssdesc = ol
                return sssdesc

        file_exists0 = exists('/etc/os-release')    # should work well enough for all distros
        if file_exists0:
            cmd = "cat /etc/os-release"
            proc0 = subprocess.Popen(cmd.split(), stdin=PIPE, stdout=PIPE, stderr=PIPE,
                                     universal_newlines=True, text=True)
            stdout = proc0.communicate()
            if proc0.returncode == 0:
                fkgname = stdout[0].splitlines()
                for inf in fkgname:
                    if 'BUILD_ID=' in inf:
                        bid = inf.replace("BUILD_ID=", '')
                        bid = bid.title()
                    if 'PRETTY_NAME=' in inf:
                        pn = inf.replace('PRETTY_NAME', '')
                        pn = pn.replace('"', '')
                        pn = pn.replace('=', '')
                        pn = pn.title()
                    if 'VERSION_CODENAME=' in inf:
                        vc = inf.replace('VERSION_CODENAME', '')
                        vc = vc.replace('"', '')
                        vc = vc.replace('=', '')
                        vc = vc.title()
                # these should be okay: Mint, Kubuntu, Lite, Neptune, Kde Neon, Manjaro
                if 'Parrot' in pn or 'MX' in pn or 'Debian' in pn or 'Endeavour' in pn or 'Garuda' in pn or \
                   'Solus' in pn or 'Sparky' in pn or 'Nobara' in pn:
                    vc = ''
                # start building distro info
                if len(vc) < 1 and len(bid) > 0:
                    vc = bid
                ol = pn.strip() + ', ' + vc + ', ' + pcds + ', ' + pcism
                ol = ol.replace(', ,', ',')
            proc0.terminate()
            # overrides
            if len(di) > 0:
                ol = di + " " + ol
            if q4osexists == 'y':
                ol = 'Q4OS ' + ol
            # finally
            ol = ol.replace('Linux', ' ')
            ol = ol.replace('Gnu/', '')
            ol = ol.replace('GNU/', '')
            ol = ol.replace('Ubuntu:Gnome', 'Gnome')
            ol = ol.replace('Cachyos', 'CachyOS')
            ol = ol.replace('  ', ' ')
            ol = ol.replace('  ', ' ')
            sssdesc = ol
            return sssdesc

    @staticmethod
    def passrtn(mainwindow):
        stext = " Enter your password or continue without it. It's not mandatory."
        stext = stext + "\n Sometimes to access a specific file or program a password is required.\n"
        stext = stext + "\n A password is most likely required for the following: "
        stext = stext + "\n'cat (grub.cfg and slabinfo), df, dmidecode, du, fdisk, find, \n"
        stext = stext + "gparted(prompt), gufw(prompt), hdparm, history, os-prober, parted'\n"
        mepaswrd, ok = QInputDialog.getText(mainwindow, "Welcome!", stext, QLineEdit.EchoMode.Password)
        if ok is False:
            sys.exit()
        global mypass
        mypass = mepaswrd

    @staticmethod
    def loadfolderlist():
        ui.cbList.setEditable(True)
        ui.cbList.setMaxVisibleItems(24)
        ui.cbList.lineEdit().setReadOnly(True)
        ui.cbList.setStyleSheet("QComboBox""{""background-color: white""}")
        ui.cbList.update()
        path_slist = os.listdir(folder_path)
        path_slist.sort()
        ui.cbList.clear()
        ui.cbList.addItem('Select')
        for x in path_slist:
            if x != '.txt':
                ui.cbList.addItem(x)

    @staticmethod
    def loadforumslist():
        if 'Debian' in sssdesc:
            if 'MX' not in sssdesc and 'Q4OS' not in sssdesc:
                ui.urlcall('https://forums.debian.net/')
        if 'Endeavour' in sssdesc:
            ui.urlcall('https://forum.endeavouros.com/')
        if 'Garuda' in sssdesc:
            ui.urlcall('https://forum.garudalinux.org/')
        if 'KDE' in sssdesc:
            if 'Kde' in sssdesc and 'Q4OS' not in sssdesc:
                ui.urlcall('https://discuss.kde.org/')
        if 'Lite' in sssdesc:
            ui.urlcall('https://www.linuxliteos.com/forums/index.php')
        if 'MX' in sssdesc or 'Mx' in sssdesc:
            ui.urlcall("https://forum.mxlinux.org/")
        if 'MANJARO' in sssdesc or 'Manjaro' in sssdesc:
            ui.urlcall('https://forum.manjaro.org/')
        if 'Mint' in sssdesc or 'LMDE' in sssdesc:
            ui.urlcall('https://forums.linuxmint.com/')
        if 'Nobara' in sssdesc:
            ui.urlcall('https://www.reddit.com/r/NobaraProject/')
        if 'Neptune' in sssdesc:
            ui.urlcall('https://neptuneos.com/en/start-page.html/')
        if 'Parrot' in sssdesc:
            ui.urlcall('https://community.parrotsec.org/')
        if 'Q4OS' in sssdesc:
            ui.urlcall('https://www.q4os.org/forum/')
        if 'Solus' in sssdesc:
            ui.urlcall('https://discuss.getsol.us/')
        if 'Ubuntu' in sssdesc and 'KDE Plasma' in pcds:
            ui.urlcall('https://www.kubuntuforums.net/')
        if 'Ubuntu' in sssdesc and 'Kubuntu' not in sssdesc:
            ui.urlcall('https://www.ubuntuforums.org/')

    @staticmethod
    def urlcall(urlis):
        # assign default browser in default applications !!
        webbrowser.open_new_tab(urlis)

    @staticmethod
    def widgetstyles():
        # buttons run
        ui.pb1.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb6.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb7.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb2.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb4.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb8.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb5.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb9.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb10.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb86.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb11.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb12.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb13.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb15.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb16.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb17.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb18.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb19.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb20.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb21.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb22.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb23.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb24.setStyleSheet("""
                     QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb93.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb25.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb26.setStyleSheet("""
                      QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb27.setStyleSheet("""
                     QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb89.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb28.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb29.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb30.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb31.setStyleSheet("""
                     QPushButton::focus{color: darkcyan; font-size: 15px;}
                     QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb32.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb33.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb88.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb34.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb35.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb36.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb37.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb38.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb39.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb40.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb42.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb44.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb45.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb46.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb47.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb48.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb90.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb49.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb50.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb51.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb52.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb84.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb52.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb55.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb57.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb58.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb87.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb59.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb60.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb61.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb64.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb65.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb66.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb68.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb69.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb70.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb71.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb72.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb73.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb74.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb75.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb76.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb77.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb78.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb79.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb80.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb81.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb82.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb83.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb91.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb94.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb95.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pb99.setStyleSheet("""
                              QPushButton::focus{color: darkcyan; font-size: 15px;}
                              QPushButton:hover{color: magenta; font-size: 15px;}
                              QPushButton:hover:pressed{color: orange;}
                              QPushButton:pressed{color: green; font-size: 15px;}
                              """)
        ui.pb101.setStyleSheet("""
                               QPushButton::focus{color: darkcyan; font-size: 15px;}
                               QPushButton:hover{color: magenta; font-size: 15px;}
                               QPushButton:hover:pressed{color: orange;}
                               QPushButton:pressed{color: green; font-size: 15px;}
                               """)
        ui.pb102.setStyleSheet("""
                               QPushButton::focus{color: darkcyan; font-size: 15px;}
                               QPushButton:hover{color: magenta; font-size: 15px;}
                               QPushButton:hover:pressed{color: orange;}
                               QPushButton:pressed{color: green; font-size: 15px;}
                               """)
        ui.pb103.setStyleSheet("""
                               QPushButton::focus{color: darkcyan; font-size: 15px;}
                               QPushButton:hover{color: magenta; font-size: 15px;}
                               QPushButton:hover:pressed{color: orange;}
                               QPushButton:pressed{color: green; font-size: 15px;}
                               """)
        ui.pb106.setStyleSheet("""
                               QPushButton::focus{color: darkcyan; font-size: 15px;}
                               QPushButton:hover{color: magenta; font-size: 15px;}
                               QPushButton:hover:pressed{color: orange;}
                               QPushButton:pressed{color: green; font-size: 15px;}
                               """)

        # buttons man
        ui.pb1.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb6_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb7_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb2_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb4_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb8_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb5_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb9_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb10_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb86_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb11_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb12_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb13_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb15_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb16_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb18_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb19_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb20_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb21_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb22_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb23_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb24_2.setStyleSheet("""
                             QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb93_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb25_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb26_2.setStyleSheet("""
                              QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb27_2.setStyleSheet("""
                             QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb89_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb28_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb29_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb30_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb31_2.setStyleSheet("""
                             QPushButton::focus{color: darkcyan; font-size: 15px;}
                             QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb32_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb33_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb88_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb34_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb35_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb36_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb37_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb38_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb40_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb42_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb44_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb45_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb46_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb47_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb48_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb90_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb49_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb50_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb51_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb52_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb84_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb52_2.setStyleSheet("""
                                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                                    QPushButton:hover{color: magenta; font-size: 15px;}
                                    QPushButton:hover:pressed{color: orange;}
                                    QPushButton:pressed{color: green; font-size: 15px;}
                                    """)
        ui.pb55_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb57_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb58_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb87_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb59_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb60_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb61_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb64_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb65_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb66_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb68_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb69_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb71_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb72_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb73_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb74_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb76_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb77_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb78_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb79_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb80_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb81_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb82_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb83_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb91_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb94_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                                    """)
        ui.pb95_2.setStyleSheet("""
                            QPushButton::focus{color: darkcyan; font-size: 15px;}
                            QPushButton:hover{color: magenta; font-size: 15px;}
                            QPushButton:hover:pressed{color: orange;}
                            QPushButton:pressed{color: green; font-size: 15px;}
                            """)
        ui.pb99_2.setStyleSheet("""
                                QPushButton::focus{color: darkcyan; font-size: 15px;}
                                QPushButton:hover{color: magenta; font-size: 15px;}
                                QPushButton:hover:pressed{color: orange;}
                                QPushButton:pressed{color: green; font-size: 15px;}
                                """)
        ui.pb101_2.setStyleSheet("""
                                 QPushButton::focus{color: darkcyan; font-size: 15px;}
                                 QPushButton:hover{color: magenta; font-size: 15px;}
                                 QPushButton:hover:pressed{color: orange;}
                                 QPushButton:pressed{color: green; font-size: 15px;}
                                 """)
        ui.pb102_2.setStyleSheet("""
                                 QPushButton::focus{color: darkcyan; font-size: 15px;}
                                 QPushButton:hover{color: magenta; font-size: 15px;}
                                 QPushButton:hover:pressed{color: orange;}
                                 QPushButton:pressed{color: green; font-size: 15px;}
                                 """)
        ui.pb103_2.setStyleSheet("""
                                 QPushButton::focus{color: darkcyan; font-size: 15px;}
                                 QPushButton:hover{color: magenta; font-size: 15px;}
                                 QPushButton:hover:pressed{color: orange;}
                                 QPushButton:pressed{color: green; font-size: 15px;}
                                 """)
        ui.pb105_2.setStyleSheet("""
                                 QPushButton::focus{color: darkcyan; font-size: 15px;}
                                 QPushButton:hover{color: magenta; font-size: 15px;}
                                 QPushButton:hover:pressed{color: orange;}
                                 QPushButton:pressed{color: green; font-size: 15px;}
                                 """)
        ui.pb106_2.setStyleSheet("""
                                 QPushButton::focus{color: darkcyan; font-size: 15px;}
                                 QPushButton:hover{color: magenta; font-size: 15px;}
                                 QPushButton:hover:pressed{color: orange;}
                                 QPushButton:pressed{color: green; font-size: 15px;}
                                 """)

        ui.pbRefreshList.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)
        ui.pbEditFile.setStyleSheet("""
                    QPushButton::focus{color: darkcyan; font-size: 15px;}
                    QPushButton:hover{color: magenta; font-size: 15px;}
                    QPushButton:hover:pressed{color: orange;}
                    QPushButton:pressed{color: green; font-size: 15px;}
                    """)

    @staticmethod
    def displayforumname():
        if 'Debian' in sssdesc and 'MX' not in sssdesc and 'Q4OS' not in sssdesc:
            ui.action_forum.setText('&Debian Forum!')
        elif 'Garuda' in sssdesc:
            ui.action_forum.setText('&Garuda Forum!')
        elif 'Lite' in sssdesc:
            ui.action_forum.setText('&Lite Forum!')
        elif 'KDE' in sssdesc and 'Neon' in sssdesc and 'Q4OS' not in sssdesc:
            ui.action_forum.setText('&KDE Neon Forum!')
        elif 'Manjaro' in sssdesc:
            ui.action_forum.setText('&Manjaro Forum!')
        elif 'MX' in sssdesc:
            ui.action_forum.setText('&MX Forum!')
        elif 'Mint' in sssdesc or 'LMDE' in sssdesc:
            ui.action_forum.setText('&Mint/LMDE Forums!')
        elif 'Neptune' in sssdesc:
            ui.action_forum.setText('&Neptune Forum!')
        elif 'Nobara' in sssdesc:
            ui.action_forum.setText('&Nobara Forum!')
        elif 'Parrot' in sssdesc:
            ui.action_forum.setText('&Parrot Forum!')
        elif 'Q4OS' in sssdesc:
            ui.action_forum.setText('&Q4OS Forum!')
        elif 'Solus' in sssdesc:
            ui.action_forum.setText('&Solus Forum!')
        elif 'Ubuntu' in sssdesc and 'KDE Plasma' in pcds:
            ui.action_forum.setText('&Kubuntu Forum!')
        elif 'Ubuntu' in sssdesc and 'Kubuntu' not in sssdesc:
            ui.action_forum.setText('&Ubuntu Forum!')
        elif 'Endeavour' in sssdesc:
            ui.action_forum.setText('&Endeavour Forum!')

    @staticmethod
    def displayerror(stitle, stext, stextd, stextmore, inbr):
        # ui.displayerror("Warning!", "'" + str(cmd) + "' Invalid user.", "(popen_function_common)", "", "16")
        notice = stitle.upper() + "  " + stext + "  " + stextd + "  " + stextmore + "  " + inbr
        if stitle == 'Warning!' or stitle == 'Whoops!':
            showthenotice = str(notice)
            ui.lbnotices.setStyleSheet("""QWidget {color: rgb(160, 64, 0);}""")
            ui.lbnotices.setText(showthenotice)
        if stitle == 'Critical!':
            showthenotice = str(notice)
            ui.lbnotices.setStyleSheet("""QWidget {color: rgb(255, 0, 0);}""")
            ui.lbnotices.setText(showthenotice)
        if stitle == 'Information!':
            showthenotice = str(notice)
            ui.lbnotices.setStyleSheet("""QWidget {color: darkcyan;}""")
            ui.lbnotices.setText(showthenotice)
        ui.clearnoticeserrorsmessages()

    @staticmethod
    def displaynotice(notice):
        showthenotice = str('NOTICE: ' + notice)
        ui.lbnotices.setStyleSheet("""QWidget {color: rgb( 11, 83, 69 );}""")
        ui.lbnotices.setText(showthenotice)
        ui.clearnoticeserrorsmessages()

    @staticmethod
    def clearnoticeserrorsmessages():
        MainWindow.repaint()
        # time.sleep(1)
        # ui.lbnotices.clear()

    @staticmethod
    def displayinformation(stitle, stext):
        # help choices
        messbox = QMessageBox()
        if 'Mint' in ssdesc or 'Lite' in ssdesc or 'Garuda' in ssdesc or 'neon' in ssdesc or \
           'Neptune' in ssdesc or 'Ubuntu' in ssdesc or 'Parrot' in ssdesc or 'LMDE' in ssdesc:
            messbox.setStyleSheet("QLabel{min-width: 520px; min-height: 90px; font-size: 10pt}")
        else:
            messbox.setStyleSheet("QLabel{min-width: 600px; min-height: 90px; font-size: 10pt}")
        messbox.setWindowTitle(stitle)
        messbox.setText(stext)
        messbox.setDetailedText('')
        messbox.setInformativeText('')
        messbox.setDefaultButton(QMessageBox.StandardButton.Ok)
        messbox.exec()

    @staticmethod
    def lgplinfo():
        messbox2 = QMessageBox()
        messbox2.setStyleSheet("QLabel{min-width: 370px; min-height: 25px; font-size: 10pt}")
        messbox2.setWindowTitle("LGPL 3.0")
        messbox2.setText("                       GNU GENERAL PUBLIC LICENSE")
        messbox2.setDetailedText("Press OK to view the LGPL 3.0 text online in your browser.")
        messbox2.setInformativeText("https://www.gnu.org/licenses/lgpl-3.0.html#license-text")
        messbox2.setStandardButtons(QMessageBox.StandardButton.Ok | QMessageBox.StandardButton.Close)
        messbox2.setDefaultButton(QMessageBox.StandardButton.Ok)
        messbox2.buttonClicked.connect(ui.btnout)
        messbox2.exec()

    @staticmethod
    def btnout(button):
        print(button.text())
        if button.text() == 'OK' or button.text() == '&OK':
            ui.lgplcall()

    @staticmethod
    def lgplcall():
        webbrowser.open('https://www.gnu.org/licenses/lgpl-3.0.html')

    @staticmethod
    def is_toolbyname(cmd):
        rc = subprocess.call(['whereis', cmd])
        if rc == '0':
            return 'true'
        wtf0 = shutil.which(cmd)
        if wtf0 == 'None' or wtf0 == 'none':
            return 'false'
        wtf2 = which(cmd) is not None
        if wtf2 is True:
            return 'true'
        return 'false'

    @staticmethod
    def is_toolbypath(cmd):
        isfile1 = os.path.isfile('/bin/' + cmd)
        isfile2 = os.path.isfile('/sbin/' + cmd)
        isfile3 = os.path.isfile('/usr/bin/' + cmd)
        isfile4 = os.path.isfile('/usr/sbin/' + cmd)
        isfile5 = os.path.isfile('/usr/local/bin/' + cmd)
        isfile6 = os.path.isfile('/usr/local/sbin/' + cmd)
        isfile7 = os.path.isfile('/usr/games/' + cmd)

        if isfile3 is True:
            return '/usr/bin/' + cmd
        if isfile4 is True:
            return '/usr/sbin/' + cmd
        if isfile1 is True:
            return '/bin/' + cmd
        if isfile2 is True:
            return '/sbin/' + cmd
        if isfile5 is True:
            return '/usr/local/bin/' + cmd
        if isfile6 is True:
            return '/usr/local/sbin/' + cmd
        if isfile7 is True:
            return '/usr/games/' + cmd

        return 'false'

    @staticmethod
    def is_toolexist(cmd):
        isresult1 = ui.is_toolbyname(cmd)
        if isresult1 == 'None' or isresult1 == 'none' or isresult1 == 'false':
            isresult2 = ui.is_toolbypath(cmd)
            if isresult2 == 'not found' or isresult2 == 'none' or isresult2 == 'false':
                return 'false'
            else:
                return isresult2  # path instead of true or false
        else:
            return 'true'

    @staticmethod
    def thread_function_os(cmd):
        # simplified Mint, now try others
        ui.displaynotice("'" + cmd + "' is started!")
        MainWindow.repaint()

        if 'Debian' in sssdesc:
            if 'MX' not in sssdesc and 'Q4OS' not in sssdesc:
                os.system("konsole -e " + "bash -c '" + cmd + "; exec bash -i' &")
                return
        if 'Endeavour' in sssdesc:
            os.system("konsole -e " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'Garuda' in sssdesc:
            os.system("gnome-terminal -- " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'KDE' in sssdesc or 'Kde' in sssdesc and 'Q4OS' not in sssdesc and 'Mint' not in sssdesc:
            os.system("konsole -e " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'Lite' in sssdesc:
            os.system("xfce4-terminal -x " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'Manjaro' in sssdesc:
            os.system("konsole -e " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'Mint' in sssdesc or 'LMDE' in sssdesc:
            # below os works for: cpufetch, neofetch, btop, top, htop, atop, nvtop, bpytop, mc
            os.system("gnome-terminal --  " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'MX' in sssdesc:
            os.system("xfce4-terminal -x " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'Neptune' in sssdesc:
            os.system("konsole -e " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'Nobara' in sssdesc:     # does this twice ?
            os.system("konsole -e " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'Parrot' in sssdesc:
            if 'dmidecode' in cmd:
                os.system("mate-terminal -x " + "bash -c ' sudo " + cmd + "; exec bash -i' &")
            else:
                os.system("mate-terminal -x " + "bash -c '" + cmd + "; exec bash -i' &")              # original
            return
        if 'Q4OS' in sssdesc:
            # permission denied, needs password with Q4OS
            # /usr/sbin/dmidecode and /usr/games/lolcat using paths almost works
            os.system("konsole -e " + "bash -c '" + cmd + "; exec bash -i' &")
            return
        if 'Solus' in sssdesc:
            os.system("konsole -e " + "bash -c '" + cmd + "; exec bash -i' &")
            return

    @staticmethod
    def thread_function(cmd):
        if ' -' in cmd and '* --' not in cmd and 'find' not in cmd:
            cmdonly = cmd.split(' -')
        else:
            cmdonly = str(cmd).split(' ')

        istool = ui.is_toolexist(cmdonly[0])
        if istool == 'false' and 'history' not in cmd:
            ui.displayerror("Warning!", "'" + str(cmd) + "' not found.", "(thread_function)", "", "1")
            return

        ui.displaynotice(cmd + " started thread!")
        MainWindow.repaint()

        # works: htop, btop, top, nvtop, bpytop, atop
        x = threading.Thread(target=ui.thread_function_os(cmd))
        x.start()

        time.sleep(1)
        ui.displaynotice(" ")

    @staticmethod
    def popen_for_programs(cmd):
        if cmd == 'skip':
            return

        # should check if exists first
        space_count = cmd.count(" ")
        if space_count > 0:
            cmdonly = cmd.split(' ')
            istool = ui.is_toolexist(cmdonly[0])
        else:
            istool = ui.is_toolexist(cmd)

        if istool == 'false':
            ui.displayerror("Warning!", "'" + str(cmd) + "' not found.", "(popen_for_programs)", "", "")
            return
        if istool != 'false' and istool != 'true':
            cmd = istool

        try:
            ui.displaynotice("'" + cmd + "' is started!")
            MainWindow.repaint()
            # no work: htop, btop, top, nvtop, bpytop, atop
            # temp = subprocess.Popen(['gparted'])          # done works & prompts for password
            # temp = subprocess.Popen(['gufw'])             # done works & prompts for password
            # temp = subprocess.Popen(['grub-customizer'])  # done works & prompts for password
            if 'cinnamon-settings' in cmd and 'info' in cmd:
                subprocess.Popen(['cinnamon-settings', 'info'])
            elif 'kinfocenter' in cmd and 'kcm_' in cmd:
                ui.findsysteminformationswitches(cmd)
            elif 'Feren' in cmd:
                cmd = '/usr/bin/systemsettings'
            else:
                subprocess.Popen(cmd)

        except Exception as e:
            ui.displaynotice("'" + cmd + "' failed,  " + str(e))
            MainWindow.repaint()
        return

    @staticmethod
    def popen_function_common(cmd2):
        cmd2 = cmd2.replace('-@', '')
        cmd = cmd2

        cmdonly = str(cmd).split(' ')
        istool = ui.is_toolexist(cmdonly[0])
        if istool == 'false':
            ui.displayerror("Warning!", "'" + str(cmd) + "' not found.", "(popen_function_common)", "", "3")
            return

        # if '/' in istool:
        # count = istool.count('/')
        # cmdfix = istool.replace(cmdonly[0], '')
        # cmd = cmdfix + cmd
        # if istool != 'false' and istool != 'true':
        # cmd = istool

        if ' --installed' in cmd or ' --upgradeable' in cmd:
            cmdonly = str(cmd2).split(' ')
            istool = ui.is_toolexist(cmdonly[0])
            if istool == 'false':
                ui.displayerror("Warning!", "'" + str(cmd) + "' not found.",
                                "(popen_function_common)", "", "4")
                return
            cmd = cmd2
        elif ' -' in cmd and '* --' not in cmd and 'systectl' not in cmd and \
                'hwinfo' not in cmd and 'ifconfig' not in cmd and 'pip list --user' not in cmd:
            cmdonly = cmd2.split(' -')
            istool = ui.is_toolexist(cmdonly[0])
            if istool == 'false':
                ui.displayerror("Warning!", "'" + str(cmd) + "' not found.",
                                "(popen_function_common)", "", "5")
                return
            cmd = cmd2
        elif 'hwinfo' in cmd or 'ifconfig' in cmd:
            cmdonly = str(cmd2).split(' ')
            istool = ui.is_toolexist(cmdonly[0])
            if istool == 'false':
                ui.displayerror("Warning!", "'" + str(cmd) + "' not found.",
                                "(popen_function_common)", "", "6")
                return
            if '/' in istool:
                cmd = istool + ' ' + cmdonly[1]
            else:
                cmd = cmdonly[0] + ' ' + cmdonly[1]
        else:
            cmdonly = str(cmd2).split(' ')
            istool = ui.is_toolexist(cmdonly[0])
            if istool == 'false':
                if cmd == '':
                    cmd = 'command'
                ui.displayerror("Warning!", "'" + str(cmd) + "' not found.",
                                "(popen_function_common)", "", "7")
                return
            cmd = cmd2

        if '*' in cmd2:
            cmd2 = cmd2.replace(' ', '_')
            if '.conf' in cmd2:
                ctxt = cmd2.replace('*', '')
                ctxt = ctxt.replace('.', '')
                ctxt = ctxt.replace('/', '_')
                ctxt = ctxt.replace('__', '_')
                log = open(folder_path + '/' + ctxt + '.txt', 'w')
            else:
                if '*' in cmd2:
                    cmd2 = cmd2.replace('*', '')
                    cmd2 = cmd2.replace('/', '_')
                    cmd2 = cmd2.replace('__', '_')
                    log = open(folder_path + '/' + cmd2 + '.txt', 'w')
                else:
                    cmd, opt = cmd2.split('*')
                    log = open(folder_path + '/' + cmd + ' ' + opt + '.txt', 'w')
        else:
            if ('cpuinfo' in cmd2) or ('os-release' in cmd2) or ('sysctl ' in cmd2):
                cmd2 = cmd2.replace(' ', '_')
                cmd2 = cmd2.replace('/', '_')
                cmd2 = cmd2.replace('__', '_')
                log = open(folder_path + '/' + cmd2 + '.txt', 'w')
                cmd2 = cmd2.replace('_', '/')
            elif 'dmidecode' in cmd2:
                cmd2 = cmd2.replace('!', ' ')
                # 'dmidecode -t 6!Memory Module'
                x = cmd2.split(" ")
                cmd2 = cmd2.replace(' ', '_')
                log = open(folder_path + '/' + cmd2 + '.txt', 'w')
                if 'man ' not in cmd:
                    cmd = x[0] + " " + x[1] + " " + x[2]
            else:
                cmd3 = cmd2.replace(' ', '_')
                cmd3 = cmd3.replace('/', '_')
                cmd3 = cmd3.replace('__', '_')
                if 'user-dirs.dirs' in cmd3:
                    x = cmd3.split("config")
                    cmd3 = "cat_config" + x[1]
                    # cmd3 = cmd3.replace("cat_home_skinnyg_.config_user-dirs.dirs", "cat_config_user-dirs.dirs")
                log = open(folder_path + '/' + cmd3 + '.txt', 'w')

        cmd = cmd.replace("_", ' ')

        # these commands/programs need the password
        if 'policy' not in cmd:
            if 'fdisk' in cmd or 'dmidecode' in cmd or 'du ' in cmd:
                cmd = ('sudo -S ' + cmd)

        ui.displaynotice(cmd + " started")
        proc = subprocess.Popen(cmd.split(), stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True)
        proc.stdin.write(mypass)
        proc.stdin.write('\n')
        proc.stdin.flush()
        stdout = proc.communicate()

        if proc.returncode == 0:
            sverbage = stdout[0]
            if 'no system default destination' in sverbage:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo system default destination")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No system default destination. No printer.",
                                "(popen_function_common)", "", "8")
                proc.terminate()
                return ''
            elif 'No destination added' in sverbage:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo destination added")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No destination added. No printer.",
                                "(popen_function_common)", "", "9")
                proc.terminate()
                return ''
            elif 'Permission denied' in stdout[1]:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nPermission denied")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Permission denied.",
                                "(popen_function_common)", "", "9b")
                proc.terminate()
                return ''

            log.write(log.name + '\n')
            log.write('\ncommand line:  ' + cmd + '\n\n\n')

            if 'lolcat' in cmd or 'cat' in cmd:
                lolcatstdout = str(stdout)
                lolcatstdoutlines = lolcatstdout.split("\\n")

                for line in lolcatstdoutlines:
                    line = line.replace("('", "")
                    line = line.replace("', '')", "")
                    splitline = line.split(":")
                    sleft = splitline[0]

                    sleft = sleft.replace("     ", " ")
                    sleft = sleft.replace("    ", " ")
                    sleft = sleft.replace("   ", " ")
                    sleft = sleft.replace("  ", " ")
                    sleftparts = sleft.split(' ')

                    if len(sleftparts) == 7:
                        splitline0 = sleftparts[0]
                        ilen = len(splitline0)
                        spacesout = 28 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline0 = sleftparts[0] + str(spacesuse)

                        ilen = len(sleftparts[1].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline1 = str(spacesuse) + sleftparts[1]

                        ilen = len(sleftparts[2].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline2 = str(spacesuse) + sleftparts[2]

                        ilen = len(sleftparts[3].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline3 = str(spacesuse) + sleftparts[3]

                        ilen = len(sleftparts[4].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline4 = str(spacesuse) + sleftparts[4]

                        ilen = len(sleftparts[5].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline5 = str(spacesuse) + sleftparts[5]

                        sleft = splitline0 + splitline1 + splitline2 + splitline3 + splitline4 + splitline5

                    sright = ' '
                    if len(splitline) > 1:
                        sright = splitline[1]
                        sright = sright.replace("     ", " ")
                        sright = sright.replace("    ", " ")
                        sright = sright.replace("   ", " ")
                        sright = sright.replace("  ", " ")

                    sleft = sleft.replace("\\t", "")
                    ilen = len(sleft)
                    spacescnt = 50 - ilen
                    if 'cpuinfo' in log.name or 'meminfo' in log.name:
                        spacescnt = 20 - ilen
                    # meminfo must also fix right side alignment
                    if 'sysctl.conf' in log.name or 'loadavg' in log.name \
                            or 'stat' in log.name or 'swaps' in log.name:
                        spacescnt = 35 - ilen
                    if 'net_dev' in log.name:
                        spacescnt = 10 - ilen

                    spacesuse = int(spacescnt) * ' '
                    if 'sysctl.conf' in log.name or 'grub' in log.name or 'loadavg' in log.name \
                            or 'mounts' in log.name or 'stats' in log.name or 'swaps' in log.name:
                        scolon = ' '
                    else:
                        scolon = ' : '

                    line = sleft + str(spacesuse) + str(scolon) + sright

                    if 'locate' in cmd or 'lsb-release' in cmd:
                        line = line.replace("     :", " ")

                    if 'grub' in log.name:
                        line = line.replace("     ", " ")
                        line = line.replace("    ", " ")
                        line = line.replace("   ", " ")
                        line = line.replace("  ", " ")

                    if 'os-prober' in cmd:
                        line = line.replace(":", "")

                    if '[sudo]' not in line and 'password' not in line:
                        log.write(line + '\n')

                ui.displaynotice(cmd + " finished")
                proc.terminate()
                return ''

            for line in stdout:
                # lolcatstdout = str(stdout)
                # lolcatstdoutlines = lolcatstdout.split("\\n")

                if ("cat " in cmd) and ("sysctl" in cmd) and ("grep" in cmd):
                    a, b, c, d, e, f, g = cmd.split(' ')
                    if (("abi." in line) and ("abi" in g) or ("debug." in line) and ("debug" in g) or
                            ("dev." in line) and ("dev" in g) or ("fs." in line) and ("fs" in g) or
                            ("kernel." in line) and ("kernel" in g) or ("net." in line) and ("net" in g) or
                            ("user." in line) and ("user" in g) or ("vm." in line) and ("vm" in g)):
                        line = line.replace("\x03", "")  # works for the ETX control key
                        line = line.replace("12", "")
                        line = line.replace("   Memory top 5", " : Memory top 5")
                        line2 = line
                        log.write(line2)

                elif 'free' in cmd or 'ps -' in cmd:
                    if 'total' in line:
                        line = '' + line
                    log.write(line + '\n')

                elif 'flatpak' in cmd and 'policy' not in cmd:
                    linesplit = (line.split("\n"))
                    for line2 in linesplit:
                        line2 = line2.replace("\t", "  ")
                        sleftparts = line2.split("  ")

                        if len(sleftparts) == 5:
                            splitline0 = sleftparts[0]
                            ilen = len(splitline0)
                            spacesout = 36 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline0 = sleftparts[0] + str(spacesuse)

                            ilen = len(sleftparts[1].strip())
                            spacesout = 36 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline1 = sleftparts[1] + str(spacesuse)

                            ilen = len(sleftparts[2].strip())
                            spacesout = 20 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline2 = str(spacesuse) + sleftparts[2]

                            ilen = len(sleftparts[3].strip())
                            spacesout = 20 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline3 = str(spacesuse) + sleftparts[3]

                            ilen = len(sleftparts[4].strip())
                            spacesout = 10 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline4 = str(spacesuse) + sleftparts[4]

                            if len(splitline2.strip()) == 0:
                                splitline2 = splitline3
                                splitline3 = '                 0.0'

                            sleft = splitline0 + splitline1 + splitline2 + splitline3 + splitline4
                            log.write(sleft + "\n")

                    ui.displaynotice(cmd + " finished")
                    proc.terminate()
                    return ''

                elif 'du -h' in cmd:
                    if 'M	/' in line:
                        line = line.replace('M	/', 'M ' + '\t' + '/')
                    if 'K	/' in line:
                        line = line.replace('K	/', 'K ' + '\t' + '/')
                    if 'G	/' in line:
                        line = line.replace('G	/', 'G ' + '\t' + '/')
                    if '[sudo] password' not in line and 'WARNING' not in line:
                        log.write(line + '\n')

                else:
                    line = line.replace("\x03", "")  # works for the ETX control key
                    line = line.replace("\x1b[33", "")
                    line = line.replace("\x1b[0m", "")
                    line = line.replace("\x1b[", "")

                    if ' inxi ' in cmd:
                        line = line.replace("12", "")
                    if 'vmstat' in cmd:
                        line = line.replace("free ", " free")
                        line = line.replace("inact", "  inact ")
                        line = line.replace("si ", " si")
                    if 'ss ' in cmd:
                        line = line.replace("RAW", "RAW   ")
                        line = line.replace("UDP", "UDP   ")
                        line = line.replace("TCP", "TCP   ")

                    line = line.replace("   Memory top 5", " : Memory top 5")
                    line2 = line
                    if '[sudo] password' not in line2 and 'WARNING' not in line2:
                        log.write(line2)

            log.flush()
            ui.displaynotice(cmd + " finished")

            # if output to terminal do it here
            if ui.actionSend_to_terminal_2.isChecked():
                cmdlolcat = cmd + " | cat"
                ui.thread_function(cmdlolcat)
                if os.path.isfile(folder_path + '/' + cmd2 + '.txt'):
                    os.remove(folder_path + '/' + cmd2 + '.txt')

            proc.terminate()
            return ''

        if proc.returncode == 1:
            errtext = str(stdout)

            if 'No destination added' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo destination added. a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No destination added.",
                                "(popen_function_common)", "", "10")

            elif 'This application can not open files' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nThis application can not open files. a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' This application cannot open files.",
                                "(popen_function_common)", "", "11")

            elif 'Permission denied' in stdout[1]:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nPermission denied")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Permission denied.",
                                "(popen_function_common)", "", "9b")

            elif 'No such file' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo such file or directory. a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No such file or directory.",
                                "(popen_function_common)", "", "12")

            elif 'locate: can not stat' in errtext:     # locate gets above error message
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nlocate: can not stat. a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' locate: can not stat.",
                                "(popen_function_common)", "", "13")

            elif 'command not found' in errtext:
                if 'lsb-release' in cmd:
                    log.write(log.name + '\n')
                    log.write('\ncommand line:  ' + cmd + '\n\n\n')
                    log.write("\nPopen failed!\n\nFile not found! a")
                    log.flush()
                    ui.displayerror("Warning!", "'" + str(cmd) + "' File not found.",
                                    "(popen_function_common)", "", "14")
                else:
                    log.write(log.name + '\n')
                    log.write('\ncommand line:  ' + cmd + '\n\n\n')
                    log.write("\nPopen failed!\n\nCommand not found! a")
                    log.flush()
                    ui.displayerror("Warning!", "'" + str(cmd) + "' Command not found.",
                                    "(popen_function_common)", "", "15")

            elif 'Invalid user' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nInvalid user! a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Invalid user.",
                                "(popen_function_common)", "", "16")

            elif 'no password was provided' in errtext or 'incorrect password' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo or incorrect password was provided")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No or incorrect password was provided.",
                                "(popen_function_common)", "", "16b")

            elif 'System has not been booted with systemd' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nInvalid user! a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' System has not been booted with systemd.",
                                "(popen_function_common)", "", "17")

            else:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nOperation is not permitted! a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Command is not working and returns nothing.",
                                "(popen_function_common)", "", "18")

        if proc.returncode > 1:
            if proc.returncode == 2 and 'ls ' in cmd:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nWhoops!\n\nCannot access directory.")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Cannot access directory.",
                                "(popen_function_common)", "", "19a")
            elif proc.returncode == 2 and 'cpupower' in cmd:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nWhoops!\n\nCpupower not found for current kernel.")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Cpupower not found for current kernel.",
                                "(popen_function_common)", "", "19b")
            elif proc.returncode == 9:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nWhoops!\n\nAppears to be no Nvidia driver installed.")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Appears to be no Nvidia driver installed.",
                                "(popen_function_common)", "", "20")
            elif proc.returncode == 16:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo manual entry! b")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No manual entry.",
                                "(popen_function_common)", "", "21")
            else:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nWas the password entered correctly? b")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Was the password entered correctly?",
                                "(popen_function_common)", "", "22")
            proc.terminate()
            return ''

        proc.terminate()
        return ''

    @staticmethod
    def popen_function_common_simple(cmd):
        if 'Endeavour' in ssdesc and 'cpuinfo' in cmd:
            cmd = 'kinfocenter kcm_cpu'
        cmdonly = cmd.split(' ')
        istool = ui.is_toolexist(cmdonly[0])
        if istool == 'false' and 'bash_history' not in cmd:
            ui.displayerror("Warning!", "'" + str(cmd) + "' not found.", "(popen_function_common_simple)", "", "2")
            return

        # if '/' in istool:
        # count = istool.count('/')
        # cmdfix = istool.replace(cmdonly[0], '')
        # cmd = cmdfix + cmd
        # if istool != 'false' and istool != 'true':
        # cmd = istool

        if 'Debian' in ssdesc and 'MX' not in ssdesc:
            if 'blkid' in cmd or 'hwinfo' in cmd or 'sysctl' in cmd:
                ui.displayerror("Warning!", "'" + str(cmd) + "' will not work on Debian.",
                                "(popen_function_common_simple)", "", "2")
                return

        cmd2 = cmd.replace(' ', '_')
        cmd2 = cmd2.replace('/', '_')
        cmd2 = cmd2.replace('__', '_')

        if 'Q4OS' in ssdesc:
            cmd2 = cmd2.replace('_home', 'home')

        log = open(folder_path + '/' + cmd2 + '.txt', 'w')      # create file in LECC

        if 'dmidecode ' in cmd or 'du ' in cmd or 'fdisk ' in cmd or 'find ' in cmd or \
           'gparted ' in cmd or 'gufw ' in cmd or 'hdparm ' in cmd or 'parted ' in cmd or \
           'dmesg ' in cmd or 'grub.cfg' in cmd or 'df ' in cmd or 'bash_history' in cmd or \
           'os-prober' in cmd:
            cmd = 'sudo -S ' + cmd

        ui.displaynotice(cmd + " started")
        proc = subprocess.Popen(cmd.split(), stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True)
        if len(mypass) > 0:
            proc.stdin.write(mypass)
            proc.stdin.write('\n')
            if 'Garuda' not in ssdesc and 'Parrot' not in ssdesc and 'Solus' not in ssdesc:
                proc.stdin.flush()
        stdout = proc.communicate()

        if proc.returncode == 0:
            sverbage = stdout[0]
            if 'no system default destination' in sverbage:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo system default destination")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No system default destination. No printer.",
                                "(popen_function_common_simple)", "", "8")
                proc.terminate()
                return ''
            elif 'No destination added' in sverbage:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo destination added")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No destination added. No printer.",
                                "(popen_function_common_simple)", "", "9")
                proc.terminate()
                return ''
            elif 'Permission denied' in stdout[1]:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nPermission denied")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Permission denied.",
                                "(popen_function_common_simple)", "", "9b")
                proc.terminate()
                return ''

            # exception
            if 'kinfocenter' in cmd:
                log.flush()
                os.remove(log.name)
                proc.terminate()
                return

            log.write(log.name + '\n')
            log.write('\ncommand line:  ' + cmd + '\n\n\n')

            if 'bash_history' not in cmd and 'cat' in cmd:
                lolcatstdout = str(stdout)
                lolcatstdoutlines = lolcatstdout.split("\\n")

                for line in lolcatstdoutlines:
                    line = line.replace("('", "")
                    line = line.replace("', '')", "")
                    splitline = line.split(":")
                    sleft = splitline[0]

                    sleft = sleft.replace("     ", " ")
                    sleft = sleft.replace("    ", " ")
                    sleft = sleft.replace("   ", " ")
                    sleft = sleft.replace("  ", " ")
                    sleftparts = sleft.split(' ')

                    if len(sleftparts) == 7:
                        splitline0 = sleftparts[0]
                        ilen = len(splitline0)
                        spacesout = 28 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline0 = sleftparts[0] + str(spacesuse)

                        ilen = len(sleftparts[1].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline1 = str(spacesuse) + sleftparts[1]

                        ilen = len(sleftparts[2].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline2 = str(spacesuse) + sleftparts[2]

                        ilen = len(sleftparts[3].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline3 = str(spacesuse) + sleftparts[3]

                        ilen = len(sleftparts[4].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline4 = str(spacesuse) + sleftparts[4]

                        ilen = len(sleftparts[5].strip())
                        spacesout = 10 - ilen
                        spacesuse = int(spacesout) * ' '
                        splitline5 = str(spacesuse) + sleftparts[5]

                        sleft = splitline0 + splitline1 + splitline2 + splitline3 + splitline4 + splitline5

                    sright = ' '
                    if len(splitline) > 1:
                        sright = splitline[1]
                        sright = sright.replace("     ", " ")
                        sright = sright.replace("    ", " ")
                        sright = sright.replace("   ", " ")
                        sright = sright.replace("  ", " ")

                    sleft = sleft.replace("\\t", "")
                    ilen = len(sleft)
                    spacescnt = 50 - ilen
                    if 'cpuinfo' in log.name or 'meminfo' in log.name:
                        spacescnt = 20 - ilen
                    # meminfo must also fix right side alignment
                    if 'sysctl.conf' in log.name or 'loadavg' in log.name \
                            or 'stat' in log.name or 'swaps' in log.name:
                        spacescnt = 35 - ilen
                    if 'net_dev' in log.name:
                        spacescnt = 10 - ilen

                    spacesuse = int(spacescnt) * ' '
                    if 'sysctl.conf' in log.name or 'grub' in log.name or 'loadavg' in log.name \
                            or 'mounts' in log.name or 'stats' in log.name or 'swaps' in log.name:
                        scolon = ' '
                    else:
                        scolon = ' : '

                    line = sleft + str(spacesuse) + str(scolon) + sright

                    if 'freshclam' in cmd:
                        line = line.replace(" :", "")
                        line = line.replace("    ", " ")
                        line = line.replace("  ", " ")

                    if 'locate' in cmd or 'lsb-release' in cmd:
                        line = line.replace(" : ", "")

                    if 'grub' in log.name:
                        line = line.replace("     ", " ")
                        line = line.replace("    ", " ")
                        line = line.replace("   ", " ")
                        line = line.replace("  ", " ")

                    if 'os-prober' in log.name:
                        line = line.replace(" : x", "")

                    if 'etc_group' in log.name:
                        line = line.replace(" : x", "")

                    if '[sudo]' not in line and 'password' not in line:
                        log.write(line + '          \n')

                ui.displaynotice(cmd + " finished")
                proc.terminate()
                return ''

            for line in stdout:
                # lolcatstdout = str(stdout)
                # lolcatstdoutlines = lolcatstdout.split("\\n")

                if ("cat " in cmd) and ("sysctl" in cmd) and ("grep" in cmd):
                    a, b, c, d, e, f, g = cmd.split(' ')
                    if (("abi." in line) and ("abi" in g) or ("debug." in line) and ("debug" in g) or
                            ("dev." in line) and ("dev" in g) or ("fs." in line) and ("fs" in g) or
                            ("kernel." in line) and ("kernel" in g) or ("net." in line) and ("net" in g) or
                            ("user." in line) and ("user" in g) or ("vm." in line) and ("vm" in g)):
                        line = line.replace("\x03", "")  # works for the ETX control key
                        line = line.replace("12", "")
                        line = line.replace("   Memory top 5", " : Memory top 5")
                        line2 = line
                        log.write(line2)

                elif 'free' in cmd or 'ps -' in cmd:
                    if 'total' in line:
                        line = '' + line
                    log.write(line + '\n')

                elif 'flatpak' in cmd and 'policy' not in cmd:
                    linesplit = (line.split("\n"))
                    for line2 in linesplit:
                        line2 = line2.replace("\t", "  ")
                        sleftparts = line2.split("  ")

                        if len(sleftparts) == 5:
                            splitline0 = sleftparts[0]
                            ilen = len(splitline0)
                            spacesout = 36 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline0 = sleftparts[0] + str(spacesuse)

                            ilen = len(sleftparts[1].strip())
                            spacesout = 36 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline1 = sleftparts[1] + str(spacesuse)

                            ilen = len(sleftparts[2].strip())
                            spacesout = 20 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline2 = str(spacesuse) + sleftparts[2]

                            ilen = len(sleftparts[3].strip())
                            spacesout = 20 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline3 = str(spacesuse) + sleftparts[3]

                            ilen = len(sleftparts[4].strip())
                            spacesout = 10 - ilen
                            spacesuse = int(spacesout) * ' '
                            splitline4 = str(spacesuse) + sleftparts[4]

                            if len(splitline2.strip()) == 0:
                                splitline2 = splitline3
                                splitline3 = '                 0.0'

                            sleft = splitline0 + splitline1 + splitline2 + splitline3 + splitline4
                            log.write(sleft + "\n")

                    ui.displaynotice(cmd + " finished")

                elif 'dpkg' in cmd:
                    linesplit = (line.split("\n"))
                    for line2 in linesplit:
                        log.write(line2 + '\n')

                elif 'du -h' in cmd:
                    if 'M	/' in line:
                        line = line.replace('M	/', 'M ' + '\t' + '/')
                    if 'K	/' in line:
                        line = line.replace('K	/', 'K ' + '\t' + '/')
                    if 'G	/' in line:
                        line = line.replace('G	/', 'G ' + '\t' + '/')
                    if '[sudo] password' not in line and 'WARNING' not in line:
                        log.write(line + '\n')

                elif 'gparted' in cmd:
                    if '[sudo] password' not in line and 'WARNING' not in line:
                        log.write(line + '\n')

                elif 'man journalctl' in cmd:
                    jlines = line.split('\n')
                    for tline in jlines:
                        log.write(tline + '\n')
                    return

                else:
                    line = line.replace("\x03", "")  # works for the ETX control key
                    line = line.replace("\x1b[33", "")
                    line = line.replace("\x1b[0m", "")
                    line = line.replace("\x1b[", "")

                    if ' inxi ' in cmd:
                        line = line.replace("12", "")
                    if 'vmstat' in cmd:
                        line = line.replace("free ", " free")
                        line = line.replace("inact", "  inact ")
                        line = line.replace("si ", " si")
                    if 'ss ' in cmd:
                        line = line.replace("RAW", "RAW   ")
                        line = line.replace("UDP", "UDP   ")
                        line = line.replace("TCP", "TCP   ")

                    line = line.replace("   Memory top 5", " : Memory top 5")
                    line2 = line
                    if '[sudo] password' not in line2 and 'WARNING' not in line2:
                        line2 = line2.replace('   ', ' ')
                        log.write(line2)

            log.flush()
            ui.displaynotice(cmd + " finished")

            # if output to terminal do it here
            if ui.actionSend_to_terminal_2.isChecked():
                cmdlolcat = cmd + " | cat"
                ui.thread_function(cmdlolcat)
                if os.path.isfile(folder_path + '/' + cmd2 + '.txt'):
                    os.remove(folder_path + '/' + cmd2 + '.txt')

            proc.terminate()
            return ''

        if proc.returncode == 1:
            errtext = str(stdout)

            if 'No destination added' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo destination added. a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No destination added.",
                                "(popen_function_common_simple)", "", "10")

            elif 'This application can not open files' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nThis application can not open files. a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' This application cannot open files.",
                                "(popen_function_common_simple)", "", "11")

            elif 'Permission denied' in stdout[1]:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nPermission denied")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Permission denied.",
                                "(popen_function_common_simple)", "", "9b")

            elif 'No such file' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo such file or directory. a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No such file or directory.",
                                "(popen_function_common_simple)", "", "12")

            elif 'locate: can not stat' in errtext:     # locate gets above error message
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nlocate: can not stat. a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' locate: can not stat.",
                                "(popen_function_common_simple)", "", "13")

            elif 'command not found' in errtext:
                if 'lsb-release' in cmd:
                    log.write(log.name + '\n')
                    log.write('\ncommand line:  ' + cmd + '\n\n\n')
                    log.write("\nPopen failed!\n\nFile not found! a")
                    log.flush()
                    ui.displayerror("Warning!", "'" + str(cmd) + "' File not found.",
                                    "(popen_function_common_simple)", "", "14")
                else:
                    log.write(log.name + '\n')
                    log.write('\ncommand line:  ' + cmd + '\n\n\n')
                    log.write("\nPopen failed!\n\nCommand not found! a")
                    log.flush()
                    ui.displayerror("Warning!", "'" + str(cmd) + "' Command not found.",
                                    "(popen_function_common_simple)", "", "15")

            elif 'Invalid user' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nInvalid user! a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Invalid user.",
                                "(popen_function_common_simple)", "", "16")

            elif 'no password was provided' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo or incorrect password was provided")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No or incorrect password was provided.",
                                "(popen_function_common_simple)", "", "16b")

            elif 'System has not been booted with systemd' in errtext:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nInvalid user! a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' System has not been booted with systemd.",
                                "(popen_function_common_simple)", "", "17")

            else:
                log.write(log.name + '\n')
                log.write('\ncommand line:  ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nOperation is not permitted! a")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Command is not working and returns nothing.",
                                "(popen_function_common_simple)", "", "18")

        if proc.returncode > 1:
            if proc.returncode == 2 and 'ls ' in cmd:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nWhoops!\n\nCannot access directory.")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Cannot access directory.",
                                "(popen_function_common_simple)", "", "19a")
            elif proc.returncode == 2 and 'cpupower' in cmd:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nWhoops!\n\nCpupower not found for current kernel.")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Cpupower not found for current kernel.",
                                "(popen_function_common_simple)", "", "19b")
            elif proc.returncode == 9:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nWhoops!\n\nAppears to be no Nvidia driver installed.")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Appears to be no Nvidia driver installed.",
                                "(popen_function_common_simple)", "", "20")
            elif proc.returncode == 16:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nNo manual entry! b")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' No manual entry.",
                                "(popen_function_common_simple)", "", "21")
            else:
                log.write(log.name + '\n')
                log.write('\ncommand line: ' + cmd + '\n\n\n')
                log.write("\nPopen failed!\n\nWas the password entered correctly? b")
                log.flush()
                ui.displayerror("Warning!", "'" + str(cmd) + "' Was the password entered correctly?",
                                "(popen_function_common_simple)", "", "22")
            proc.terminate()
            return ''

        proc.terminate()
        return ''

    @staticmethod
    def popen_function_run(cmd):
        if 'driver-manager' in cmd or 'gnome-system-monitor' in cmd:
            if 'Ubuntu' in sssdesc or 'Parrot' in sssdesc:
                ui.displayerror("Warning!", "'" + str(cmd) + " not found.", "(popen_function_run)", "", "23")
                return

        cmdonly = str(cmd).split(' ')
        istool = ui.is_toolexist(cmdonly[0])
        if istool == 'false' and 'history' not in cmd:
            ui.displayerror("Warning!", "'" + str(cmd) + "' not found.", "(popen_function_run)", "", "r24")
            return
        else:
            if 'kate' not in cmd and 'vlc' not in cmd and 'bpytop' not in cmd and \
               'nvtop' not in cmd and 'atop' not in cmd and 'htop' not in cmd and \
               'kwrite' not in cmd and 'ncdu' not in cmd and 'nvim' not in cmd and \
               'Endeavour' not in cmd and 'gufw' not in cmd:
                cmd = 'sudo -S ' + str(cmd)

            # these commands/programs need the password: gparted, gufw
            proc = subprocess.Popen(cmd.split(), stdin=PIPE, stdout=PIPE, stderr=PIPE)
            pb = bytes(mypass, "ascii")
            proc.stdin.write(pb)
            if 'Garuda' not in ssdesc and 'Parrot' not in ssdesc and \
                    'MX' not in ssdesc and 'Endeavour' not in ssdesc and \
                    'Q4OS' not in ssdesc and 'Solus' not in ssdesc:
                proc.stdin.flush()
            stdout = proc.communicate()

            if proc.returncode == 1:
                errtext = str(stdout)
                if 'no password was provided' in errtext:
                    ui.displayerror("Warning!", "'" + str(cmd) + "' No password was provided.",
                                    "(popen_function_run)", "", "r25")

            if proc.returncode == 139:
                ui.displayerror("Critical!", "'" + str(cmd) + "' Segmentation fault.",
                                "(popen_function_run)", "EGL_BAD_ACCESS", "r99")

            if (proc.returncode != 139 and proc.returncode > 1) or proc.returncode is None:
                ui.displayerror("Warning!", "'" + str(cmd) + "' not found.",
                                "(popen_function_run)", "", "r26")

            proc.terminate()
            return

    @staticmethod
    def popen_function_runbypath(cmd):
        if ' -' in cmd and '* --' not in cmd and 'find' not in cmd:
            cmdonly = str(cmd).split(' -')
            istool = ui.is_toolexist(cmdonly[0])
        else:
            cmdonly = str(cmd).split(' ')
            istool = ui.is_toolexist(cmdonly[0])

        if istool == 'false':
            ui.displayerror("Warning!", "'" + str(cmd) + "' not found.", "(popen_function_runbypath)", "", "rp26")
            return

        p = subprocess.Popen(str(cmd))
        p.communicate()
        if p.returncode != 0 or p.returncode is None:
            if 'nvtop' in cmd:
                ui.displayerror("Warning!", "nvtop exists but probably no Nvidia driver.",
                                "(popen_function_runbypath)", "", "rp27")
            else:
                ui.displayerror("Warning!", "'" + str(cmd) + "' not found.", "(popen_function_runbypath)", "", "rp28")

    @staticmethod
    def findcontrolcenter():        # working here
        # distros, desktops & notes
        # Debian uses GNOME, Xfce, Plasma, Cinnamon, Mate, LXDE, or LXQt
        # Endeavour uses Cinnamon, Budgie, Gnome, Mate, Xfce, i3, LXDE, LXQt
        # Garuda uses Cinnamon, Xfce, Mate
        # KDE Neon uses Plasma, xfce4, Mate
        # Manjaro uses Xfce, Plasma, Gnome
        # Mint uses Cinnamon, Plasma, Gnome, Mate, Xfce
        # Neptune uses Plasma, x11
        # Parrot uses Mate, Plasma, Gnome, Xfce

        if 'Debian' in sssdesc and 'MX' not in sssdesc and 'Q4OS' not in sssdesc and 'bookworm' not in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Endeavour' in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Feren' in sssdesc:
            # must be root
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Garuda' in sssdesc:
            if 'Xfce' in pcds:
                ui.popen_for_programs('xfce4-settings-manager')
                return 'skip'
            if 'Cinnamon' in pcds:
                ui.popen_for_programs('cinnamon-settings')
                return 'skip'
            return 'unknown'
        if 'KDE' in sssdesc or 'Kde' in sssdesc and 'Nobara' not in sssdesc and \
                'MX' not in sssdesc and 'Q4OS' not in sssdesc and 'Debian' not in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Lite' in sssdesc:
            ui.lb39.setText('Settings')
            ui.popen_for_programs('software-properties-gtk')
            return 'skip'
        if 'Manjaro' in sssdesc:
            if 'Xfce' in pcds:
                ui.popen_for_programs('xfce4-settings-manager')
                return 'skip'
            if 'Plasma' in pcds:
                ui.popen_for_programs('systemsettings')
                return 'skip'
            return 'unknown'
        if 'Mint' in sssdesc or 'LMDE' in sssdesc:
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('cinnamon-settings')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-control-center')
                return 'skip'
            return 'unknown'
        if 'MX' in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Debian' in sssdesc and 'bookworm' in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Neptune' in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Nobara' in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Parrot' in sssdesc:
            ui.popen_for_programs('onboard-settings')
            return 'skip'
        if 'Solus' in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Sparky' in sssdesc:
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('cinnamon-settings')
                return 'skip'
            if 'Mate' in sssdesc or 'Xfce' in sssdesc:
                ui.popen_for_programs('onboard-settings')
                return 'skip'
            if 'Gnome' in sssdesc:
                ui.popen_for_programs('gnome-control-center')
                return 'skip'
            return
        if 'Q4OS' in sssdesc:
            ui.popen_for_programs('systemsettings')
            return 'skip'
        if 'Ubuntu' in sssdesc and 'Kubuntu' not in sssdesc and 'Lubuntu' not in sssdesc:
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('cinnamon-settings')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-control-center')
                return 'skip'

            ui.popen_for_programs('onboard-settings')
            return 'skip'

        return 'unknown'

    @staticmethod
    def findsysteminformation():        # working here now
        if 'Endeavour' in sssdesc:
            ui.popen_for_programs('kinfocenter')
            return 'skip'
        if 'Garuda' in sssdesc:
            if 'Xfce' in pcds:
                ui.popen_for_programs('xfce4-about')
                return 'skip'
            if 'Cinnamon' in pcds:
                ui.popen_for_programs('cinnamon-settings info')
                return 'skip'
            return 'unknown'
        if 'KDE' in sssdesc and 'Neon' in sssdesc:
            ui.popen_for_programs('kinfocenter')
            return 'skip'
        if 'Lite' in sssdesc:
            ui.popen_for_programs('lite-welcome')
            return 'skip'
        if 'Manjaro' in sssdesc:
            print(sssdesc + '   ' + pcds)
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('cinnamon-settings info')
                return 'skip'
            if 'Xfce' in pcds:
                ui.popen_for_programs('xfce4-about')
                return 'skip'
            if 'Plasma' in pcds:
                ui.popen_for_programs('kinfocenter')
                return 'skip'
            if 'Mate' in pcds:
                ui.popen_for_programs('mate-system-info')
                return 'skip'
            return 'unknown'
        if 'Mint' in sssdesc or 'LMDE' in sssdesc:
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('cinnamon-settings info')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('cinnamon-settings info')
                return 'skip'
            return 'unknown'
        if 'MX' in sssdesc or 'Neptune' in sssdesc or 'Q4OS' in sssdesc or 'Plasma' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('kinfocenter')
                return 'skip'
            return 'unknown'
        if 'Debian' in sssdesc:
            if 'MX' not in sssdesc and 'Q4OS' not in sssdesc and 'bookworm' not in sssdesc:
                ui.popen_for_programs('kinfocenter')
                return 'skip'
            return 'unknown'
        if 'Nobara' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('kinfocenter')
                return 'skip'
            return 'unknown'
        if 'Solus' in sssdesc:
            ui.popen_for_programs('kinfocenter')
            return 'skip'
        if 'Parrot' in sssdesc:
            ui.cb39.hide()
            ui.pb39_2.hide()
            ui.lb39_3.hide()
            return 'n//a'
        if 'Sparky' in sssdesc:
            if 'Mate' in sssdesc:
                ui.popen_for_programs('sparky-system')
                return 'skip'
            return 'unknown'
        if 'Ubuntu' in sssdesc and 'Kubuntu' not in sssdesc and 'Lubuntu' not in sssdesc:
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-control-center')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce4-control-center')
                return 'skip'
            if 'Gnome' in sssdesc:
                ui.popen_for_programs('gnome-control-center')
                return 'skip'
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('cinnamon-settings info')
                return 'skip'
            return 'unknown'

        return 'unknown'

    @staticmethod
    def findsysteminformationswitches(cmd):
        # s=system, p=processes, r=resources, f=file systems
        if 'Garuda' in sssdesc:
            p = QProcess()
            p.startDetached("cinnamon-settings", [" info"])
        if 'MX' in sssdesc or 'Mx' in sssdesc:
            p = QProcess()
            p.startDetached("mx-welcome", ["--about"])
        if 'Parrot' in sssdesc:
            p = QProcess()
            p.startDetached("mate-system-monitor", [" -s"])
        if 'Mint' in sssdesc or 'LMDE' in sssdesc:
            p = QProcess()
            fsis = cmd.split(' ')
            p.startDetached(fsis[0], [fsis[1]])

    @staticmethod
    def findaterminal():
        # Debian, Garuda, KDE Neon, Mint, Neptune, Parrot, Kubuntu
        # terminator tilix
        istool = ui.is_toolbyname('qterminal')
        if istool == 'true':
            return 'qterminal '
        istool = ui.is_toolbyname('konsole')
        if istool == 'true':
            return 'konsole -e '
        istool = ui.is_toolbyname('xfce4-terminal')
        if istool == 'true':
            return 'xfce4-terminal -x '
        istool = ui.is_toolbyname('mate-terminal')
        if istool == 'true':
            return 'mate-terminal -x '
        istool = ui.is_toolbyname('gnome-terminal')
        if istool == 'true':
            return 'gnome-terminal -x '
        return "unknown"

    @staticmethod
    def findaneditor(cmd):
        # os.chmod(cmd,?)
        itexist = ui.is_toolbyname('kate')
        if itexist != 'false':
            myprocess.start('kate', [cmd])
            return

        itexist = ui.is_toolbyname('pluma')
        if itexist != 'false':
            myprocess.start('pluma', [cmd])
            return

        itexist = ui.is_toolbyname('geany')
        if itexist != 'false':
            myprocess.start('geany', [cmd])
            return

        itexist = ui.is_toolbyname('gedit')
        if itexist != 'false':
            myprocess.start('gedit', [cmd])
            return

        itexist = ui.is_toolbyname('xed')
        if itexist != 'false':
            myprocess.start('xed', [cmd])
            return

        itexist = ui.is_toolbyname('kwrite')
        if itexist != 'false':
            myprocess.start('kwrite', [cmd])
            return

        itexist = ui.is_toolbyname('bluefish')
        if itexist != 'false':
            myprocess.start('bluefish', [cmd])
            return

        itexist = ui.is_toolbyname('notepadqq')
        if itexist != 'false':
            myprocess.start('notepadqq', [cmd])
            return

        itexist = ui.is_toolbyname('mousepad')
        if itexist != 'false':
            myprocess.start('mousepad', [cmd])
            return

        itexist = ui.is_toolbyname('nano')
        if itexist != 'false':
            myprocess.start('nano', [cmd])
            return

        return "unknown"

    @staticmethod
    def getaboutcenterhellowelcome():       # working here
        if 'Debian' in sssdesc:
            if 'MX' not in sssdesc and 'Q4OS' not in sssdesc and 'bookworm' not in sssdesc:
                ui.popen_for_programs('kinfocenter')
                return 'skip'
            return 'unknown'
        if 'Endeavour' in sssdesc:
            ui.popen_for_programs('eos-welcome')
            return 'skip'
        if 'Cachy' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('kinfocenter')
                return 'skip'
            else:
                ui.displaynotice("Non-Plasma desktop must be coded in:  (getaboutcenterhellowelcome)")
                MainWindow.repaint()
                return
        if 'Feren' in sssdesc:
            ui.popen_for_programs('kinfocenter')
            return 'skip'
        if 'Garuda' in sssdesc:
            ui.popen_for_programs('garuda-welcome')
            return 'skip'
        if 'KDE' in sssdesc or 'Kde' in sssdesc and 'Q4OS' not in sssdesc and 'Debian' not in sssdesc:
            if ('Neptune' not in sssdesc and 'Sparky' not in sssdesc and
                    'Mx' not in sssdesc and 'Nobara' not in sssdesc and 'Manjaro' not in sssdesc and
                    'Q4OS' not in sssdesc):
                ui.popen_for_programs('plasma-welcome')
                return 'skip'
        if 'Manjaro' in sssdesc:
            ui.popen_for_programs('manjaro-hello')
            return 'skip'
        if 'Mint' in sssdesc or 'LMDE' in sssdesc:
            ui.popen_for_programs('mintwelcome')
            return 'skip'
        if 'MX' in sssdesc or 'Mx' in sssdesc:
            ui.findsysteminformationswitches('mx-welcome--about')
            return
        if 'Debian' in sssdesc and 'bookworm' in sssdesc:
            ui.popen_for_programs('mx-welcome')
            return 'skip'
        if 'Neptune' in sssdesc:
            ui.popen_for_programs('kinfocenter')
            return 'skip'
        if 'Nobara' in sssdesc:
            ui.popen_for_programs('nobara-welcome')
            return 'skip'
        if 'Parrot' in sssdesc:
            ui.popen_for_programs('mate-control-center')
            return 'skip'
        if 'Q4OS' in sssdesc:
            ui.popen_for_programs('welcome-screen5.exu')
            return 'skip'
        if 'Solus' in sssdesc:
            ui.popen_for_programs('kinfocenter')
            return 'skip'
        if 'Sparky' in sssdesc:
            # Mate
            ui.popen_for_programs('sparky-welcome')
            return 'skip'
        if 'Lite' in sssdesc:
            ui.popen_for_programs('lite-welcome')
            return 'skip'
        if 'Ubuntu' in sssdesc and 'Kubuntu' not in sssdesc and 'Lubuntu' not in sssdesc:
            if 'Mate' in sssdesc:
                ui.popen_for_programs('ubuntu-mate-welcome')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce4-control-center')
                return 'skip'
            if 'Gnome' in sssdesc:
                ui.popen_for_programs('gnome-control-center')
                return 'skip'
            if 'Cinnamon' in sssdesc:
                # cinnamon-control-center is just a few settings
                ui.popen_for_programs('uknown')
                return 'skip'
            return 'unknown'

        return'unknown'

    @staticmethod
    def runbyqprocess(cmd):
        # process states based on QProcess doc:
        # 0 - not running
        # 1 - starting
        # 2 - running

        cmdonly = cmd.split(' ')
        istool = ui.is_toolexist(cmdonly[0])
        if istool == 'false' and 'history' not in cmd:
            ui.displayerror('Warning!', "'" + str(cmd) + "' not found.", "(runbyqprocess)", "", "29")
            # MainWindow.repaint()
            # time.sleep(1)
            # ui.lbnotices.clear()
            return
        if '/' in istool:
            cmdfix = istool.replace(cmdonly[0], '')
            cmd = cmdfix + cmd

        if 'mate-system-monitor' in cmd and ' -' in cmd:
            ui.findsysteminformationswitches(cmd)
            return
        if 'gnome-control-center' in cmd:
            if ' system' in cmd or ' info-overview' in cmd:
                ui.findsysteminformationswitches(cmd)
                return

        if 'control-center' in cmd or 'welcome' in cmd or \
           'plasma-systemmonitor' in cmd or 'gnome-tour' in cmd or 'gnome-system-monitor' in cmd or \
           'garuda-assistant' in cmd or 'systemsettings' in cmd or 'manjaro-hello' in cmd or \
           'garuda-welcome' in cmd or 'mousepad' in cmd or 'xfce4-settings-manager' in cmd or \
           'system-monitoring-center' in cmd or 'software-properties-gtk' in cmd or \
           'mate-system-monitor' in cmd or 'plasma-welcome' in cmd or 'onboard-settings' in cmd or \
           'xfce4-about' in cmd or 'sparky-about' in cmd or 'sparky-system' in cmd or 'mintdesktop' in cmd:
            ui.runtheqprocess(cmd)
            return

        # gnome-terminal, mate-terminal, xfce4-terminal, qterminal
        # konsole, xterm, tilda, yakuake, lxterminal, terminology
        suseterm = ui.findaterminal()

        if 'terminal' == suseterm:
            cmd = suseterm + ' ' + cmd
        if 'konsole' in suseterm:
            cmd = suseterm + ' ' + cmd
        if 'xfce4-terminal' in suseterm:
            cmd = suseterm + ' ' + cmd
        if 'mate-terminal' in suseterm:
            cmd = suseterm + ' ' + cmd
        if 'gnome-terminal' in suseterm:
            cmd = suseterm + ' ' + cmd

        if 'top' in cmd:
            cmd = "nohup " + cmd
        else:
            cmd = "nohup " + cmd + ' >/dev/null 2>&1'

        ui.runtheqprocess(cmd)

    @staticmethod
    def runtheqprocess(cmd):
        ui.myprocess = QProcess()
        ui.myprocess.started.connect(ui.showtheqprocessstarted(cmd))
        ui.myprocess.finished.connect(ui.showtheqprocessdone)
        ui.myprocess.setObjectName(cmd)
        ui.myprocess.start(cmd)
        ui.myprocess.waitForFinished()

    @staticmethod
    def showtheqprocessdone():
        ui.myprocess.kill()
        ui.myprocess = None
        ui.displaynotice("'Finished!")  # or clear the text
        MainWindow.show()

    @staticmethod
    def showtheqprocessstarted(cmd):
        ui.displaynotice("'" + cmd + "' is started, detached!")
        MainWindow.hide()

    @staticmethod
    def urldistrowatch():
        ui.urlcall('https://distrowatch.com/')

    @staticmethod
    def openfileineditor():
        msg = str(ui.cbList.currentText())
        if msg != "nothing" and msg != "select":
            ui.findaneditor(folder_path + "/" + msg)

    # help panels
    @staticmethod
    def leccabout():
        stext = "\n      I'm new to Linux, Python & PySide6. This is my first Python/Qt program.\n\n"
        stext = stext + "      Typing Terminal commands became tedious so I made this program.\n"
        stext = stext + "      This program does not make any system changes nor retrieve any data!!\n"
        stext = stext + "      Some commands require a password, which is optional!\n"
        stext = stext + "      ...\n"
        stext = stext + "      First time this program runs a desktop directory will be created, LECC.\n"
        stext = stext + "      This program puts text files into the desktop folder, LECC.\n"
        stext = stext + "      The output file names are a representation of the commands.\n"
        stext = stext + "      Under Menu/Outputs you can send text outputs to the Terminal.\n"
        stext = stext + "      Many commands will not work unless they are installed.\n"
        stext = stext + "      You can delete the LECC directory since it will be created again.\n"
        stext = stext + "      ...\n"
        stext = stext + "      I created a few styles. When choosing one it is saved in LECCstyleSave.txt.\n"
        stext = stext + "      ...\n"
        stext = stext + "      I used the following software to create this program: \n"
        stext = stext + "      PyCharm,  PySide6,  Python3,  Qt6 Designer,  Nuitka.\n\n"
        stext = stext + "                                               Created  by Davi Rich  aka: Stalkerstein\n"
        ui.displayinformation('About', stext)

    @staticmethod
    def leccnotes():
        stext = "\n                   Many Linux commands are listed on the tabs.\n"
        stext = stext + "                   Most have Run and Man(ual) buttons and a description.\n"
        stext = stext + "                   'Run' buttons execute the command.\n"
        stext = stext + "                   'Man' buttons retrieve the commands' documentation.\n"
        stext = stext + "                   Comboboxes list the command's selections.\n"
        stext = stext + "                   The mouse wheel will move through combobox selections.\n"
        stext = stext + "                   Combobox selections can be altered in this program.\n"
        stext = stext + "                   ...\n"
        stext = stext + "                   Some commands are executed, ex; About.\n"
        stext = stext + "                   Some run through the terminal, ex; neofetch.\n"
        stext = stext + "                   Some run & create a text file with its output, ex; fdisk.\n"
        stext = stext + "                   Some commands have a combobox with options/switches.\n"
        stext = stext + "                   ...\n"
        stext = stext + "                   The 'LECC List' tab will list the files in the directory, LECC.\n"
        stext = stext + "                   There are two buttons, Refresh and Edit File on the list tab.\n"
        stext = stext + "                   Refresh will reload the list in the combobox from LECC directory.\n"
        stext = stext + "                   An editer is used instead of 'cat' to display text.\n"
        stext = stext + "                   ...\n"
        stext = stext + "                   The 'Process Viewers' tab lists programs for viewing processes .\n"
        stext = stext + "                   The 'Video' tab shows programs for video card information.\n"
        stext = stext + "                   Note: I only have NVidia type computers, not AMD.\n"
        stext = stext + "                   ...\n"
        stext = stext + "                   Control+Tab should move across the tabs depending on the distro.\n"
        stext = stext + "                   Tabbing will move through all the buttons and comboboxes.\n"
        stext = stext + "                   ...\n"
        stext = stext + "                   cat (grub.cfg & slabinfo), df, dmesg, dmidecode, du, fdisk, find, \n"
        stext = stext + "                   gparted, gufw, hdparm, history, parted usually require a password.\n"
        stext = stext + "                   ...\n"
        stext = stext + "                   On the lower left of the screen there will be messages displayed. \n"
        stext = stext + "\n"
        ui.displayinformation('Notes', stext)

    @staticmethod
    def lecccommands():
        stext = "\n           Here is a list of commands that might have to be installed based on the distro.\n"
        stext = stext + "           ...\n"
        stext = stext + "           apt, atop, blkid, btop, bpytop, clamtk, cpuinfo, cpu-x, cpufetch, cpupower, \n"
        stext = stext + "           cpupower-gui, df, dig, dmesg, dmidecode, dpkg, du, efibootmgr, env, fdisk, \n"
        stext = stext + "           findmnt, flatpak, firewall-config, free, gdu, getconf, gnome-disks, gparted, \n"
        stext = stext + "           grub-customizer, gufw, hardinfo, hcitool, hdparm, history, hostname, \n"
        stext = stext + "           linuxinfo, hostnamectl, hwinfo, htop, id, ifconfig, inxi, ip, journalctl, \n"
        stext = stext + "           locate, lpstat, lsblk, lscpu, lshw, lslogins, lsmod, lsof, lspci, lsscsi, lsusb, \n"
        stext = stext + "           mlocate, midnight commander, neofetch, netstat, nnmcli, nvidia-settings, \n"
        stext = stext + "           nvidia-settings, nvidia-smi, nvtop, os-prober, parted, pip, printenv, ps, \n"
        stext = stext + "           psensor, nslookup, pip3, pipx, pstree, pydf, qps, rhythmbox, ss, sysctl, \n"
        stext = stext + "           sysstat, tree, uname, vlc, vmstat, w, who, whoami, xinput, versions.\n"
        stext = stext + "           ...\n"
        stext = stext + "           I installed many programs using; a distro specific update program, \n"
        stext = stext + "           apt, discover, dnf, muon, pamac, pacman, pip, pipx, synaptic, yay, zypper.\n"
        stext = stext + "           ...\n"
        stext = stext + "           Some commands can be a little slow when starting up.\n"
        stext = stext + "           Some commands don't always spawn on top. So if not seen try alt+tab.\n"
        ui.displayinformation('Commands', stext)

    @staticmethod
    def lecctesting():
        stext = "\n       There are supposedly hundreds of Linux distros maintained.\n"
        stext = stext + "       Hence testing is basically impossible.\n"
        stext = stext + "       Below is a list of some distros that I attempted to test this program on.\n"
        stext = stext + "       There are many versions, idiosyncrasies, quirks, desktops & programs.\n"
        stext = stext + "       ...\n"
        stext = stext + "       CachyOS, Debian, Endeavour, Feren, Garuda, KDE Neon, Kubuntu, Lite, LMDE, \n"
        stext = stext + "       Manjaro, Mint, MX, Neptune, Nobara, Parrot, Q4OS, Solus, Sparky, Ubuntu\n"
        stext = stext + "       ...\n"
        stext = stext + "       Laptop:\n"
        stext = stext + "       Dell Inspiron 15 5567, Kaby Lake i7-7500U CPU @2.70GHz, Intel HD Graphics 620,\n"
        stext = stext + "       PNY 16GB DDR4 Sync 3200 MHz, SanDisk SDSSDH3 512GB\n\n"
        stext = stext + "       Desktop:\n"
        stext = stext + "       Windows 10, Intel i7-3770k, G.Skill 16 GB, Asus Sabertooth Z77, Nvidia GTX950, \n"
        stext = stext + "       Samsung EVO SSD 512 GB.\n"
        ui.displayinformation('Testing', stext)

    @staticmethod
    def licensecopyright():
        stext = "\n    LECC is free software: you can redistribute it only under the terms of the GNU\n"
        stext = stext + "    General Public License as published by the Free Software Foundation, either\n"
        stext = stext + "    version 3 of the License or (at your option) any later version.\n"
        stext = stext + "    ...\n"
        stext = stext + "    LECC is distributed in the hope that it will be useful, but WITHOUT ANY\n"
        stext = stext + "    WARRANTY; without even the implied warranty of MERCHANTABILITY or\n"
        stext = stext + "    FITNESS FOR A PARTICULAR PURPOSE.\n"
        stext = stext + "    ...\n"
        stext = stext + "    See the GNU General Public License for more details.\n"
        stext = stext + "    https://www.gnu.org/licenses/lgpl-3.0.html\n"
        ui.displayinformation('License/Copyright', stext)

    @staticmethod
    def getoseditor():
        useeditor = ''
        istool = ui.is_toolexist('kate')
        if istool == 'true':
            return 'kate'
        istool = ui.is_toolexist('kwrite')
        if istool == 'true':
            return 'kwrite'
        istool = ui.is_toolexist('pluma')
        if istool == 'true':
            return 'pluma'
        istool = ui.is_toolexist('mousepad')
        if istool == 'true':
            return 'mousepad'
        istool = ui.is_toolexist('vim')
        if istool == 'true':
            return 'vim'
        istool = ui.is_toolexist('xed')
        if istool == 'true':
            return 'xed'
        istool = ui.is_toolexist('gedit')
        if istool == 'true':
            return 'gedit'
        istool = ui.is_toolexist('geany')
        if istool == 'true':
            return 'geany'
        istool = ui.is_toolexist('nano')    # has path but no program
        if istool == 'true':
            return 'nano'
        return useeditor

    @staticmethod
    def getsystemmonitor():
        # distros
        if 'Debian' in sssdesc and 'MX' not in sssdesc and 'Q4OS' not in sssdesc:
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Cachy' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Feren' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            return 'unknown'
        if 'Endeavour' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            if 'Gnome' in sssdesc or 'GNOME' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Budgie' in sssdesc:
                return 'unknown'
            return 'unknown'
        if 'Garuda' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            if 'Gnome' in sssdesc or 'GNOME' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            return 'unknown'
        if 'KDE' in sssdesc and 'Neon' in sssdesc and 'Q4OS' not in sssdesc:
            ui.popen_for_programs('plasma-systemmonitor')
            return 'skip'
        if 'Kubuntu' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Lite' in sssdesc:
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('system-monitoring-center')
                return 'skip'
            return 'unknown'
        if 'Manjaro' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            if 'Gnome' in sssdesc or 'GNOME' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Mint' in sssdesc or 'LMDE' in sssdesc:
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'MX' in sssdesc or 'Mx' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Neptune' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Nobara' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            if 'Gnome' in sssdesc or 'GNOME' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            return 'unknown'
        if 'Parrot' in sssdesc:
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-system-monitor')
                return 'skip'
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Q4OS' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Solus' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            if 'Gnome' in sssdesc or 'GNOME' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Bungie' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Sparky' in sssdesc:
            if 'Plasma' in sssdesc:
                ui.popen_for_programs('plasma-systemmonitor')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-system-monitor')
                return 'skip'
            if 'Bungie' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            return 'unknown'
        if 'Ubuntu' in sssdesc and 'Kubuntu' not in sssdesc and 'Lubuntu' not in sssdesc:
            if 'Cinnamon' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Mate' in sssdesc:
                ui.popen_for_programs('mate-system-monitor')
                return 'skip'
            return 'unknown'
        if 'Zorin' in sssdesc:
            if 'Gnome' in sssdesc or 'GNOME' in sssdesc:
                ui.popen_for_programs('gnome-system-monitor')
                return 'skip'
            if 'Xfce' in sssdesc:
                ui.popen_for_programs('xfce-systemmonitor')
                return 'skip'
            return 'unknown'

        return "unknown"

    @staticmethod
    def getcomboboxdata(cbnbr, cmd):
        dfuse = ''

        if str(cbnbr) > '0':
            if str(cbnbr) == '5':   # works
                # cat
                seltext = ui.cb5.currentText()
                if seltext != 'Select':
                    if ui.actionSend_to_terminal_2.isChecked():
                        dfuse = ('cat ' + seltext)
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        dfuse = ('cat ' + seltext)
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb5")
                return
            if str(cbnbr) == '6':   # works
                seltext = ui.cb6.currentText()
                # apt list
                if seltext != 'Select':
                    # send to terminal
                    if ui.actionSend_to_terminal_2.isChecked():
                        dfuse = ('apt ' + seltext)
                        ui.thread_function_os(dfuse)

                    # sent to text file
                    if ui.actionSend_to_text_file_2.isChecked():
                        dfuse = ('apt ' + seltext)
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb6")
                return
            if str(cbnbr) == '13':  # works
                seltext = ui.cb13.currentText()
                # df
                if seltext != 'Select':
                    # send to terminal
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = (cmd + ' -' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb13")
                return
            if str(cbnbr) == '132' or str(cbnbr) == '13_2':  # works
                seltext = ui.cb13_2.currentText()
                # dig
                if seltext != 'Select':
                    # send to terminal
                    dfuse = (cmd + ' ' + seltext)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb13_2")
                return
            if str(cbnbr) == '15':  # terminal no works
                # dmidecode
                seltext = ui.cb15.currentText()
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = ('/usr/sbin/dmidecode -t ' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():     # prompted
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb15")
                return
            if str(cbnbr) == '22':  # works
                # find (.conf)
                seltext = ui.cb22.currentText()
                if seltext != 'Select':
                    dfuse = ('find ' + seltext + ' -type f -name ' + '*.conf')
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb22")
                return
            if str(cbnbr) == '23':
                # find (image)
                seltext = ui.cb23.currentText()
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = ('find /usr -type f -name ' + '*.' + resultdesc)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb23")
                return
            if str(cbnbr) == '33':  # works
                # hostname
                seltext = ui.cb33.currentText()
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = ('hostname -' + resultchoice)
                    dfuse = dfuse.replace('-@', '')
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb33")
                return
            if str(cbnbr) == '36':
                seltext = ui.cb36.currentText()
                # ifconfig
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = (cmd + ' -' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb36")
                return
            if str(cbnbr) == '37':
                seltext = ui.cb37.currentText()
                # inxi
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = (cmd + ' -' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb37")
                return
            if str(cbnbr) == '38':
                seltext = ui.cb38.currentText()
                # ip
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = (cmd + ' ' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb38")
                return
            if str(cbnbr) == '39':  # for specific distro(s) to show the combobox
                # o/s info
                seltext = ui.cb39.currentText()
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = ('mate-system-monitor -' + resultchoice)
                    ui.popen_function_common_simple(dfuse)
                return
            if str(cbnbr) == '40':
                # locate
                seltext = ui.cb40.currentText()
                if seltext != 'Select':
                    if ui.actionSend_to_terminal_2.isChecked():
                        dfuse = ('locate ' + seltext)
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        dfuse = ('locate ' + seltext)
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb40")
                return
            if str(cbnbr) == '44':
                seltext = ui.cb44.currentText()
                # lpstat
                if seltext != 'Select':
                    if ui.actionSend_to_terminal_2.isChecked():
                        dfuse = ('lpstat ' + seltext)
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        dfuse = ('lpstat ' + seltext)
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb44")
                return
            if str(cbnbr) == '52':
                # ls (dir)
                seltext = ui.cb52.currentText()
                if seltext != 'Select':
                    dfuse = ('ls ' + seltext)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb52")
                return
            if str(cbnbr) == '57':
                seltext = ui.cb57.currentText()
                # netstat
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = (cmd + ' -' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb57")
                return
            if str(cbnbr) == '59':
                seltext = ui.cb59.currentText()
                # nvidia-smi
                if seltext != 'Select' and len(seltext) > 1:
                    if '@' in seltext:
                        # seltext = seltext.replace("@", "")
                        if ui.actionSend_to_terminal_2.isChecked():
                            dfuse = (cmd + ' ' + '| cat')
                            ui.thread_function_os(dfuse)

                        if ui.actionSend_to_text_file_2.isChecked():
                            dfuse = cmd
                            ui.popen_function_common_simple(dfuse)
                    else:
                        resultchoice, resultdesc = seltext.split(' - ')
                        if ui.actionSend_to_terminal_2.isChecked():
                            dfuse = (cmd + ' -' + resultchoice)
                            ui.thread_function_os(dfuse)

                        if ui.actionSend_to_text_file_2.isChecked():
                            dfuse = (cmd + ' -' + resultchoice)
                            ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "59")
                return
            if str(cbnbr) == '66':
                seltext = ui.cb66.currentText()
                # ps
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    if 'u' in resultchoice and 'list' not in resultdesc:
                        resultchoice = 'u ' + resultdesc
                    dfuse = (cmd + ' -' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb66")
                return
            if str(cbnbr) == '73':
                seltext = ui.cb73.currentText()
                # ss
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = (cmd + ' ' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb73")
                return
            if str(cbnbr) == '77':  # works
                seltext = ui.cb77.currentText()
                # uname
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = (cmd + ' -' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb77")
                return
            if str(cbnbr) == '772' or str(cbnbr) == '77_2':  # works underscore lost wtf?
                seltext = ui.cb77_2.currentText()
                # tree
                if seltext != 'Select':
                    dfuse = (cmd + ' ' + seltext)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb77_2")
                return
            if str(cbnbr) == '79':
                seltext = ui.cb79.currentText()
                # vmstat
                if seltext != 'Select':
                    resultchoice, resultdesc = seltext.split(' - ')
                    dfuse = (cmd + ' -' + resultchoice)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "cb79")
                return
            if str(cbnbr) == '83':
                # xinput
                seltext = ui.cb83.currentText()
                if seltext != 'Select' and len(seltext) > 1:
                    resultchoice, resultdesc = seltext.split(' - ')
                    if ui.actionSend_to_terminal_2.isChecked():
                        dfuse = (cmd + ' ' + resultchoice)
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        dfuse = (cmd + ' ' + resultchoice)
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "83")
                return
            if str(cbnbr) == '86':
                # cpupower
                seltext = ui.cb86.currentText()
                if seltext != 'Select' and len(seltext) > 1:
                    if ui.actionSend_to_terminal_2.isChecked():
                        dfuse = (cmd + ' ' + seltext)
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        dfuse = (cmd + ' ' + seltext)
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "86")
                return
            if str(cbnbr) == '94':
                # ls programs
                seltext = ui.cb94.currentText()
                if seltext != 'Select':
                    dfuse = ('ls ' + seltext)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "94")
                return
            if str(cbnbr) == '99':
                # versions
                seltext = ui.cb99.currentText()
                if seltext != 'Select':
                    if seltext == 'audacious':
                        dfuse = 'audacious --version'
                    if seltext == 'bash':
                        dfuse = 'bash --version'
                    if seltext == 'bpytop':
                        dfuse = 'bpytop --version'
                    if seltext == 'btop':
                        dfuse = 'btop --version'
                    if seltext == 'caja':
                        dfuse = 'caja --version'
                    if seltext == 'cinnamon':
                        dfuse = 'cinnamon --version'
                    if seltext == 'claws-mail':
                        dfuse = 'claws-mail --version'
                    if seltext == 'cpu-x':
                        dfuse = 'cpu-x --version'
                    if seltext == 'cpu':
                        dfuse = 'cpu --version'
                    if seltext == 'cpufetch':
                        dfuse = 'cpufetch --version'
                    if seltext == 'cpupower':
                        dfuse = 'cpupower --version'
                    if seltext == 'curl':
                        dfuse = 'curl --version'
                    if seltext == 'df':
                        dfuse = 'df --version'
                    if seltext == 'dmesg':
                        dfuse = 'dmesg --version'
                    if seltext == 'dmidecode':
                        dfuse = 'dmidecode --version'
                    if seltext == 'dolphin':
                        dfuse = 'dolphin --version'
                    if seltext == 'dpkg':
                        dfuse = 'dpkg --version'
                    if seltext == 'du':
                        dfuse = 'du --version'
                    if seltext == 'efibootmgr':
                        dfuse = 'efibootmgr --version'
                    if seltext == 'env':
                        dfuse = 'env --version'
                    if seltext == 'evolution':
                        dfuse = 'evolution --version'
                    if seltext == 'fdisk':
                        dfuse = 'fdisk --version'
                    if seltext == 'findmnt':
                        dfuse = 'findmnt --version'
                    if seltext == 'firefox':
                        dfuse = 'firefox --version'
                    if seltext == 'firejail':
                        dfuse = 'firejail --version'
                    if seltext == 'flatpak':
                        dfuse = 'flatpak --version'
                    if seltext == 'free':
                        dfuse = 'free --version'
                    if seltext == 'gedit':
                        dfuse = 'gedit --version'
                    if seltext == 'get-q4os-version':
                        dfuse = 'get-q4os-version'
                    if seltext == 'getconf':
                        dfuse = 'getconf --version'
                    if seltext == 'gdu':
                        dfuse = 'gdu --version'
                    if seltext == 'gnome-terminal':
                        dfuse = 'gnome-terminal --version'
                    if seltext == 'gthumb':
                        dfuse = 'gthumb --version'
                    if seltext == 'gwenview':
                        dfuse = 'gwenview --version'
                    if seltext == 'grub-customizer':
                        dfuse = 'grub-customizer --version'
                    if seltext == 'hardinfo':
                        dfuse = 'hardinfo --version'
                    if seltext == 'hostname':
                        dfuse = 'hostname --version'
                    if seltext == 'hostnamectl':
                        dfuse = 'hostnamectl --version'
                    if seltext == 'hwinfo':
                        dfuse = 'hwinfo --version'
                    if seltext == 'htop':
                        dfuse = 'htop --version'
                    if seltext == 'id':
                        dfuse = 'id --version'
                    if seltext == 'ifconfig':
                        dfuse = 'ifconfig --version'
                    if seltext == 'inxi':
                        dfuse = 'inxi --version'
                    if seltext == 'kate':
                        dfuse = 'kate --version'
                    if seltext == 'kmail':
                        dfuse = 'kmail --version'
                    if seltext == 'konsole':
                        dfuse = 'konsole --version'
                    if seltext == 'kwrite':
                        dfuse = 'kwrite --version'
                    if seltext == 'libreoffice':
                        dfuse = 'libreoffice -v'
                    if seltext == 'linuxinfo':
                        dfuse = 'linuxinfo -v'
                    if seltext == 'locate':
                        dfuse = 'locate --version'
                    if seltext == 'lolcat':
                        dfuse = 'lolcat --version'
                    if seltext == 'lsblk':
                        dfuse = 'lsblk --version'
                    if seltext == 'lscpu':
                        dfuse = 'lscpu --version'
                    if seltext == 'lslogins':
                        dfuse = 'lslogins --version'
                    if seltext == 'lsscsi':
                        dfuse = 'lsscsi --version'
                    if seltext == 'lspci':
                        dfuse = 'lspci --version'
                    if seltext == 'mate-terminal':
                        dfuse = 'mate-terminal --version'
                    if seltext == 'mc':
                        dfuse = 'mc --version'
                    if seltext == 'mypy':
                        dfuse = 'mypy --version'
                    if seltext == 'nano':
                        dfuse = 'nano --version'
                    if seltext == 'nemo':
                        dfuse = 'nemo --version'
                    if seltext == 'neofetch':
                        dfuse = 'neofetch --version'
                    if seltext == 'netstat':
                        dfuse = 'netstat --version'
                    if seltext == 'nets-tools':
                        dfuse = 'nets-tools --version'
                    if seltext == 'nuitka':
                        if 'Q4OS' in ssdesc:
                            dfuse = '/home/mfcsdhah/.local/bin/nuitka --version'
                        else:
                            dfuse = 'python3 -m nuitka --version'
                    if seltext == 'nvidia-settings':
                        dfuse = 'nvidia-settings --version'
                    if seltext == 'nvidia-smi':
                        dfuse = 'nvidia-smi --version'
                    if seltext == 'nvtop':
                        dfuse = 'nvtop --version'
                    if seltext == 'parted':
                        dfuse = 'parted --version'
                    if seltext == 'pearl':
                        dfuse = 'pearl --version'
                    if seltext == 'pip':
                        dfuse = 'pip --version'
                    if seltext == 'pip3':
                        dfuse = 'pip3 --version'
                    if seltext == 'pipx':
                        dfuse = 'pipx --version'
                    if seltext == 'pluma':
                        dfuse = 'pluma --version'
                    if seltext == 'ps':
                        dfuse = 'ps --version'
                    if seltext == 'psensor':
                        dfuse = 'psensor --version'
                    if seltext == 'pydf':
                        dfuse = 'pydf --version'
                    if seltext == 'pyinstaller':
                        dfuse = 'pyinstaller --version'
                    if seltext == 'python3':
                        dfuse = 'python3 --version'
                    if seltext == 'qps':
                        dfuse = 'qps --version'
                    if seltext == 'refind':
                        dfuse = 'refind --version'
                    if seltext == 'rsync':
                        dfuse = 'rsync --version'
                    if seltext == 'rhythmbox':
                        dfuse = 'rhythmbox --version'
                    if seltext == 'screenfetch':
                        dfuse = 'screenfetch --version'
                    if seltext == 'ss':
                        dfuse = 'ss --version'
                    if seltext == 'stat':
                        dfuse = 'stat --version'
                    if seltext == 'sudo':
                        dfuse = 'sudo --version'
                    if seltext == 'sysctl':
                        dfuse = 'sysctl --version'
                    if seltext == 'thunar':
                        dfuse = 'thunar --version'
                    if seltext == 'timeshift':
                        dfuse = 'timeshift --version'
                    if seltext == 'tor':
                        dfuse = 'tor --version'
                    if seltext == 'uname':
                        dfuse = 'uname --version'
                    if seltext == 'uptime':
                        dfuse = 'uptime --version'
                    if seltext == 'vlc':
                        dfuse = 'vlc --version'
                    if seltext == 'vmstat':
                        dfuse = 'vmstat --version'
                    if seltext == 'w':
                        dfuse = 's --version'
                    if seltext == 'who':
                        dfuse = 'who --version'
                    if seltext == 'whoami':
                        dfuse = 'whoami --version'
                    if seltext == 'xed':
                        dfuse = 'xed --version'
                    if seltext == 'xfce4-terminal':
                        dfuse = 'xfce4-terminal --version'
                    if seltext == 'xinput':
                        dfuse = 'xinput --version'

                    if 'Select' not in dfuse and len(dfuse) > 1:
                        if ui.actionSend_to_terminal_2.isChecked():
                            dfuse = (dfuse + " | lolcat")
                            ui.thread_function_os(dfuse)

                        if ui.actionSend_to_text_file_2.isChecked():
                            ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "99")
                return
            if str(cbnbr) == '101':
                # apt policy
                seltext = ui.cb101.currentText()
                if seltext != 'Select' and len(seltext) > 1:
                    if ui.actionSend_to_terminal_2.isChecked():
                        dfuse = (cmd + ' ' + seltext)
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        dfuse = (cmd + ' ' + seltext)
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdataqprocess)", "", "101")
                return
            if str(cbnbr) == '102':
                # du
                seltext = ui.cb102.currentText()
                if seltext != 'Select':
                    dfuse = ('du -h ' + seltext)
                    if seltext != 'Select':
                        if ui.actionSend_to_terminal_2.isChecked():
                            ui.thread_function_os(dfuse)

                        if ui.actionSend_to_text_file_2.isChecked():
                            ui.popen_function_common_simple(dfuse)
                    return

                if 'Select' not in dfuse and len(dfuse) > 1:
                    ui.popen_function_common(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdata)", "", "102")
            if str(cbnbr) == '108':
                seltext = ui.cb108.currentText()
                # nslookup
                if seltext != 'Select':
                    dfuse = (cmd + ' ' + seltext)
                    if ui.actionSend_to_terminal_2.isChecked():
                        ui.thread_function_os(dfuse)

                    if ui.actionSend_to_text_file_2.isChecked():
                        ui.popen_function_common_simple(dfuse)
                else:
                    ui.displayerror('Whoops!', "Please make a selection.", "(getcomboboxdata)", "", "108")
                return

    @staticmethod
    def getcomboboxdataqprocess(cbnbr):
        if str(cbnbr) == '7':   # works
            # atop
            seltext = ui.cb7.currentText()
            if seltext != 'Select':
                resultchoice, resultdesc = seltext.split(' - ')
                dfuse = ('atop -' + resultchoice)
                ui.thread_function(dfuse)
                return

        if str(cbnbr) == '76':  # works
            # top
            seltext = ui.cb76.currentText()
            if seltext != 'Select':
                resultchoice, resultdesc = seltext.split(' - ')
                dfuse = ('top -' + resultchoice + " " + resultdesc)
                if "@" in dfuse:
                    dfuse = dfuse.replace('@', '')
                ui.thread_function(dfuse)
                return

    @staticmethod
    def stylecyan():
        ui.savethestyle('cyan')

        app.setStyleSheet("""
                           QLabel { color: #5d5d5d; }
                           QMenuBar { color: #004242; }
                           QMenu { color: #004242; }
                           QMenu::item:selected {background: #ccffff; }

                           QTabBar::tab { background: #008080; color: white; padding: 10px; }
                           QTabBar::tab:selected { background: #00c2c2; }

                           QTabWidget::pane { border: none; }

                           QPushButton { background-color: #00a8a8; }
                           QPushButton::pressed { color: rgb(224, 0, 0); }
                           QPushButton::hover { background-color: #008080; }
                           QPushButton::focus { background-color: #008080; }

                           QComboBox { background-color: white; color: black; }
                           QComboBox::hover { background-color: white; border: 2px #00cccc; border-style: solid; }
                           QComboBox::focus { background-color: white; border: 2px #00b8b8; border-style: solid; }
                           QComboBox::dropdown { background-color: white; }
                           QComboBox::down-arrow { background-color: #00b8b8; }
                           QComboBox QAbstractItemView { border: 2px solid #00b8b8; 
                           selection-color: magenta; selection-background-color: white; }

                           QStatusBar { background-color: #009999; }
                        """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: #4d4d4d")

    @staticmethod
    def stylegray():
        ui.savethestyle('gray')

        app.setStyleSheet("""
                   QLabel { color: #5d5d5d; }
                   QMenuBar { color: #464646; }
                   QMenu { color: #464646; }
                   QMenu::item:selected {background: #ebebeb; }
                   
                   QTabBar::tab { background: #838383; color: white; padding: 10px; }
                   QTabBar::tab:selected { background: #b4b4b4; }
                   
                   QTabWidget::pane { border: none; }
                   
                   QPushButton { background-color: #9d9d9d; }
                   QPushButton::pressed { color: rgb(224, 0, 0); }
                   QPushButton::hover { background-color: #5d5d5d; }
                   QPushButton::focus { background-color: #5d5d5d; }
                   
                   QComboBox { background-color: white; color: black; }
                   QComboBox::hover { background-color: white; border: 2px gray; border-style: solid; }
                   QComboBox::focus { background-color: white; border: 2px #575757; border-style: solid; }
                   QComboBox::dropdown { background-color: white; }
                   QComboBox::down-arrow { background-color: #aeaeae; }
                   QComboBox QAbstractItemView { border: 2px solid darkgray; 
                   selection-color: magenta; selection-background-color: white; }
                   
                   QStatusBar { background-color: #b4b4b4; }
                """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: #4d4d4d")

    @staticmethod
    def stylecocoa():
        ui.savethestyle('cocoa')

        app.setStyleSheet("""
                    QLabel { color: #f1e7da; }
                    QMenuBar { color: #8f6938; }
                    QMenu { color: #8f6938; } 
                    QMenu::item:selected {background: #f1e7da; }
            
                    QTabBar::tab { background: #cca97b; color: #46331b; padding: 10px;}
                    QTabBar::tab:selected { background: #e2cfb6; }
            
                    QTabWidget::pane { border: none; }
            
                    QPushButton { background-color: #e2cfb6; }
                    QPushButton::pressed { color: rgb(224, 0, 0); }
                    QPushButton::hover { background-color: #cca97b; }
                    QPushButton::focus { background-color: #cca97b; }
            
                    QComboBox { background-color: white; color: black; }
                    QComboBox::hover { background-color: white; border: 2px #cca97b; border-style: solid; }
                    QComboBox::focus { background-color: white; border: 2px #cca97b; border-style: solid; }
                    QComboBox::dropdown { background-color: white; }
                    QComboBox::down-arrow { background-color: #e2cfb6; }
                    QComboBox QAbstractItemView { border: 2px solid darkgray; 
                    selection-color: magenta; selection-background-color: white; }
            
                    QStatusBar { background-color: #e2cfb6; }
                 """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: #46331b")

    @staticmethod
    def stylelight():
        ui.savethestyle('light')

        app.setStyleSheet("""
                    QWidget { background-color: white; }
                    QLabel { color: black; }
                    QMenuBar { color: black; }
                    QMenu { color: black; }
                    QMenu::item:selected {background: #e3e3e3; }
                    
                    QTabBar::tab { background: #ecf0f1; color: black; padding: 10px; }
                    QTabBar::tab:selected { background: lightgray; color: snow; }
                    
                    QTabWidget::pane { border: none; }
                    
                    QPushButton { color: black; }
                    QPushButton::pressed { color: rgb(224, 0, 0); }
                    QPushButton::hover { background-color: #d7dbdd; }
                    QPushButton::focus { background-color: #d7dbdd; } 
                    
                    QComboBox { color: black; background-color: white; }
                    QComboBox::hover { background-color: white; border: 2px darkgray; border-style: solid; }
                    QComboBox::focus { background-color: white; border: 2px darkgray; border-style: solid; }
                    QComboBox::dropdown { background-color: white; }
                    QComboBox::dropdown { background-color: #ecf0f1; }
                    QComboBox::down-arrow { background-color: #ecf0f1; }
                    QComboBox QAbstractItemView { border: 2px solid darkgray; 
                    selection-color: magenta; selection-background-color: white; }
                    
                    QStatusBar { color: #424242; }
                 """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: black")

    @staticmethod
    def styleteal():
        ui.savethestyle('teal')

        app.setStyleSheet("""
                    QLabel { color: rgb(0,76,76); }
                    QMenuBar { color: rgb(0,76,76); }
                    QMenu { color: rgb(0,76,76); }
                    QMenu::item:selected {background: #b3ffff; }
                    
                    QTabBar::tab { background: rgb(102,178,178); color: white; padding: 10px; }
                    QTabBar::tab:selected { background: rgb(178,216,216); }
                    
                    QTabWidget::pane { border: none; }
                    
                    QPushButton { background-color: rgb(178,216,216); }
                    QPushButton::pressed { color: rgb(224, 0, 0); }
                    QPushButton::hover { background-color: rgb(102,178,178); }
                    QPushButton::focus { background-color: rgb(102,178,178); }
                    
                    QComboBox { background-color: white; color: black; }
                    QComboBox::hover { background-color: white; border: 2px rgb(102,178,178); border-style: solid; }
                    QComboBox::focus { background-color: white; border: 2px rgb(102,178,178); border-style: solid; }
                    QComboBox::dropdown { background-color: white; }
                    QComboBox::down-arrow { background-color: rgb(178,216,216); }
                    QComboBox QAbstractItemView { border: 2px solid darkgray; 
                    selection-color: magenta; selection-background-color: white; }
                    
                    QStatusBar { background: rgb(178,216,216); } 
                 """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: #005757")

    @staticmethod
    def stylegreen():
        ui.savethestyle('green')

        app.setStyleSheet("""
                    QLabel { color: #1b2019; }
                    QMenuBar { color: #455140; }
                    QMenu { color: #455140; }
                    QMenu::item:selected {background: #dceadc; }
                    
                    QTabBar::tab { background: #52be80; color: white; padding: 10px; }
                    QTabBar::tab:selected { background: #b3e6c9; }
                    
                    QTabWidget::pane { border: none; }
                    
                    QPushButton { background-color: #90dab1; }
                    QPushButton::pressed { color: rgb(224, 0, 0); }
                    QPushButton::hover { background-color: #84b070; }
                    QPushButton::focus { background-color: #84b070; }
                    
                    QComboBox { background-color: white; color: black; }
                    QComboBox::hover { background-color: white; border: 2px #759c64; border-style: solid; }
                    QComboBox::focus { background-color: white; border: 2px #759c64; border-style: solid; }
                    QComboBox::dropdown { background-color: white; }
                    QComboBox::down-arrow { background-color: #52be80; }
                    QComboBox QAbstractItemView { border: 2px solid darkgray; 
                    selection-color: magenta; selection-background-color: white; }
                    
                    QStatusBar { background: #90dab1; }
                 """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: #21633e")

    @staticmethod
    def styleblue():
        ui.savethestyle('blue')

        app.setStyleSheet("""
                    QLabel { color: rgb(0,76,76); }
                    QMenuBar { color: darkblue; }
                    QMenu { color: darkblue; }
                    QMenu::item:selected {background: #b1dffc; }
                    
                    QTabBar::tab { background: #2980b9; color: white; padding: 10px; }
                    QTabBar::tab:selected { background: #94aec4; }
                    
                    QTabWidget::pane { border: none; }
                    
                    QPushButton { background-color: #94aec4; }
                    QPushButton::pressed { color: rgb(224, 0, 0); }
                    QPushButton::hover { background-color: #2a5d8a; }
                    QPushButton::focus { background-color: #2a5d8a; }
                    
                    QComboBox { background-color: white; color: black; }
                    QComboBox::hover { background-color: white; border: 2px #778c9e; border-style: solid; }
                    QComboBox::focus { background-color: white; border: 2px #778c9e; border-style: solid; }
                    QComboBox::dropdown { background-color: snow; }
                    QComboBox::down-arrow { background-color: #778c9e; }
                    QComboBox QAbstractItemView { border: 2px solid darkgray; 
                    selection-color: magenta; selection-background-color: white; }
                    
                    QStatusBar { background: #94aec4; }
                 """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: #2980b9")

    @staticmethod
    def styletan():
        ui.savethestyle('tan')

        app.setStyleSheet("""
                    QLabel { color: #caa677; }
                    QMenuBar { color: #caa677; }
                    QMenu { color: #caa677; }
                    QMenu::item:selected {background: #b1dffc; }

                    QTabBar::tab { background: #dbc3a3; color: white; padding: 10px; }
                    QTabBar::tab:selected { background: #ece0cf; }

                    QTabWidget::pane { border: none; }

                    QPushButton { background-color: #ece0cf; }
                    QPushButton::pressed { color: rgb(224, 0, 0); }
                    QPushButton::hover { background-color: #d7bc98; }
                    QPushButton::focus { background-color: #d7bc98; }

                    QComboBox { background-color: white; color: black; }
                    QComboBox::hover { background-color: white; border: 2px #caa677; border-style: solid; }
                    QComboBox::focus { background-color: white; border: 2px #caa677; border-style: solid; }
                    QComboBox::dropdown { background-color: snow; }
                    QComboBox::down-arrow { background-color: #caa677; }
                    QComboBox QAbstractItemView { border: 2px solid #ece0cf; 
                    selection-color: magenta; selection-background-color: white; }

                    QStatusBar { background: #ece0cf; }
                 """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: #cdab7e")

    @staticmethod
    def styledark():
        ui.savethestyle('dark')

        app.setStyleSheet("""
                    QWidget { background-color: #8c8c8c; }
                    QLabel { color: snow; }
                    QMenuBar { color: snow; }
                    QMenu { color: snow; }
                    QMenu::item:selected {background: #e3e3e3; }
                    
                    QTabBar::tab { background: #969696; color: white; padding: 10px; }
                    QTabBar::tab:selected { background: #c6c6c6; }
                    
                    QTabWidget::pane { border: none; }
                    
                    QPushButton { background-color: #c6c6c6; }
                    QPushButton::pressed { color: rgb(224, 0, 0); }
                    QPushButton::hover { background-color: #969696; }
                    QPushButton::focus { background-color: #969696; }
                    
                    QComboBox { background-color: #f2f2f2; color: black; }
                    QComboBox::hover { background-color: #969696; border: 2px #696969; border-style: solid; }
                    QComboBox::focus { background-color: #969696; border: 2px #696969; border-style: solid; }
                    QComboBox::dropdown { background-color: white; }
                    QComboBox::down-arrow { background-color: #969696; }
                    QComboBox QAbstractItemView { border: 2px solid darkgray; background-color: #e6e6e6; 
                    selection-color: magenta; selection-background-color: white; }
                    
                    QStatusBar { color: #c6c6c6; }
                 """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: snow")

    @staticmethod
    def styledarkdark():
        ui.savethestyle('darkdark')

        app.setStyleSheet("""
                   QWidget { background-color: #555555; }
                   QLabel { color: snow; }
                   QMenuBar { color: snow; }
                   QMenu { background: #a6a6a6; color: snow; }
                   QMenu::item:selected {background: #383838; }
                   
                   QTabBar::tab { background: #4c4c4c; color: white; padding: 10px; }
                   QTabBar::tab:selected { background: #bebebe; }
                   
                   QTabWidget::pane { border: none; }
                   
                   QPushButton { background-color: #bebebe; }
                   QPushButton::pressed { color: rgb(224, 0, 0); }
                   QPushButton::hover { background-color: #969696; }
                   QPushButton::focus { background-color: #969696; }
                   
                   QComboBox { background-color: white; color: black; }
                   QComboBox::hover { background-color: white; border: 2px #696969; border-style: solid; }
                   QComboBox::focus { background-color: white; border: 2px #696969; border-style: solid; }
                   QComboBox::dropdown { background-color: white; }
                   QComboBox::down-arrow { background-color: #696969; }
                   QComboBox QAbstractItemView { border: 2px solid darkgray; background-color: lightgray; 
                   selection-color: magenta; selection-background-color: white; }
                   
                   QStatusBar { color: snow; }
                """)

        for w in MainWindow.findChildren(QLabel):
            w.setStyleSheet("color: snow")

    @staticmethod
    def setthestyle(globalstylevalue):
        # done at boot time
        if globalstylevalue == 'tan':
            ui.styletan()
        if globalstylevalue == 'cyan':
            ui.stylecyan()
        if globalstylevalue == 'gray':
            ui.stylegray()
        if globalstylevalue == 'cocoa':
            ui.stylecocoa()
        if globalstylevalue == 'light':
            ui.stylelight()
        if globalstylevalue == 'teal':
            ui.styleteal()
        if globalstylevalue == 'green':
            ui.stylegreen()
        if globalstylevalue == 'blue':
            ui.styleblue()
        if globalstylevalue == 'dark':
            ui.styledark()
        if globalstylevalue == 'darkdark':
            ui.styledarkdark()

    @staticmethod
    def savethestyle(thestyle):
        my_file = open("LECCstyleSave.txt", "w")
        my_file.write(thestyle)
        my_file.close()

    @staticmethod
    def getsavedstyle():
        my_file = "LECCstyleSave.txt"
        if os.path.isfile(my_file):
            use_file = open(my_file, "r")
            thestyle = use_file.read()
            thestyle = thestyle.replace('\n', '')
            return thestyle
        else:
            my_file = open("LECCstyleSave.txt", "w")
            my_file.write('gray')
            my_file.close()
            return 'gray'

    @staticmethod
    def cb39showhide():
        # o/s info, kinfocenter; hide by default
        ui.pb39_2.hide()
        ui.lb39_3.hide()
        ui.cb39.hide()
        ui.lb39_4.hide()
        ui.pb39_3.hide()
        ui.lb39_6.hide()
        ui.lb39_5.hide()

        if 'Cachy' in sssdesc or 'Manjaro' in sssdesc:
            return
        if 'Debian' in sssdesc:
            if 'MX' not in sssdesc and 'Q4OS' not in sssdesc and \
               'bookworm' not in sssdesc and 'Bookworm' not in sssdesc:
                ui.cb39.show()
        if 'Feren' in sssdesc:
            ui.pb39_2.show()
            ui.lb39_3.show()
            ui.lb39_4.show()
            return
        if 'xMint' in sssdesc or 'xLMDE' in sssdesc:
            ui.pb39_2.show()
            ui.lb39_3.show()
            ui.lb39_4.show()
            return
        if 'MX' in sssdesc or 'Mx' in sssdesc:
            return
        if 'Solus' in sssdesc or 'Endeavour' in sssdesc or \
           'Q4OS' in sssdesc or 'Plasma' in sssdesc:
            if 'Neptune' not in sssdesc:
                ui.cb39.show()
        if 'Ubuntu?' in sssdesc:
            # cannot find an information display
            ui.pb39_2.show()
            ui.lb39_3.show()
            ui.lb39_4.show()

    @staticmethod
    def loadallcomboboxes():
        # cat
        ui.cb5.setEditable(True)
        ui.cb5.setMaxVisibleItems(10)
        ui.cb5.lineEdit().setReadOnly(True)
        ui.cb5.setStyleSheet("QComboBox"
                             "{""background-color: white""}")
        ui.cb5.update()
        cat_list = ["Select", "/boot/grub/grub.cfg", "/etc/apt/sources.list", "/etc/clamav/freshclam.conf",
                    "/etc/cpupower_gui.conf", "/etc/default/grub", "/etc/fstab", "/etc/group",
                    "/etc/issue", "/etc/lsb-release", "/etc/os-release", "/etc/motd", "/etc/printcap",
                    "/etc/sysctl.conf", "/proc/cpuinfo", "/proc/filesystems", "/proc/interrupts",
                    "/proc/ioports", "/proc/loadavg", "/proc/meminfo", "/proc/mounts",
                    "/proc/net/dev", "/proc/slabinfo", "/proc/stat", "/proc/swaps",
                    "/proc/sys/vm/dirty_background_ratio", "/proc/sys/vm/dirty_ratio",
                    "/proc/version", "/usr/bin/os-prober", "/usr/lib/os-release"]
        ui.cb5.addItems(cat_list)

        # apt list
        ui.cb6.setEditable(True)
        ui.cb6.setMaxVisibleItems(10)
        ui.cb6.lineEdit().setReadOnly(True)
        ui.cb6.setStyleSheet("QComboBox"
                             "{""background-color: white""}")
        ui.cb6.update()
        apt_list = ["Select", "list --installed", "list --upgradeable"]
        ui.cb6.addItems(apt_list)

        # atop
        ui.cb7.setEditable(True)
        ui.cb7.setMaxVisibleItems(10)
        ui.cb7.lineEdit().setReadOnly(True)
        ui.cb7.setStyleSheet("QComboBox"
                             "{""background-color: white""}")
        ui.cb7.update()
        atop_list = ["Select", "au - Number of processes for each user ",
                     "c - bg processes command-lines", "d - Show disk-related process info",
                     "g - Show general output", "j - Show process activity accumulated per Docker",
                     "m - Show memory-related process info", "n - Network related output",
                     "o - Show user-defined line of the process",
                     "p - Show process activity accumulated per program",
                     "s - Show which core a process is using",
                     "v - show process characteristics/start time",
                     "y - thread-specific resource utilization"]
        ui.cb7.addItems(atop_list)

        # df
        ui.cb13.setEditable(True)
        ui.cb13.setMaxVisibleItems(10)
        ui.cb13.lineEdit().setReadOnly(True)
        ui.cb13.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb13.update()
        df_list = ["Select", "a - List pseudo, dups, inaccessible file systems", "h - Disk usage",
                   "l - List local file systems", "m - List mounted file systems"]
        ui.cb13.addItems(df_list)

        # dig
        ui.cb13_2.setEditable(True)
        ui.cb13_2.setMaxVisibleItems(10)
        ui.cb13_2.lineEdit().setReadOnly(True)
        ui.cb13_2.setStyleSheet("QComboBox"
                                "{""background-color: white""}")
        ui.cb13_2.update()
        dg_list = ["Select",
                   "www.asus.com", "www.amd.com", "www.anandtech.com",
                   "www.distrowatch.com", "www.duckduckgo.com",
                   "www.evga.com", "www.hp.com",
                   "www.google.com", "www.microsoft.com", "www.newegg.com",
                   "www.pcworld.com", "www.tomshardware.com",
                   "www.nvidia.com",
                   "www.userbenchmark.com", "www.youtube.com", ]
        ui.cb13_2.addItems(dg_list)

        # dmidecode
        ui.cb15.setEditable(True)
        ui.cb15.setMaxVisibleItems(10)
        ui.cb15.lineEdit().setReadOnly(True)
        ui.cb15.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb15.update()
        dmidecode_list = ["Select", "0 - BIOS",
                          "1 - System", "2 - Baseboard", "3 - Chassis", "4 - Processor",
                          "5 - Memory Controller", "6 - Memory Module", "7 - Cache", "8 - Port Connector",
                          "9 - System Slots", "10 - On-Board Devices", "11 - OEM Strings",
                          "12 - System Config Options", "13 - Bios Language", "16 - Physical Memory Array",
                          "17 - Memory Devices", "18 - 32bit Memory Error",
                          "19 - Memory Array Mapped", "20 - Memory Devices Mapped",
                          "26 - Voltage Probe", "27 - Cooling Device", "28 - Temperature Probes",
                          "29 - Electrical Current Probe", "32 - System Boot", "34 - Mgmt Device",
                          "35 - Mgmt Device Comp", "36 - Mgmt Device Threshold Data",
                          "39 - Power Supply", "40 - Additional Info", "41 - Onboard Devices Ext. Info"]
        ui.cb15.addItems(dmidecode_list)

        # find .conf
        ui.cb22.setEditable(True)
        ui.cb22.setMaxVisibleItems(8)
        ui.cb22.lineEdit().setReadOnly(True)
        ui.cb22.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb22.update()
        find_conf_list = ["Select", "/bin", "/boot", "/etc", "/dev", "/home", "/lib", "/media",
                          "/mnt", "/opt", "/proc", "/srv", "/sys", "/tmp", "/usr", "/var"]
        ui.cb22.addItems(find_conf_list)

        # find image
        ui.cb23.setEditable(True)
        ui.cb23.setMaxVisibleItems(6)
        ui.cb23.lineEdit().setReadOnly(True)
        ui.cb23.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb23.update()
        findi_list = ["Select", "@ - bmp", "@ - gif", "@ - jpg", "@ - jpeg", "@ - png", "@ - tiff"]
        ui.cb23.addItems(findi_list)

        # hostname
        ui.cb33.setEditable(True)
        ui.cb33.setMaxVisibleItems(10)
        ui.cb33.lineEdit().setReadOnly(True)
        ui.cb33.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb33.update()
        hostname_list = ["Select", "@ - No switch shows the host name",
                         "i - Shows ip adddress", "I - Shows all ip adddresses"]
        ui.cb33.addItems(hostname_list)

        # ifconfig
        ui.cb36.setEditable(True)
        ui.cb36.setMaxVisibleItems(10)
        ui.cb36.lineEdit().setReadOnly(True)
        ui.cb36.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb36.update()
        ifconfig_list = ["Select", "a - List all available interfaces", "s - Short list of interfaces"]
        ui.cb36.addItems(ifconfig_list)

        # inxi
        ui.cb37.setEditable(True)
        ui.cb37.setMaxVisibleItems(10)
        ui.cb37.lineEdit().setReadOnly(True)
        ui.cb37.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb37.update()
        inxi_list = ["Select", "a - cpu,speed,kernel,up,mem,storage,procs,shell,inxi version",
                     "b - cpu,speed,mem,sys,mach,cpu,gpu,net,drives,procs", "d - Optical drive info",
                     "f - Show all CPU flags used", "l - Show partition labels", "i - Network device info",
                     "m - Memory info", "n - Advance Network device info", "o - Unmounted partition info",
                     "p - Full partition info", "r - Distro repositories", "s - Sensors (temps & fan speeds)",
                     "t - Processes (top 5)", "tcm - CPU procs & mem used (top 5)",
                     "up - Partition UUIDs", "z - cpu,speed,kernel,up,mem,storage,procs,shell version,inxi version",
                     "w - Weather (local)", "A - Sound card(s) info & driver(s)",
                     "B - System battery info", "C - CPU core speeds (if available)",
                     "D - Total disk space & used percentage", "F - Full output for inxi",
                     "G - graphic card(s) info & driver(s)", "I - Procs, uptime, mem, space, shell, ver",
                     "M - Computer information", "N - Network info & driver", "R - RAID info",
                     "S - Host name, kernel, desktop env", "Fxpmzr - Show system information list",
                     "Fxz - Shows hardware specifications", "Fxxz - Shows hardware information"]
        ui.cb37.addItems(inxi_list)

        # ip
        ui.cb38.setEditable(True)
        ui.cb38.setMaxVisibleItems(10)
        ui.cb38.lineEdit().setReadOnly(True)
        ui.cb38.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb38.update()
        ip_list = ["Select", "link show - Show network devices",
                   "neigh - Shows current neighbor table in kernel", "route - Show routing table"]
        ui.cb38.addItems(ip_list)

        # o/s info
        ui.cb39.setEditable(True)
        ui.cb39.setMaxVisibleItems(10)
        ui.cb39.lineEdit().setReadOnly(True)
        ui.cb39.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb39.update()
        info_list = ["Select", "s - System Information", "p - System Processes",
                     "r - System Resources", "f - File Systems"]
        ui.cb39.addItems(info_list)

        # locate
        ui.cb40.setEditable(True)
        ui.cb40.setMaxVisibleItems(10)
        ui.cb40.lineEdit().setReadOnly(True)
        ui.cb40.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb40.update()
        locate_list = ["Select", "*.bash", "*.bin", "*.bmp", "*.class", "*.cfg", "*.cpp", "*.css",
                       "*.csv", "*.deb", "*.efi", "*.gcs", "*.gif", "*.gqv", "*.gz", "*.html", "*.ini",
                       "*.java", "*.jpg", "*.jpeg", "*.js", "*.log", "*.linux", "*.ogv", "*.pdf",
                       "*.php", "*.pl", "*.png", "*.py", "*.rar", "*.rtf", "*.tiff", "*.txt", "*.wav",
                       "*.xcf", "*.zip"]
        ui.cb40.addItems(locate_list)

        # lpstat
        ui.cb44.setEditable(True)
        ui.cb44.setMaxVisibleItems(8)
        ui.cb44.lineEdit().setReadOnly(True)
        ui.cb44.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb44.update()
        lpstat_list = ["Select", "d - Current default destination", "e - Available destinations on local network",
                       "l - Long listing of printers, classes, jobs", "r - CUPS server status",
                       "s - Status summery", "t - All status information: a,c,d,o,p,r,v",
                       "u - List current user print jobs", "v - List printers", "H - Server host name and port"]
        ui.cb44.addItems(lpstat_list)

        # ls (dir)
        ui.cb52.setEditable(True)
        ui.cb52.setMaxVisibleItems(10)
        ui.cb52.lineEdit().setReadOnly(True)
        ui.cb52.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb52.update()
        ls_list = ["Select", "/bin", "/boot", "/cdrom", "/dev", "/etc", "/home", "/lib", "/srv",
                   "/lib64", "/libx32", "/media", "/mnt", "/opt", "/proc", "/root", "/run", "/sbin",
                   "/swapfile", "/sys", "/tmp", "/usr", "/var"]
        ui.cb52.addItems(ls_list)

        # netstat
        ui.cb57.setEditable(True)
        ui.cb57.setMaxVisibleItems(10)
        ui.cb57.lineEdit().setReadOnly(True)
        ui.cb57.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb57.update()
        netstat_list = ["Select", "g - Multicast group membership", "i - Show Kernel interface table",
                        "pnltu - Show active listen ports", "s - Network statistics",
                        "r - Show Kernel routing table"]
        ui.cb57.addItems(netstat_list)

        # nvidia-smi
        ui.cb59.setEditable(True)
        ui.cb59.setMaxVisibleItems(10)
        ui.cb59.lineEdit().setReadOnly(True)
        ui.cb59.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb59.update()
        netstat_list = ["Select", "@ - No switch shows gpu driver info", "L - Shows gpu name"]
        ui.cb59.addItems(netstat_list)

        # ps
        ui.cb66.setEditable(True)
        ui.cb66.setMaxVisibleItems(10)
        ui.cb66.lineEdit().setReadOnly(True)
        ui.cb66.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb66.update()
        findme = (os.environ['HOME'])
        findme = findme.replace("home", "")
        findme = findme.replace("/", "")
        ui.cb66.addItem('Select')
        ui.cb66.addItem('u - ' + findme)
        ps_list = ["au -  list processes by user",
                   "auxwf - list user, pid, resource usage/child procs",
                   "ax - list processes using BSD", "ef - list processes standard display",
                   "A - list all processes", "U root - list  processes for root"]
        ui.cb66.addItems(ps_list)

        # ss
        ui.cb73.setEditable(True)
        ui.cb73.setMaxVisibleItems(10)
        ui.cb73.lineEdit().setReadOnly(True)
        ui.cb73.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb73.update()
        ss_list = ["Select", "-a - Listening/non-listening  sockets",
                   "-ta - List TCP sockets", "-m - Show socket memory usage",
                   "-sa - List all SCTP sockets", "-ua - List all UDP sockets"]
        ui.cb73.addItems(ss_list)

        # top
        ui.cb76.setEditable(True)
        ui.cb76.setMaxVisibleItems(10)
        ui.cb76.lineEdit().setReadOnly(True)
        ui.cb76.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb76.update()
        findme = (os.environ['HOME'])
        findme = findme.replace("home", "")
        findme = findme.replace("/", "")
        ui.cb76.addItem('Select')
        ui.cb76.addItem('u - ' + findme)
        top_list = ["u - daemon", "u - root"]
        ui.cb76.addItems(top_list)

        # uname
        ui.cb77.setEditable(True)
        ui.cb77.setMaxVisibleItems(10)
        ui.cb77.lineEdit().setReadOnly(True)
        ui.cb77.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb77.update()
        uname_list = ["Select", "a - Show all known information",
                      "i - hardware platform", "m - system architecture",
                      "n - network node hostname", "o - operating system",
                      "p - processor type", "r - kernel release",
                      "s - kernel name", "v - kernel version"]
        ui.cb77.addItems(uname_list)

        # tree
        ui.cb77_2.setEditable(True)
        ui.cb77_2.setMaxVisibleItems(10)
        ui.cb77_2.lineEdit().setReadOnly(True)
        ui.cb77_2.setStyleSheet("QComboBox"
                                "{""background-color: white""}")
        ui.cb77_2.update()
        tree_list = ["Select", "/bin", "/boot", "/etc", "/dev", "/home", "/lib", "/lib64", "/media",
                     "/mnt", "/opt", "/proc", "/sbin", "/srv", "/sys", "/tmp", "/usr", "/var"]
        ui.cb77_2.addItems(tree_list)

        # vmstat
        ui.cb79.setEditable(True)
        ui.cb79.setMaxVisibleItems(10)
        ui.cb79.lineEdit().setReadOnly(True)
        ui.cb79.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb79.update()
        vmstat_list = ["Select", "a - Displays active & inactive memory",
                       "d - List all disk statistics", "m - Kernel slab info if supported",
                       "s - Table of various event counters", "D - Summerize disk statistics"]
        ui.cb79.addItems(vmstat_list)

        # xinput
        ui.cb83.setEditable(True)
        ui.cb83.setMaxVisibleItems(10)
        ui.cb83.lineEdit().setReadOnly(True)
        ui.cb83.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb83.update()
        xinput_list = ["Select", "list - All the input devices", "list --long - Detailed capabilities of devices"]
        ui.cb83.addItems(xinput_list)

        # cpupower
        ui.cb86.setEditable(True)
        ui.cb86.setMaxVisibleItems(10)
        ui.cb86.lineEdit().setReadOnly(True)
        ui.cb86.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb86.update()
        cpupower = ["Select", "frequency-info", "idle-info", "info"]
        ui.cb86.addItems(cpupower)

        # ls programs
        ui.cb94.setEditable(True)
        ui.cb94.setMaxVisibleItems(10)
        ui.cb94.lineEdit().setReadOnly(True)
        ui.cb94.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb94.update()
        lsprograms_list = ["Select", "/usr/bin/", "/usr/local/bin/", "/usr/lib/",
                           "/usr/local/lib", "/usr/share/applications"]
        ui.cb94.addItems(lsprograms_list)

        # versions
        ui.cb99.setEditable(True)
        ui.cb99.setMaxVisibleItems(10)
        ui.cb99.lineEdit().setReadOnly(True)
        ui.cb99.setStyleSheet("QComboBox"
                              "{""background-color: white""}")
        ui.cb99.update()
        versions_list = ["Select", "audacious", "bash", "bpytop", "btop", "caja", "celluloid", "cinnamon",
                         "claws-mail", "cpu",
                         "cpufetch", "cpupower", "cpupower-gui", "cpu-x", "curl", "dolphin", "df", "dmesg",
                         "dmidecode", "dpkg", "du", "efibootmgr", "env",
                         "evolution", "fdisk", "findmnt", "firefox", "firejail", "flatpak", "free",
                         "gdu", "get-q4os-version", "gedit", "getconf", "gdu", "gnome-terminal", "gthumb", "gwenview",
                         "grub-customizer", "hardinfo", "hostname", "hostnamectl", "hwinfo", "htop", "id",
                         "ifconfig", "inxi", "kate", "kmail", "konsole", "kwrite", "libreoffice", "linuxinfo", "locate",
                         "lolcat", "lsblk", "lscpu", "lslogins", "lsscsi", "lspci", "mc", "mate-terminal", "mypy",
                         "nano", "nemo", "neofetch", "netstat", "net-tools", "nuitka", "nvidia-settings",
                         "nvidia-smi", "nvtop", "parted", "printenv", "psensor", "pearl", "pip", "pip3", "pipx",
                         "pluma", "ps", "psensor", "pydf", "pyinstaller", "python3", "qps", "refind", "rsync",
                         "rhythmbox", "screenfetch", "ss", "stat", "sudo", "sysctl", "thunar", "timeshift", "tor",
                         "uname", "uptime", "vlc", "visudo", "vmstat", "w", "who", "whoami", "xed", "xinput",
                         "xfce4-terminal"]
        ui.cb99.addItems(versions_list)

        # apt policy
        ui.cb101.setEditable(True)
        ui.cb101.setMaxVisibleItems(10)
        ui.cb101.lineEdit().setReadOnly(True)
        ui.cb101.setStyleSheet("QComboBox"
                               "{""background-color: white""}")
        ui.cb101.update()
        apt_policy_list = ["Select", "bpytop", "btop", "clamtk", "cpu-x", "cpufetch", "cpupower", "cpupower-gui",
                           "df", "dmidecode", "dpkg", "efibootmgr", "fdisk", "flatpak", "firejail", "gdu", "gparted",
                           "grub-customizer", "gufw", "hardinfo", "hostname", "htop", "hwinfo", "inxi", "linuxinfo",
                           "locate", "lshw", "lsof", "mc", "neofetch", "nuitka", "nvtop", "os-prober",
                           "pip", "pipx", "psensor", "python3", "qps", "systemctl", "xinput"]
        ui.cb101.addItems(apt_policy_list)

        # du
        ui.cb102.setEditable(True)
        ui.cb102.setMaxVisibleItems(10)
        ui.cb102.lineEdit().setReadOnly(True)
        ui.cb102.setStyleSheet("QComboBox"
                               "{""background-color: white""}")
        ui.cb102.update()
        du_list = ["Select", "/bin", "/boot", "/etc", "/dev", "/home", "/lib", "/lib64", "/media",
                   "/mnt", "/opt", "/proc", "/sbin", "/srv", "/sys", "/tmp", "/usr", "/var"]
        ui.cb102.addItems(du_list)

        # nslookup
        ui.cb108.setEditable(True)
        ui.cb108.setMaxVisibleItems(10)
        ui.cb108.lineEdit().setReadOnly(True)
        ui.cb108.setStyleSheet("QComboBox"
                               "{""background-color: white""}")
        ui.cb108.update()
        ns_list = ["Select",
                   "www.asus.com", "www.amd.com", "www.anandtech.com",
                   "www.distrowatch.com", "www.duckduckgo.com",
                   "www.evga.com", "www.hp.com",
                   "www.google.com", "www.microsoft.com", "www.newegg.com",
                   "www.pcworld.com", "www.tomshardware.com",
                   "www.nvidia.com",
                   "www.userbenchmark.com", "www.youtube.com", ]
        ui.cb108.addItems(ns_list)

    @staticmethod
    def onclickedf():
        if ui.actionSend_to_text_file_2.isChecked():
            ui.actionSend_to_terminal_2.setChecked(False)

    @staticmethod
    def onclickedt():
        if ui.actionSend_to_terminal_2.isChecked():
            ui.actionSend_to_text_file_2.setChecked(False)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    frameGm = MainWindow.frameGeometry()
    centerPoint = QtGui.QGuiApplication.primaryScreen().availableGeometry().center()
    frameGm.moveCenter(centerPoint)
    MainWindow.move(frameGm.topLeft())
    MainWindow.setStyleSheet(
                         "QComboBox""{font: 9pt Ariel}"
                         "QLabel""{font: 9pt Ariel}"
                         "QMenu""{font: 9pt Ariel}"
                         "QAction""{font: 9pt Ariel}"
                         "QLabel""{color: black}"
                         "QPushButton""{font: 9pt Ariel}"
                         "QMenuBar""{font: 9pt Ariel}"
                         "QStatusBar""{font: 9pt Ariel}"
                         "QStatusBar""{color: black}"
                         "QTabWidget""{font: 9pt Ariel}")
    MainWindow.show()

    # my code startup code
    ssdesc = ui.startupinfo()
    # read file for style
    globalstylevalue = ui.getsavedstyle()
    ui.setthestyle(globalstylevalue)
    if "Garuda" in ssdesc or 'Parrot' in ssdesc:
        ui.stylelight()
    # tab order must be loaded here not below
    ui.settaborders()

    myprocess = QProcess()
    ui.cb39showhide()   # based on the distro
    myMessage = QLabel()
    myMessage.setText(ssdesc.strip())

    ui.statusbar.addPermanentWidget(myMessage)
    ui.passrtn(MainWindow)
    ui.actionSend_to_text_file_2.setChecked(True)
    ui.loadallcomboboxes()
    ui.loadfolderlist()
    ui.displayforumname()

    file_exists5 = exists('/usr/bin/kinfocenter')
    if file_exists5:
        ui.pb39_3.show()
        ui.lb39_6.show()
        ui.lb39_5.show()
    else:
        ui.pb39_3.hide()
        ui.lb39_6.hide()
        ui.lb39_5.hide()

    # botton actions
    ui.pb1.clicked.connect(ui.getaboutcenterhellowelcome)
    ui.pb6.clicked.connect(lambda: ui.getcomboboxdata('6', 'apt'))
    ui.pb101.clicked.connect(lambda: ui.getcomboboxdata('101', 'apt policy'))
    ui.pb7.clicked.connect(lambda: ui.getcomboboxdataqprocess('7'))
    ui.pb2.clicked.connect(lambda: ui.popen_function_common_simple(str('blkid -o list')))
    ui.pb4.clicked.connect(lambda: ui.thread_function(str('bpytop')))
    ui.pb8.clicked.connect(lambda: ui.thread_function(str('btop')))
    ui.pb5.clicked.connect(lambda: ui.getcomboboxdata('5', 'cat'))
    ui.pb9_4.clicked.connect(lambda: ui.popen_function_common_simple(str('cpu-info')))
    ui.pb9.clicked.connect(lambda: ui.popen_for_programs(str('cpu-x')))
    ui.pb10.clicked.connect(lambda: ui.thread_function(str('cpufetch')))
    ui.pb11.clicked.connect(lambda: ui.popen_for_programs(str('cpupower-gui')))
    ui.pb12.clicked.connect(lambda: ui.popen_for_programs(str('clamtk')))
    ui.pb86.clicked.connect(lambda: ui.getcomboboxdata('86', 'cpupower'))
    ui.pb13.clicked.connect(lambda: ui.getcomboboxdata('13', 'df'))
    ui.pb13_4.clicked.connect(lambda: ui.getcomboboxdata('13_2', 'dig'))
    ui.pb108.clicked.connect(lambda: ui.getcomboboxdata('108', 'nslookup'))
    ui.pb14_4.clicked.connect(lambda: ui.popen_function_common_simple(str('dmesg')))
    ui.pb15.clicked.connect(lambda: ui.getcomboboxdata(15, 'dmidecode'))
    ui.pb16.clicked.connect(lambda: ui.popen_function_common_simple(str('dpkg -l')))
    ui.pb17.clicked.connect(lambda: ui.popen_for_programs(str('driver-manager')))
    ui.pb102.clicked.connect(lambda: ui.getcomboboxdata(102, 'du'))
    ui.pb18.clicked.connect(lambda: ui.popen_for_programs(ui.getoseditor()))
    ui.pb19.clicked.connect(lambda: ui.popen_function_common_simple(str('efibootmgr')))
    ui.pb20.clicked.connect(lambda: ui.popen_function_common_simple(str('env')))
    ui.pb21.clicked.connect(lambda: ui.popen_function_common(str('fdisk -x')))
    ui.pb22.clicked.connect(lambda: ui.getcomboboxdata(22, 'find'))
    ui.pb23.clicked.connect(lambda: ui.getcomboboxdata(23, 'find'))
    ui.pb24.clicked.connect(lambda: ui.popen_function_common_simple(str('findmnt')))
    ui.pb93.clicked.connect(lambda: ui.popen_function_common_simple(str('flatpak list')))
    ui.pb25.clicked.connect(lambda: ui.popen_function_run(str('firewall-config')))
    ui.pb26.clicked.connect(lambda: ui.popen_function_common_simple(str('free -h')))
    ui.pb27.clicked.connect(lambda: ui.popen_function_common_simple(str('gdu')))
    ui.pb89.clicked.connect(lambda: ui.popen_function_common_simple(str('getconf -a')))
    ui.pb106.clicked.connect(lambda: ui.popen_for_programs(str('gnome-disks')))
    ui.pb28.clicked.connect(lambda: ui.popen_for_programs(str('gparted')))
    ui.pb29.clicked.connect(lambda: ui.popen_for_programs(str('grub-customizer')))
    ui.pb30.clicked.connect(lambda: ui.popen_for_programs(str('gufw')))
    ui.pb31.clicked.connect(lambda: ui.popen_for_programs(str('hardinfo')))
    ui.pb32.clicked.connect(lambda: ui.popen_function_common(str('hcitool dev')))
    ui.pb103.clicked.connect(lambda: ui.popen_function_common_simple(str('hdparm -I /dev/sda')))
    ui.pb91_3.clicked.connect(lambda: ui.popen_function_common_simple(str('cat /root/.bash_history')))
    ui.pb33.clicked.connect(lambda: ui.getcomboboxdata(33, 'hostname'))
    ui.pb91.clicked.connect(lambda: ui.popen_function_common(str('hostnamectl')))
    ui.pb88.clicked.connect(lambda: ui.thread_function(str('htop')))
    ui.pb34.clicked.connect(lambda: ui.popen_function_common_simple(str('hwinfo --disk')))
    ui.pb35.clicked.connect(lambda: ui.popen_function_common_simple(str('id')))
    ui.pb36.clicked.connect(lambda: ui.getcomboboxdata(36, 'ifconfig'))
    ui.pb37.clicked.connect(lambda: ui.getcomboboxdata(37, 'inxi'))
    ui.pb35_3.clicked.connect(lambda: ui.popen_function_common_simple(str('iostat')))
    ui.pb38.clicked.connect(lambda: ui.getcomboboxdata(38, 'ip'))
    ui.pb47_4.clicked.connect(lambda: ui.popen_function_common_simple(str('journalctl -xe')))
    ui.pb39.clicked.connect(lambda: ui.findcontrolcenter())
    ui.pb39_2.clicked.connect(lambda: ui.popen_for_programs(ui.findsysteminformation()))
    ui.pb39_3.clicked.connect(lambda: ui.popen_for_programs(str('kinfocenter kcm_about-distro')))
    ui.pb42.clicked.connect(lambda: ui.popen_function_common(str('linuxinfo')))
    ui.pb40.clicked.connect(lambda: ui.getcomboboxdata(40, 'locate'))
    ui.pb45.clicked.connect(lambda: ui.popen_function_common(str('lsblk -f')))
    ui.pb44.clicked.connect(lambda: ui.getcomboboxdata(44, 'lpstat'))
    ui.pb46.clicked.connect(lambda: ui.popen_function_common(str('lscpu')))
    ui.pb47.clicked.connect(lambda: ui.popen_function_common(str('lshw')))
    ui.pb48.clicked.connect(lambda: ui.popen_function_common(str('lslogins')))
    ui.pb90_3.clicked.connect(lambda: ui.popen_function_common(str('lsmod')))
    ui.pb90.clicked.connect(lambda: ui.popen_function_common(str('lsof')))
    ui.pb49.clicked.connect(lambda: ui.popen_function_common(str('lspci -tv')))
    ui.pb50.clicked.connect(lambda: ui.popen_function_common(str('lsscsi')))
    ui.pb51.clicked.connect(lambda: ui.popen_function_common(str('lsusb')))
    ui.pb52.clicked.connect(lambda: ui.getcomboboxdata(52, 'ls /'))
    ui.pb84.clicked.connect(lambda: ui.thread_function(str('mc')))
    ui.pb55.clicked.connect(lambda: ui.thread_function(str('neofetch')))
    ui.pb57.clicked.connect(lambda: ui.getcomboboxdata(57, 'netstat'))
    ui.pb58.clicked.connect(lambda: ui.popen_function_common(str('systemctl status NetworkManager')))
    ui.pb87.clicked.connect(lambda: ui.popen_function_common(str('nmcli')))
    ui.pb59.clicked.connect(lambda: ui.getcomboboxdata(59, 'nvidia-smi'))
    ui.pb60.clicked.connect(lambda: ui.popen_for_programs(str('nvidia-settings')))
    ui.pb61.clicked.connect(lambda: ui.thread_function(str('nvtop')))
    ui.pb110.clicked.connect(lambda: ui.popen_function_common_simple(str('os-prober')))
    ui.pb105.clicked.connect(lambda: ui.popen_function_common_simple(str('parted -l')))
    ui.pb64.clicked.connect(lambda: ui.popen_function_common(str('pip list standard')))
    ui.pb65.clicked.connect(lambda: ui.popen_function_common(str('pip list --user')))
    ui.pb69_4.clicked.connect(lambda: ui.popen_function_common(str('printenv')))
    ui.pb66.clicked.connect(lambda: ui.getcomboboxdata('66', 'ps'))
    ui.pb68.clicked.connect(lambda: ui.popen_for_programs(str('psensor')))
    ui.pb69.clicked.connect(lambda: ui.popen_function_common(str('pstree')))
    ui.pb70.clicked.connect(lambda: ui.popen_function_common(str('pydf')))
    ui.pb71.clicked.connect(lambda: ui.popen_function_common(str('python3 -V')))
    ui.pb72.clicked.connect(lambda: ui.popen_for_programs(str('rhythmbox')))
    ui.pb73.clicked.connect(lambda: ui.getcomboboxdata(73, 'ss'))
    ui.pb74.clicked.connect(lambda: ui.popen_function_common_simple(str('sysctl -a')))
    ui.pb75.clicked.connect(lambda: ui.popen_for_programs(ui.getsystemmonitor()))
    ui.pb76.clicked.connect(lambda: ui.getcomboboxdataqprocess(76))
    ui.pb77_4.clicked.connect(lambda: ui.getcomboboxdata(77_2, 'tree'))
    ui.pb77.clicked.connect(lambda: ui.getcomboboxdata(77, 'uname'))
    ui.pb78_4.clicked.connect(lambda: ui.popen_for_programs(str('celluloid')))
    ui.pb78.clicked.connect(lambda: ui.popen_for_programs(str('vlc')))
    ui.pb79.clicked.connect(lambda: ui.getcomboboxdata(79, 'vmstat'))
    ui.pb80.clicked.connect(lambda: ui.popen_function_common(str('w')))
    ui.pb81.clicked.connect(lambda: ui.popen_function_common(str('who')))
    ui.pb82.clicked.connect(lambda: ui.popen_function_common(str('whoami')))
    ui.pb83.clicked.connect(lambda: ui.getcomboboxdata(83, 'xinput'))
    ui.pb94.clicked.connect(lambda: ui.getcomboboxdata(94, 'programs'))
    ui.pb95.clicked.connect(lambda: ui.popen_for_programs(str('qps')))
    ui.pb99.clicked.connect(lambda: ui.getcomboboxdata(99, 'version'))

    # bytton actions for manuals
    ui.pb2_2.clicked.connect(lambda: ui.popen_function_common_simple('man blkid'))
    ui.pb4_2.clicked.connect(lambda: ui.popen_function_common_simple('man bpytop'))
    ui.pb5_2.clicked.connect(lambda: ui.popen_function_common_simple('man cat'))
    ui.pb6_2.clicked.connect(lambda: ui.popen_function_common_simple('man apt'))
    ui.pb101_2.clicked.connect(lambda: ui.popen_function_common_simple('man apt'))
    ui.pb7_2.clicked.connect(lambda: ui.popen_function_common_simple('man atop'))
    ui.pb8_2.clicked.connect(lambda: ui.popen_function_common_simple('man btop'))
    ui.pb9_2.clicked.connect(lambda: ui.popen_function_common_simple('man cpu-x'))
    ui.pb10_2.clicked.connect(lambda: ui.popen_function_common_simple('man cpufetch'))
    ui.pb11_2.clicked.connect(lambda: ui.popen_function_common_simple('man cpupower-gui'))
    ui.pb12_2.clicked.connect(lambda: ui.popen_function_common_simple('man clamtk'))
    ui.pb13_2.clicked.connect(lambda: ui.popen_function_common_simple('man df'))
    ui.pb13_3.clicked.connect(lambda: ui.popen_function_common_simple('man dig'))
    ui.pb108_2.clicked.connect(lambda: ui.popen_function_common_simple('man nslookup'))
    ui.pb14_3.clicked.connect(lambda: ui.popen_function_common_simple('man dmesg'))
    ui.pb15_2.clicked.connect(lambda: ui.popen_function_common_simple('man dmidecode'))
    ui.pb16_2.clicked.connect(lambda: ui.popen_function_common_simple('man dpkg'))
    ui.pb102_2.clicked.connect(lambda: ui.popen_function_common_simple('man du'))
    ui.pb18_2.clicked.connect(lambda: ui.popen_function_common_simple('man ' + ui.getoseditor()))
    ui.pb19_2.clicked.connect(lambda: ui.popen_function_common_simple('man efibootmgr'))
    ui.pb20_2.clicked.connect(lambda: ui.popen_function_common_simple('man env'))
    ui.pb21_2.clicked.connect(lambda: ui.popen_function_common_simple('man fdisk'))
    ui.pb22_2.clicked.connect(lambda: ui.popen_function_common_simple('man find'))
    ui.pb23_2.clicked.connect(lambda: ui.popen_function_common_simple('man find'))
    ui.pb24_2.clicked.connect(lambda: ui.popen_function_common_simple('man findmnt'))
    ui.pb25_2.clicked.connect(lambda: ui.popen_function_common_simple('man firewall-config'))
    ui.pb26_2.clicked.connect(lambda: ui.popen_function_common_simple('man free'))
    ui.pb27_2.clicked.connect(lambda: ui.popen_function_common_simple('man gdu'))
    ui.pb106_2.clicked.connect(lambda: ui.popen_function_common_simple('man gnome-disks'))
    ui.pb28_2.clicked.connect(lambda: ui.popen_function_common_simple('man gparted'))
    ui.pb29_2.clicked.connect(lambda: ui.popen_function_common_simple('man grub-customizer'))
    ui.pb30_2.clicked.connect(lambda: ui.popen_function_common_simple('man gufw'))
    ui.pb31_2.clicked.connect(lambda: ui.popen_function_common_simple('man hardinfo'))
    ui.pb32_2.clicked.connect(lambda: ui.popen_function_common_simple('man hcitool'))
    ui.pb103_2.clicked.connect(lambda: ui.popen_function_common_simple('man hdparm'))
    ui.pb91_4.clicked.connect(lambda: ui.popen_function_common_simple('man history'))
    ui.pb33_2.clicked.connect(lambda: ui.popen_function_common_simple('man hostname'))
    ui.pb34_2.clicked.connect(lambda: ui.popen_function_common_simple('man hwinfo'))
    ui.pb35_2.clicked.connect(lambda: ui.popen_function_common_simple('man id'))
    ui.pb36_2.clicked.connect(lambda: ui.popen_function_common_simple('man ifconfig'))
    ui.pb37_2.clicked.connect(lambda: ui.popen_function_common_simple('man inxi'))
    ui.pb35_4.clicked.connect(lambda: ui.popen_function_common_simple('man iostat'))
    ui.pb38_2.clicked.connect(lambda: ui.popen_function_common_simple('man ip'))
    ui.pb47_3.clicked.connect(lambda: ui.popen_function_common_simple('man journalctl'))
    ui.pb40_2.clicked.connect(lambda: ui.popen_function_common_simple('man locate'))
    ui.pb42_2.clicked.connect(lambda: ui.popen_function_common_simple('man linuxinfo'))
    ui.pb44_2.clicked.connect(lambda: ui.popen_function_common_simple('man lpstat'))
    ui.pb45_2.clicked.connect(lambda: ui.popen_function_common_simple('man lsblk'))
    ui.pb46_2.clicked.connect(lambda: ui.popen_function_common_simple('man lscpu'))
    ui.pb47_2.clicked.connect(lambda: ui.popen_function_common_simple('man lshw'))
    ui.pb48_2.clicked.connect(lambda: ui.popen_function_common_simple('man lslogins'))
    ui.pb49_2.clicked.connect(lambda: ui.popen_function_common_simple('man lspci'))
    ui.pb50_2.clicked.connect(lambda: ui.popen_function_common_simple('man lsscsi'))
    ui.pb51_2.clicked.connect(lambda: ui.popen_function_common_simple('man lsusb'))
    ui.pb52_2.clicked.connect(lambda: ui.popen_function_common_simple('man ls'))
    ui.pb55_2.clicked.connect(lambda: ui.popen_function_common_simple('man neofetch'))
    ui.pb57_2.clicked.connect(lambda: ui.popen_function_common_simple('man netstat'))
    ui.pb58_2.clicked.connect(lambda: ui.popen_function_common_simple('man systemctl'))
    ui.pb59_2.clicked.connect(lambda: ui.popen_function_common_simple('man nvidia-smi'))
    ui.pb60_2.clicked.connect(lambda: ui.popen_function_common_simple('man nvidia-settings'))
    ui.pb61_2.clicked.connect(lambda: ui.popen_function_common_simple('man nvtop'))
    ui.pb105_2.clicked.connect(lambda: ui.popen_function_common_simple('man parted'))
    ui.pb64_2.clicked.connect(lambda: ui.popen_function_common_simple('man pip'))
    ui.pb65_2.clicked.connect(lambda: ui.popen_function_common_simple('man pip3'))
    ui.pb69_3.clicked.connect(lambda: ui.popen_function_common_simple('man printenv'))
    ui.pb66_2.clicked.connect(lambda: ui.popen_function_common_simple('man ps'))
    ui.pb68_2.clicked.connect(lambda: ui.popen_function_common_simple('man psensor'))
    ui.pb69_2.clicked.connect(lambda: ui.popen_function_common_simple('man pstree'))
    ui.pb71_2.clicked.connect(lambda: ui.popen_function_common_simple('man python3'))
    ui.pb72_2.clicked.connect(lambda: ui.popen_function_common_simple('man rhythmbox'))
    ui.pb73_2.clicked.connect(lambda: ui.popen_function_common_simple('man ss'))
    ui.pb74_2.clicked.connect(lambda: ui.popen_function_common_simple('man sysctl'))
    ui.pb76_2.clicked.connect(lambda: ui.popen_function_common_simple('man top'))
    ui.pb77_3.clicked.connect(lambda: ui.popen_function_common_simple('man tree'))
    ui.pb77_2.clicked.connect(lambda: ui.popen_function_common_simple('man uname'))
    ui.pb78_3.clicked.connect(lambda: ui.popen_function_common_simple('man celluloid'))
    ui.pb78_2.clicked.connect(lambda: ui.popen_function_common_simple('man vlc'))
    ui.pb79_2.clicked.connect(lambda: ui.popen_function_common_simple('man vmstat'))
    ui.pb80_2.clicked.connect(lambda: ui.popen_function_common_simple('man w'))
    ui.pb81_2.clicked.connect(lambda: ui.popen_function_common_simple('man who'))
    ui.pb82_2.clicked.connect(lambda: ui.popen_function_common_simple('man whoami'))
    ui.pb83_2.clicked.connect(lambda: ui.popen_function_common_simple('man xinput'))
    ui.pb84_2.clicked.connect(lambda: ui.popen_function_common_simple('man mc'))
    ui.pb86_2.clicked.connect(lambda: ui.popen_function_common_simple('man cpupower'))
    ui.pb87_2.clicked.connect(lambda: ui.popen_function_common_simple('man nmcli'))
    ui.pb88_2.clicked.connect(lambda: ui.popen_function_common_simple('man htop'))
    ui.pb89_2.clicked.connect(lambda: ui.popen_function_common_simple('man getconf'))
    ui.pb90_2.clicked.connect(lambda: ui.popen_function_common_simple('man lsof'))
    ui.pb90_4.clicked.connect(lambda: ui.popen_function_common_simple('man lsmod'))
    ui.pb91_2.clicked.connect(lambda: ui.popen_function_common_simple('man hostnamectl'))
    ui.pb93_2.clicked.connect(lambda: ui.popen_function_common_simple('man flatpak'))
    ui.pb94_2.clicked.connect(lambda: ui.popen_function_common_simple('man ls'))
    ui.pb95_2.clicked.connect(lambda: ui.popen_function_common_simple('man qps'))
    ui.pb99_2.clicked.connect(lambda: ui.popen_function_common_simple('man version'))

    # list tab
    ui.pbRefreshList.clicked.connect(lambda: ui.loadfolderlist())
    ui.pbEditFile.clicked.connect(lambda: ui.openfileineditor())

    # help panels
    ui.actionAbout_3.triggered.connect(lambda: ui.leccabout())
    ui.actionNotes_2.triggered.connect(lambda: ui.leccnotes())
    ui.actionCommands_2.triggered.connect(lambda: ui.lecccommands())
    ui.actionTesting.triggered.connect(lambda: ui.lecctesting())
    ui.actionLicense_Copyright.triggered.connect(lambda: ui.licensecopyright())

    # styles
    ui.actionDark.triggered.connect(ui.styledark)
    ui.actionDark_Dark_2.triggered.connect(ui.styledarkdark)
    ui.actionBlue.triggered.connect(ui.styleblue)
    ui.actionGreen.triggered.connect(ui.stylegreen)
    ui.actionLight_2.triggered.connect(ui.stylelight)
    ui.actionTeal.triggered.connect(ui.styleteal)
    ui.actionGray.triggered.connect(ui.stylegray)
    ui.action_Cocoa.triggered.connect(ui.stylecocoa)
    ui.actionCyan.triggered.connect(ui.stylecyan)
    ui.actionTan.triggered.connect(ui.styletan)

    # menu selections
    ui.action_distrowatch.triggered.connect(lambda: ui.urldistrowatch())
    ui.action_forum.triggered.connect(lambda: ui.loadforumslist())
    ui.actionLGPL_3_0.triggered.connect(ui.lgplinfo)

    # send to file or terminal
    ui.actionSend_to_text_file_2.toggled.connect(ui.onclickedf)
    ui.actionSend_to_terminal_2.toggled.connect(ui.onclickedt)
    # my code end

    sys.exit(app.exec())
